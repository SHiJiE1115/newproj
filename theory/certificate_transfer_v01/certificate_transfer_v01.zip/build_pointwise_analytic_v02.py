"""Three-subcube analytic certificate obstruction and explicit attaining completion."""
from fractions import Fraction
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
raw = (HERE / 'CERTIFICATE_TRANSFER_PROTOCOL_V01.json').read_bytes()
assert hashlib.sha256(raw).hexdigest() == '1d4de4a832e575efe1d40ca44cb9eedbf39720e84d6448b1f848a4a61c295f81'
p = json.loads(raw)
amendment_raw = (HERE / 'POST_CAP_ANALYTIC_PROTOCOL_V02.json').read_bytes()
amendment = json.loads(amendment_raw)
worlds = p['source']
prices = (2, 2, 3, 0, 1, 1, 1)
idx = lambda v: sum(bit << q for q, bit in enumerate(v))
cost = lambda s: sum(prices[q] for q in range(7) if s >> q & 1)
pos = {idx(w['bits']) for w in worlds if w['label']}
neg = {idx(w['bits']) for w in worlds if not w['label']}


def certificates(x, positives, negatives):
    opposite = negatives if x in positives else positives
    return [s for s in range(128) if all((x ^ y) & s for y in opposite)]


legal_sets = {x: certificates(x, pos, neg) for x in pos | neg}
promise_costs = {x: min(map(cost, ss)) for x, ss in legal_sets.items()}
abc = {name: idx(v) for name, v in amendment['three_legal_worlds_in_coordinate_order'].items()}
a, b, c = (abc[name] for name in ('a', 'b', 'c'))
assert a in pos and b in neg and c in pos
assert [promise_costs[x] for x in (a, b, c)] == [1, 2, 2]
cheap_a = [s for s in legal_sets[a] if cost(s) < 2]
assert cheap_a == [(1 << 3) | (1 << 6)]
b_under4 = [s for s in legal_sets[b] if cost(s) < 4]
assert all(s & 2 for s in b_under4)
b_after_a = [s for s in b_under4 if s & (1 << 6)]
assert b_after_a == [66, 74]
assert all(s & ~74 == 0 for s in b_after_a)
assert all((b ^ c) & s == 2 for s in b_after_a)
c_under4_with_q1 = [s for s in legal_sets[c] if cost(s) < 4 and s & 2]
assert c_under4_with_q1 == []
assert b ^ 2 in pos


def completion(x):
    q = [(x >> i) & 1 for i in range(7)]
    if q[3] != q[6]:
        return 1
    if q[5] != q[6] or q[1] == 0:
        return 0
    return int((not q[0]) or q[4]) if q[3] == 0 else int((not q[4]) or q[2])


truth = [completion(x) for x in range(128)]
assert all(truth[x] == int(x in pos) for x in pos | neg)
all_pos = {x for x in range(128) if truth[x]}
all_neg = set(range(128)) - all_pos
rows = []
for w in worlds:
    x = idx(w['bits'])
    full_sets = certificates(x, all_pos, all_neg)
    best = min(map(cost, full_sets))
    ratio = Fraction(best, promise_costs[x])
    assert ratio <= 2
    rows.append({'input': x, 'label': w['label'], 'promise_cost': promise_costs[x], 'full_cost': best,
                 'ratio': str(ratio), 'one_minimum_full_certificate': min(s for s in full_sets if cost(s) == best)})
assert max(Fraction(row['ratio']) for row in rows) == 2
result = {
    'status': 'PRODUCER_SHARP_POINTWISE_INFLATION_PENDING_SEPARATE_VERIFICATION',
    'protocol_sha256': hashlib.sha256(raw).hexdigest(), 'post_cap_amendment_sha256': hashlib.sha256(amendment_raw).hexdigest(),
    'all_completion_lower_witness': {'worlds': abc, 'promise_costs': {'a': 1, 'b': 2, 'c': 2},
        'promise_certificates_at_a_below_cost2': cheap_a,
        'promise_certificates_at_b_below_cost4': b_under4,
        'b_certificates_compatible_with_positive_cube_avoidance': b_after_a,
        'promise_certificates_at_c_below_cost4_containing_q1': c_under4_with_q1,
        'disjunction': 'C_g(a)>=2 OR C_g(b)>=4 OR C_g(c)>=4',
        'base_inflation_lower': '2',
        'positive_probe_inflation_lower': '2/(1+epsilon)for0<=epsilon<1',
        'positive_extension_reason': 'All query prices only increase from base. Threshold<2at a still forces{3,6}; threshold<4at b after q1andq6 permits only optionalq3; threshold<4at c containingq1 is already impossible at base. Promise costs at a,b,c are1+epsilon,2,2in this interval.'},
    'attaining_completion': {'definition': amendment['attaining_completion'],
        'full_truth_table_integer': sum(v << x for x, v in enumerate(truth)),
        'full_output_bits_input_integer_order': truth, 'source_full_certificate_comparison': rows},
    'sharp_minimum_pointwise_inflation_all_total_completions_at_free_probe': '2',
    'exact_positive_epsilon_inflation': 'NOT_COMPUTED',
    'capped_DP_used_as_theorem_evidence': False,
    'all_completions_enumerated': False, 'lower_is_analytic_universal_not_a_census': True,
    'new_model_API_calls': 0, 'human_review': False, 'literature_priority_established': False}
out = HERE / 'POINTWISE_ANALYTIC_RESULT_V02.json'
assert not out.exists()
out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': result['status'], 'unrestricted_pointwise_inflation': '2',
                  'positive_probe_lower': '2/(1+epsilon)', 'source_worlds': len(rows), 'search_failure_used_as_proof': False}), flush=True)
