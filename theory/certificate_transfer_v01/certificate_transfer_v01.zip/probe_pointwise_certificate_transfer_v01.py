"""Bounded exact existence search for pointwise promise-certificate preservation."""
import hashlib
import itertools
import json
from pathlib import Path
import time

HERE = Path(__file__).resolve().parent
PSHA = '1d4de4a832e575efe1d40ca44cb9eedbf39720e84d6448b1f848a4a61c295f81'
raw = (HERE / 'CERTIFICATE_TRANSFER_PROTOCOL_V01.json').read_bytes()
assert hashlib.sha256(raw).hexdigest() == PSHA
p = json.loads(raw)
worlds = p['source']
prices = p['secondary']['prices']
limits = p['secondary']['limits']
N = len(worlds)
target = sum(w['label'] << i for i, w in enumerate(worlds))
full = (1 << N) - 1
budget = []
for w in worlds:
    opposite = [v['bits'] for v in worlds if v['label'] != w['label']]
    feasible = [s for s in range(128) if all(any(s >> q & 1 and w['bits'][q] != v[q] for q in range(7)) for v in opposite)]
    budget.append(min(sum(prices[q] for q in range(7) if s >> q & 1) for s in feasible))
caps = [a + 1 for a in budget]
assert max(caps) < 256
dp = {}
retained = 0
pairs = 0
started = time.monotonic()
layer_counts = []
answer = None


class ResourceCap(Exception):
    pass


class Found(Exception):
    def __init__(self, node, subset, vector):
        self.node, self.subset, self.vector = node, subset, vector


def check_limits():
    if pairs >= limits['max_combination_pairs']:
        raise ResourceCap('combination-pair limit')
    if retained >= limits['max_retained_vectors']:
        raise ResourceCap('retained-vector limit')
    if time.monotonic() - started >= limits['max_wall_seconds']:
        raise ResourceCap('wall-time limit')


def insert(states, mask, vector, node, subset):
    global retained
    if mask == target and all(a <= b for a, b in zip(vector, budget)):
        raise Found(node, subset, vector)
    group = states.setdefault(mask, {})
    if vector in group:
        return
    if any(all(a <= b for a, b in zip(old, vector)) for old in group):
        return
    worse = [old for old in group if all(a <= b for a, b in zip(vector, old))]
    for old in worse:
        del group[old]
    group[vector] = node
    retained += 1 - len(worse)


status, reason = 'NO_POINTWISE_PRESERVING_RO_COMPLETION', None
try:
    for size in range(1, 8):
        for coords in itertools.combinations(range(7), size):
            subset = sum(1 << q for q in coords)
            states = {}
            if size == 1:
                q = coords[0]
                mask = sum(w['bits'][q] << i for i, w in enumerate(worlds))
                vec = bytes(min(prices[q], cap) for cap in caps)
                insert(states, mask, vec, (q, False), subset)
                insert(states, mask ^ full, vec, (q, True), subset)
            else:
                left = (subset - 1) & subset
                while left:
                    right = subset ^ left
                    if right and left & (subset & -subset):
                        for ma, ga in dp[left].items():
                            for mb, gb in dp[right].items():
                                amask, omask = ma & mb, ma | mb
                                for ca, ta in ga.items():
                                    for cb, tb in gb.items():
                                        pairs += 1
                                        if pairs % 1000 == 0:
                                            check_limits()
                                        av, ov = [], []
                                        for i in range(N):
                                            a, b, u, v = (ma >> i) & 1, (mb >> i) & 1, ca[i], cb[i]
                                            ac = u + v if a and b else min(u, v) if not a and not b else u if not a else v
                                            oc = u + v if not a and not b else min(u, v) if a and b else u if a else v
                                            av.append(min(caps[i], ac))
                                            ov.append(min(caps[i], oc))
                                        insert(states, amask, bytes(av), ('AND', ta, tb), subset)
                                        insert(states, omask, bytes(ov), ('OR', ta, tb), subset)
                    left = (left - 1) & subset
            dp[subset] = states
            check_limits()
        layer_counts.append({'size': size, 'retained_vectors': retained, 'combination_pairs': pairs})
        print(json.dumps({'completed_layer': size, 'vectors': retained, 'pairs': pairs}), flush=True)
except Found as hit:
    status = 'FOUND_POINTWISE_PRESERVING_COMPATIBLE_RO_COMPLETION'
    answer = {'formula': hit.node, 'used_coordinate_subset': hit.subset, 'capped_certificate_vector': list(hit.vector)}
except ResourceCap as stop:
    status, reason = 'UNKNOWN_RESOURCE_CAPPED', str(stop)

frontier_path = None
if status == 'NO_POINTWISE_PRESERVING_RO_COMPLETION':
    frontier = {'protocol_sha256': PSHA, 'budgets': budget, 'caps': caps,
                'states': [{'subset': s, 'output_mask': m, 'vectors_hex': sorted(v.hex() for v in group)}
                           for s, states in sorted(dp.items()) for m, group in sorted(states.items())]}
    frontier_path = HERE / 'POINTWISE_COVERAGE_FRONTIER_V01.json'
    assert not frontier_path.exists()
    frontier_path.write_text(json.dumps(frontier, indent=2) + '\n', encoding='utf-8')
result = {
    'status': status, 'protocol_sha256': PSHA, 'prices': prices,
    'promise_cheapest_certificate_costs': budget, 'saturation_caps': caps,
    'target_output_mask': target, 'completed_layers': layer_counts,
    'retained_vectors': retained, 'combination_pairs': pairs,
    'wall_seconds': time.monotonic() - started, 'resource_cap_reason': reason,
    'formula_witness': answer, 'coverage_frontier': None if frontier_path is None else {
        'name': frontier_path.name, 'bytes': frontier_path.stat().st_size,
        'sha256': hashlib.sha256(frontier_path.read_bytes()).hexdigest()},
    'all_RO_functions_explicitly_enumerated': False,
    'mathematical_completeness': status == 'NO_POINTWISE_PRESERVING_RO_COMPLETION',
    'if_no': 'Subset-disjoint formula induction and monotone capped sum/min recurrence; full closed frontier must be independently checked before accepting absence.',
    'if_found': 'The explicit full function and all promised full-certificate minima must be independently checked; search completeness is unnecessary for existence.',
    'if_capped': 'No mathematical absence or existence conclusion; no automatic larger retry',
    'human_review': False, 'new_model_API_calls': 0}
out = HERE / 'POINTWISE_CERTIFICATE_PROBE_V01.json'
assert not out.exists()
out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': status, 'vectors': retained, 'pairs': pairs, 'wall_seconds': result['wall_seconds'], 'reason': reason}), flush=True)
