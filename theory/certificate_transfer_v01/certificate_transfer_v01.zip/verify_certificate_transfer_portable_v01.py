"""Independent truth/cofactor classification and opposite-input hitting sets."""
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def load(name):
    raw = (HERE / name).read_bytes()
    return json.loads(raw), hashlib.sha256(raw).hexdigest()


p, psha = load('CERTIFICATE_TRANSFER_PROTOCOL_V01.json')
assert psha == '1d4de4a832e575efe1d40ca44cb9eedbf39720e84d6448b1f848a4a61c295f81'
am, amsha = load('POST_CAP_ANALYTIC_PROTOCOL_V02.json')
assert amsha == '8c87eca50ddd9e3d51fafa31a7e5f33c2ccbcf4f238323adfe3fa722b6168223'
ro, rosha = load('FULL_CERTIFICATE_TRANSFER_RESULT_V01.json')
pw, pwsha = load('POINTWISE_ANALYTIC_RESULT_V02.json')
probe, probesha = load('POINTWISE_CERTIFICATE_PROBE_V01.json')
assert ro['protocol_sha256'] == pw['protocol_sha256'] == psha
assert pw['post_cap_amendment_sha256'] == amsha
assert am['failed_probe_sha256'] == probesha
assert probe['status'] == 'UNKNOWN_RESOURCE_CAPPED' and probe['mathematical_completeness'] is False
assert probe['retained_vectors'] - p['secondary']['limits']['max_retained_vectors'] == am['cap_audit']['overshoot'] == 64
assert not pw['capped_DP_used_as_theorem_evidence']


def labels(table, n):
    return [(table >> x) & 1 for x in range(1 << n)]


def minimal_hitting_sets(table, n):
    values = labels(table, n)
    answer = []
    for x in range(1 << n):
        differences = {x ^ y for y in range(1 << n) if values[x] != values[y]}
        found = []
        for subset in sorted(range(1 << n), key=lambda s: (s.bit_count(), s)):
            if any(chosen & subset == chosen for chosen in found):
                continue
            if all(subset & difference for difference in differences):
                found.append(subset)
        answer.append(sorted(found))
    return answer


def ro3(table):
    values = labels(table, 3)
    if not all(any(values[x] != values[x ^ (1 << q)] for x in range(8)) for q in range(3)):
        return False
    for q in range(3):
        others = [j for j in range(3) if j != q]
        for b in range(2):
            fixed = [values[x] for x in range(8) if (x >> q) & 1 == b]
            nonconstant = [values[x] for x in range(8) if (x >> q) & 1 != b]
            if len(set(fixed)) == 1 and sum(nonconstant) in (1, 3):
                return True
    return False


expected = {t for t in range(256) if ro3(t)}
rows = {r['truth_table_integer']: r for r in ro['core_rows']}
assert len(expected) == len(rows) == 64 and set(rows) == expected
histogram = {}
for table in sorted(expected):
    families = minimal_hitting_sets(table, 3)
    row = rows[table]
    assert row['minimal_certificate_subsets_by_input'] == families
    kind = row['symbolic_maximum_full_certificate']
    if any(f == [7] for f in families):
        assert kind == 'sum_all_three_prices'
        assert families[row['forced_subset_witness_inputs']['7']] == [7]
    else:
        assert kind == 'maximum_of_three_pair_sums'
        assert all(any(s.bit_count() <= 2 for s in family) for family in families)
        for s in (3, 5, 6):
            assert families[row['forced_subset_witness_inputs'][str(s)]] == [s]
    histogram[kind] = histogram.get(kind, 0) + 1
    costs = [min(sum((2, 2, 3)[q] for q in range(3) if s >> q & 1) for s in family) for family in families]
    assert costs == row['certificate_costs_at_2_2_3']
assert histogram == ro['symbolic_type_histogram'] == {'sum_all_three_prices': 16, 'maximum_of_three_pair_sums': 48}

worlds = []
for a in range(2):
    for b in range(2):
        for c in range(2):
            worlds.append((1, (a, 1, a, b, a, c, c)))
for u in range(2):
    for v in range(2):
        for w in range(2):
            worlds.append((0, (u, u, 0, v, w, w, v)))
assert [{'label': lab, 'bits': list(bits)} for lab, bits in worlds] == p['source']
to_int = lambda bits: sum(b << q for q, b in enumerate(bits))
pos = {to_int(bits) for lab, bits in worlds if lab}
neg = {to_int(bits) for lab, bits in worlds if not lab}
assert pos & neg == set() and len(pos) == len(neg) == 8
for witness in ro['full_source_forced_essential_pairs']:
    a, b, q = witness['A_input'], witness['B_input'], witness['only_difference']
    assert a in pos and b in neg and a ^ b == 1 << q
assert {r['only_difference'] for r in ro['full_source_forced_essential_pairs']} == {0, 1, 2}


def evaluate_formula(formula, x):
    if type(formula[0]) is int:
        return ((x >> formula[0]) & 1) != formula[1]
    left = evaluate_formula(formula[1], x)
    right = evaluate_formula(formula[2], x)
    return left and right if formula[0] == 'AND' else left or right


upper = ro['attaining_RO']
ro_bits = [int(evaluate_formula(upper['formula'], x)) for x in range(128)]
assert sum(a << x for x, a in enumerate(ro_bits)) == upper['full_truth_table_integer']
assert all(ro_bits[x] == int(x in pos) for x in pos | neg)
ro_family = minimal_hitting_sets(upper['full_truth_table_integer'], 7)
assert ro_family == upper['minimal_certificate_subsets_by_input']
assert all(all(s & ~7 == 0 for s in family) for family in ro_family)
assert all(any(s.bit_count() <= 2 for s in family) for family in ro_family)
assert all(any(family == [s] for family in ro_family) for s in (3, 5, 6))
prices = (2, 2, 3, 0, 1, 1, 1)
cost = lambda s: sum(prices[q] for q in range(7) if s >> q & 1)
assert [min(cost(s) for s in family) for family in ro_family] == upper['full_certificate_costs_at_base']
assert max(upper['full_certificate_costs_at_base']) == 5


def tree_run(tree, x, purchased=0):
    if type(tree) is int:
        return tree, purchased
    q, left, right = tree
    assert not purchased & (1 << q)
    return tree_run(right if x & (1 << q) else left, x, purchased | (1 << q))


ad = ro['unrestricted_attaining_completion_at_free_probe']
traces = [tree_run(ad['tree'], x) for x in range(128)]
assert [{'input': x, 'label': lab, 'purchased_subset': mask} for x, (lab, mask) in enumerate(traces)] == ad['full_query_traces']
assert all(traces[x][0] == int(x in pos) for x in pos | neg)
assert max(cost(mask) for _, mask in traces) == 4
assert all(mask & 8 for _, mask in traces)
table = sum(lab << x for x, (lab, _) in enumerate(traces))
assert table == ad['full_truth_table_integer']
ad_family = minimal_hitting_sets(table, 7)
assert ad_family == ad['minimal_certificate_subsets_by_input']
assert [min(cost(s) for s in family) for family in ad_family] == ad['full_certificate_costs_at_base']
assert max(ad['full_certificate_costs_at_base']) == 4
assert 2 in pos and 0 in neg and 3 in neg and 2 ^ 0 == 2 and 2 ^ 3 == 1


def promise_certificates(x):
    opposite = neg if x in pos else pos
    differences = {x ^ y for y in opposite}
    return [s for s in range(128) if all(s & d for d in differences)]


pcerts = {x: promise_certificates(x) for x in pos | neg}
pprices = {x: min(map(cost, masks)) for x, masks in pcerts.items()}
abc = {name: to_int(v) for name, v in am['three_legal_worlds_in_coordinate_order'].items()}
a, b, c = [abc[name] for name in ('a', 'b', 'c')]
assert a in pos and b in neg and c in pos
assert [pprices[x] for x in (a, b, c)] == [1, 2, 2]
cheap = {a: [s for s in pcerts[a] if cost(s) < 2], b: [s for s in pcerts[b] if cost(s) < 4], c: [s for s in pcerts[c] if cost(s) < 4]}
lower = pw['all_completion_lower_witness']
assert lower['worlds'] == abc and cheap[a] == lower['promise_certificates_at_a_below_cost2'] == [72]
assert cheap[b] == lower['promise_certificates_at_b_below_cost4']
assert all(s & 2 for s in cheap[b])
assert [s for s in cheap[b] if s & 64] == lower['b_certificates_compatible_with_positive_cube_avoidance'] == [66, 74]
assert [s for s in cheap[c] if s & 2] == lower['promise_certificates_at_c_below_cost4_containing_q1'] == []
contradiction_cases = 0
for sa in cheap[a]:
    for sb in cheap[b]:
        for sc in cheap[c]:
            ab_disjoint = bool((a ^ b) & sa & sb)
            cb_disjoint = bool((c ^ b) & sc & sb)
            assert not (ab_disjoint and cb_disjoint)
            contradiction_cases += 1
assert contradiction_cases > 0
assert 2 in pcerts[b] and 48 in pcerts[c]
assert cost(2) == cost(48) == 2 and not 2 & 8 and not 48 & 8
assert 72 in pcerts[a] and cost(72) == 1


def attaining(x):
    bit = lambda q: bool(x & (1 << q))
    equal_36 = bit(3) == bit(6)
    equal_56 = bit(5) == bit(6)
    core = ((not bit(0)) or bit(4)) if not bit(3) else ((not bit(4)) or bit(2))
    return int((not equal_36) or (equal_56 and bit(1) and core))


bits = [attaining(x) for x in range(128)]
witness = pw['attaining_completion']
assert bits == witness['full_output_bits_input_integer_order']
assert sum(v << x for x, v in enumerate(bits)) == witness['full_truth_table_integer']
assert all(bits[x] == int(x in pos) for x in pos | neg)
family = minimal_hitting_sets(witness['full_truth_table_integer'], 7)
ratios = []
for row, (lab, vector) in zip(witness['source_full_certificate_comparison'], worlds):
    x = to_int(vector)
    best = min(cost(s) for s in family[x])
    assert row['input'] == x and row['label'] == lab
    assert row['promise_cost'] == pprices[x] and row['full_cost'] == best
    assert cost(row['one_minimum_full_certificate']) == best
    assert all(row['one_minimum_full_certificate'] & (x ^ y) for y in range(128) if bits[x] != bits[y])
    ratio = F(best, pprices[x])
    assert str(ratio) == row['ratio'] and ratio <= 2
    ratios.append(str(ratio))
assert max(map(F, ratios)) == 2

result = {
    'status': 'PASS_SEPARATE_FULL_CERTIFICATE_AND_SHARP_POINTWISE_COMPLETION_OBSTRUCTIONS',
    'protocol_sha256': psha, 'post_cap_amendment_sha256': amsha,
    'full_certificate_result_sha256': rosha, 'pointwise_analytic_result_sha256': pwsha,
    'independent_three_variable_truth_tables_scanned': 256, 'three_essential_RO_truth_functions': 64,
    'symbolic_certificate_type_counts': histogram,
    'all_nonnegative_price_RO_minimum_maximum_full_certificate': 'max(c0+c1,c0+c2,c1+c2)',
    'all_size_proof': 'Forced essential core; neutral restriction; full-certificate projection monotonicity; complete three-leaf symbolic classification. Finite checks alone are not an all-seven-formula census.',
    'at_core_prices_2_2_3': {'RO_minimum_maximum_full_certificate': '5', 'unrestricted_minimum_at_free_probe': '4',
        'unrestricted_positive_probe_upper': '4+epsilon', 'strict_comparison_interval': '0<=epsilon<1'},
    'pointwise_over_ALL_compatible_total_functions': {'free_probe_exact_minimum_max_ratio': '2',
        'lower_proof_three_worlds': abc, 'cheap_certificate_triples_with_opposite_label_full_subcube_collision': contradiction_cases,
        'explicit_attaining_full_truth_table_checked_on_all128inputs': True, 'actual_source_ratio_vector': ratios,
        'positive_probe_lower': '2/(1+epsilon)for0<=epsilon<1', 'positive_price_lossless_transfer_impossible': True,
        'exact_positive_probe_optimum_computed': False},
    'secondary_formula_DP': {'status': probe['status'], 'cap_overshoot_retained_vectors': 64, 'used_as_theorem_premise': False,
        'larger_retry_performed': False, 'old_failure_retained': True},
    'distinct_transfer_quantifiers_kept': True,
    'not_excluded': ['Maximum-full-certificate bridge using a suitable unrestricted completion and legal priority certificate policy',
                     'Source-aware classical algorithms and other cost-preserving reductions', 'Bounds sharper than the product of a uniform pointwise alpha and rho'],
    'V09_edited': False, 'P1_changed': False, 'new_model_API_calls': 0,
    'human_review': False, 'proof_assistant_kernel': False, 'literature_priority_established': False}
import argparse
parser = argparse.ArgumentParser()
parser.add_argument('--out', required=True)
out = Path(parser.parse_args().out)
assert not out.exists()
out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': result['status'], 'RO_full_certificate_minimum': '5',
                  'general_full_certificate_minimum_at_free_probe': '4', 'general_pointwise_inflation': '2',
                  'opposite_cube_collisions_checked': contradiction_cases, 'capped_search_used_as_proof': False}), flush=True)
