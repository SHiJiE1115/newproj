"""New full-certificate objective; no randomized games are rerun."""
from collections import Counter
from functools import lru_cache
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PSHA = '1d4de4a832e575efe1d40ca44cb9eedbf39720e84d6448b1f848a4a61c295f81'
raw = (HERE / 'CERTIFICATE_TRANSFER_PROTOCOL_V01.json').read_bytes()
assert hashlib.sha256(raw).hexdigest() == PSHA
p = json.loads(raw)


def value(formula, x):
    if len(formula) == 2:
        q, negated = formula
        return ((x >> q) & 1) ^ int(negated)
    gate, left, right = formula
    a, b = value(left, x), value(right, x)
    return a & b if gate == 'AND' else a | b


@lru_cache(None)
def ro_functions(subset):
    if subset.bit_count() == 1:
        q = subset.bit_length() - 1
        return {sum(value([q, sign], x) << x for x in range(8)): [q, sign] for sign in (False, True)}
    found = {}
    left = (subset - 1) & subset
    while left:
        right = subset ^ left
        if right and left & (subset & -subset):
            for a, ta in ro_functions(left).items():
                for b, tb in ro_functions(right).items():
                    found.setdefault(a & b, ['AND', ta, tb])
                    found.setdefault(a | b, ['OR', ta, tb])
        left = (left - 1) & subset
    return found


def certificate_families(table, n):
    families = []
    for x in range(1 << n):
        valid = [s for s in range(1 << n) if all(((x ^ y) & s) or ((table >> x) & 1) == ((table >> y) & 1) for y in range(1 << n))]
        families.append([s for s in valid if not any(t != s and t & s == t for t in valid)])
    return families


rows, types = [], Counter()
functions = ro_functions(7)
assert len(functions) == 64
for table, tree in sorted(functions.items()):
    families = certificate_families(table, 3)
    if any(f == [7] for f in families):
        kind = 'sum_all_three_prices'
        assert all(all(s < 8 for s in f) for f in families)
        forcing = {'7': next(x for x, f in enumerate(families) if f == [7])}
    else:
        kind = 'maximum_of_three_pair_sums'
        assert all(all(s.bit_count() <= 2 for s in f) for f in families)
        forcing = {str(s): next(x for x, f in enumerate(families) if f == [s]) for s in (3, 5, 6)}
    types[kind] += 1
    costs = [min(sum((2, 2, 3)[q] for q in range(3) if s >> q & 1) for s in f) for f in families]
    assert max(costs) == (7 if kind == 'sum_all_three_prices' else 5)
    rows.append({'truth_table_integer': table, 'formula': tree, 'minimal_certificate_subsets_by_input': families,
                 'symbolic_maximum_full_certificate': kind, 'forced_subset_witness_inputs': forcing,
                 'certificate_costs_at_2_2_3': costs})
assert types == {'sum_all_three_prices': 16, 'maximum_of_three_pair_sums': 48}
worlds = p['source']
index = lambda v: sum(bit << q for q, bit in enumerate(v))
pos = {index(w['bits']) for w in worlds if w['label'] == 1}
neg = {index(w['bits']) for w in worlds if w['label'] == 0}
assert len(pos) == len(neg) == 8 and not pos & neg
pairs = [(2, 3, 0), (2, 0, 1), (127, 123, 2)]
for a, b, q in pairs:
    assert a in pos and b in neg and a ^ b == 1 << q
formula = p['attaining_RO_formula']
ro_table = sum(value(formula, x) << x for x in range(128))
assert all(((ro_table >> x) & 1) == int(x in pos) for x in pos | neg)
ro_families = certificate_families(ro_table, 7)
assert all(all(s & ~7 == 0 for s in f) for f in ro_families)
assert all(all(s.bit_count() <= 2 for s in f) for f in ro_families)
assert all(any(f == [s] for f in ro_families) for s in (3, 5, 6))


def evaluate_tree(tree, x):
    node, purchased = tree, 0
    while isinstance(node, list):
        q = node[0]
        assert not purchased >> q & 1
        purchased |= 1 << q
        node = node[1 + ((x >> q) & 1)]
    return node, purchased


trace = [evaluate_tree(p['inherited_adaptive_tree'], x) for x in range(128)]
assert all(trace[x][0] == int(x in pos) for x in pos | neg)
adaptive_table = sum(label << x for x, (label, _) in enumerate(trace))
adaptive_families = certificate_families(adaptive_table, 7)
prices = (2, 2, 3, 0, 1, 1, 1)
cost = lambda s: sum(prices[q] for q in range(7) if s >> q & 1)
ro_costs = [min(map(cost, f)) for f in ro_families]
ad_costs = [min(map(cost, f)) for f in adaptive_families]
assert max(ro_costs) == 5 and max(ad_costs) == max(cost(s) for _, s in trace) == 4
assert all(cost(s) <= 4 for _, s in trace)
assert 3 in [s & ~8 for _, s in trace]
result = {
    'status': 'PRODUCER_FULL_CERTIFICATE_RO_BARRIER_PENDING_SEPARATE_VERIFICATION', 'protocol_sha256': PSHA,
    'core_rows': rows, 'three_essential_RO_functions': len(rows), 'symbolic_type_histogram': dict(types),
    'full_source_forced_essential_pairs': [{'A_input': a, 'B_input': b, 'only_difference': q} for a, b, q in pairs],
    'all_nonnegative_price_minimum_over_compatible_RO': 'max(c0+c1,c0+c2,c1+c2)',
    'all_size_proof_dependencies': ['Neutral restrictions retain nominated essential leaves', 'Restriction cannot increase maximum certificate cost', 'Three-leaf full-certificate classification'],
    'attaining_RO': {'formula': formula, 'full_truth_table_integer': ro_table,
                     'minimal_certificate_subsets_by_input': ro_families, 'full_certificate_costs_at_base': ro_costs,
                     'maximum_full_certificate_at_base': max(ro_costs)},
    'unrestricted_attaining_completion_at_free_probe': {
        'tree': p['inherited_adaptive_tree'], 'full_truth_table_integer': adaptive_table,
        'full_query_traces': [{'input': x, 'label': lab, 'purchased_subset': s} for x, (lab, s) in enumerate(trace)],
        'minimal_certificate_subsets_by_input': adaptive_families, 'full_certificate_costs_at_base': ad_costs,
        'maximum_full_certificate_at_base': max(ad_costs), 'full_query_cost_at_base': 4,
        'positive_probe_upper': '4+epsilon', 'cost_charges_probe_on_all_paths': True},
    'unrestricted_minimum_maximum_full_certificate_at_free_probe': '4',
    'RO_minimum_maximum_full_certificate_at_base': '5',
    'positive_probe_strict_barrier': '0<epsilon<1:ROminimum5>unrestrictedupper4+epsilon',
    'pointwise_promise_certificate_preservation': 'Separate secondary objective, not inferred here',
    'per_completion_randomized_optimization': False, 'new_model_API_calls': 0, 'human_review': False,
    'literature_priority_established': False}
out = HERE / 'FULL_CERTIFICATE_TRANSFER_RESULT_V01.json'
assert not out.exists()
out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'status': result['status'], 'three_RO_functions': len(rows), 'symbolic_types': dict(types),
                  'RO_max_certificate_minimum': '5', 'unrestricted_max_certificate_minimum_at_free_probe': '4'}), flush=True)
