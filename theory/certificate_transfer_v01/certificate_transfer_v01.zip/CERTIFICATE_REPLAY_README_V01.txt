Private certificate-transfer comparison packet

Python3.10+ standard library; no network, API credentials, model calls or installations.
Extract the flat ZIP into any writable directory and run:
 python -I -X utf8 -B verify_certificate_transfer_portable_v01.py --out replay.json
The output must not already exist. Compare parsed JSON with
INDEPENDENT_CERTIFICATE_TRANSFER_V01.json; the actual relocated Windows run
also compares bytes. The portable change only adds an output argument.

The verifier independently classifies three-essential-variable read-once
functions by scanning256truth tables/cofactors, uses opposite-input hitting
sets for certificates, checks complete128-input truth tables, and checks all48
cheap certificate triples behind the universal three-world lower. It imports
no mathematical producer functions. Parent manuscript paths in the protocol
are provenance metadata only; the replay does not need access to them.

The original capped formula-DP is retained for provenance and is not rerun
by this replay. UNKNOWN_RESOURCE_CAPPED is not evidence of absence. Its
64-vector cap overshoot is explicitly recorded in the analytic amendment.
The independent verifier proves the separate analytic route and explicit
attaining function. It does not certify a proof-assistant kernel or human
author review. Read the proof note for the all-size restriction argument.

Quantifiers: minimum maximum full-cube certificate cost for read-once
completions is the largest pair sum of core prices; unrestricted minimum at
free probe is4. Separately, minimum pointwise inflation across all total
completions is2at the free probe. Positive-probe inflation is only bounded
below by2/(1+epsilon); no exact positive-price optimum is claimed.

All material is private and not submitted. No literature-priority, general
completion-framework novelty, practical academic-evaluation or historical
authentication claim follows. Main manuscriptV09 remains unchanged.
