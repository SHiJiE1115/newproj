Public candidate: structural depth proof premises (R and C4), v01

This is a prepared public derivative, not a publication or execution receipt.
Python3.10+ standard library only; extract every member into one new directory:
  python -I -X utf8 -B verify.py --out-dir ../fresh-verification-output
The output directory must not exist and must be outside this package.
Do not use -O or -OO. Full acceptance requires64R cases and64C4 cases.
Expected checked totals are35244R proof nodes,562548R unit inferences and2331C4
unit inferences. Platform success must be established by an actual new run.

The input R producer status remains CHECKER_PENDING. All64case objects,
including timings and proofs, equal the original retained objects. The public
protocol retains its mathematical fields and replaces input pin locations
with paths relative to r/. Only explicitly listed local PID/history metadata
was removed. PUBLIC_LINEAGE.json and PUBLIC_CHECKER_BINDING_DIFF.patch identify
these changes without shipping old host paths, raw private copies or receipts.
Original encoder/solver/aux bytes are archival inputs, not regeneration commands.
Run only the top-level verify.py for the stated reproduction contract.

C4's seven files are unchanged. Read written/STRUCTURAL_DEPTH_THREE_PROOF_V01_EN.txt,
the two accompanying TeX files, r/AUXILIARY_PROOFS_V01_EN.txt, and the C4 written
derivations for the mathematics. The historical BASE identifiers in the long
note locate prior evidence conceptually; they are not dependencies opened by
this runner. Current bytes are bound by MANIFEST.json. Private historical
verification receipts are deliberately absent and cannot substitute for a new run.

The runner uses package files and a chosen output directory. No API, network,
credentials, old machine directory or installed third-party library is needed.
Package hashes check identity, not an external signature or authorship. The
written coverage/encoding/gluing arguments are not proof-assistant formalized.
This package does not replay the depth-four witness, B5 or the six-query catalogue,
prove application benefit or exhaustive literature priority, or imply human review.
No blanket project licence, author declaration or journal submission is asserted.
