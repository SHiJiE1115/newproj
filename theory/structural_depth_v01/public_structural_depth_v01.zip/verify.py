"""Replay the unchanged R and C4 premises from this extracted package.

Python 3.10+ standard library only. This checks finite proof premises;
the accompanying written reductions are not proof-assistant formalized.
"""
from pathlib import Path, PurePosixPath
import argparse
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
if sys.flags.optimize:
    raise RuntimeError('Assertions must remain enabled; do not use -O/-OO')

def read(p):
    if p.stat().st_size>48*1024*1024: raise ValueError('INPUT_TOO_LARGE')
    return json.loads(p.read_bytes())

def pin(p):
    data=p.read_bytes()
    return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

def save(p,value):
    with p.open('x',encoding='utf-8') as f:
        json.dump(value,f,ensure_ascii=False,indent=2); f.write('\n')

def verify_manifest():
    m=read(HERE/'MANIFEST.json')
    names=[]
    for row in m['files']:
        name=row['name']; q=PurePosixPath(name)
        if not name or q.is_absolute() or '..' in q.parts or ':' in name or '\\' in name:
            raise ValueError('UNSAFE_MEMBER:'+str(name))
        path=HERE.joinpath(*q.parts)
        if not path.resolve().is_relative_to(HERE) or path.is_symlink():
            raise ValueError('UNSAFE_RESOLVED_MEMBER:'+name)
        for parent in path.parents:
            if parent==HERE: break
            if parent.is_symlink(): raise ValueError('SYMLINK_MEMBER:'+name)
        names.append(name)
        if not path.is_file(): raise ValueError('MISSING_MEMBER:'+name)
        actual=pin(path)
        if actual['bytes']!=row['bytes'] or actual['sha256']!=row['sha256']:
            raise ValueError('INPUT_HASH_MISMATCH:'+name)
    if len(set(n.casefold() for n in names))!=len(names): raise ValueError('DUPLICATE_MEMBER')
    actual={p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file()}
    if actual!=set(names)|{'MANIFEST.json'}: raise ValueError('UNEXPECTED_MEMBER_SET')
    return m

def run_child(label,script,outdir,extra=()):
    command=[sys.executable,'-I','-X','utf8','-B',str(script),*map(str,extra)]
    stdout=outdir/(label+'.stdout.txt'); stderr=outdir/(label+'.stderr.txt')
    started=time.monotonic()
    with stdout.open('xb') as so,stderr.open('xb') as se:
        proc=subprocess.Popen(command,cwd=HERE,stdin=subprocess.DEVNULL,stdout=so,stderr=se,
            env={**os.environ,'TEMP':str(outdir),'TMP':str(outdir),'TMPDIR':str(outdir),'PYTHONDONTWRITEBYTECODE':'1'})
        save(outdir/(label+'.PROCESS_START.json'),{'pid':proc.pid,'command':command,'script':pin(script),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
        timed=False
        try: proc.wait(timeout=220)
        except subprocess.TimeoutExpired:
            timed=True; proc.kill(); proc.wait()
        receipt={'pid':proc.pid,'actual_exit_code':proc.returncode,'timed_out':timed,
            'wall_seconds':time.monotonic()-started,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'retained_Popen_wait':True,'stdout':pin(stdout),'stderr':pin(stderr)}
        save(outdir/(label+'.PROCESS_TERMINAL.json'),receipt)
    if timed or proc.returncode!=0: raise RuntimeError('CHILD_FAILED:'+label)
    return receipt

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out-dir',required=True,type=Path)
    args=parser.parse_args()
    out=args.out_dir.resolve()
    if out==HERE or out.is_relative_to(HERE): raise ValueError('OUTPUT_MUST_BE_OUTSIDE_PACKAGE')
    manifest=verify_manifest()
    # Whole-package acceptance is deliberately stricter than the old checker's
    # legitimate partial/countermodel reports. All frozen premises are required.
    r=read(HERE/'r/RECIPROCAL_RESULT_V01.json')
    if len(r['cases'])!=64 or r['attempted']!=64 or r['not_attempted']!=[]:
        raise ValueError('COVERAGE_ERROR_R_CASE_COUNT')
    out.mkdir(parents=True,exist_ok=False)
    rr=out/'R_INDEPENDENT_RESULT.json'
    r_receipt=run_child('R',HERE/'r/verify_reciprocal_portable_v01.py',out,('--out',rr))
    checked=read(rr)
    if not (checked['status']=='PASS_ALL64_REBUILT_AXIOMS_AND_COMPLETE_UNSAT_DERIVATIONS_LOCAL_R_ONLY'
            and checked['attempted']==64 and checked['verified_UNSAT_cases']==64
            and checked['all64_UNSAT_verified'] is True and checked['verified_SAT_countermodel'] is False
            and checked['open_case_ids']==[] and checked['not_attempted']==[]
            and checked['verified_proof_nodes']==35244 and checked['verified_unit_inferences']==562548):
        raise ValueError('R_COMPLETE_PROOF_REQUIREMENTS_NOT_MET')
    c_receipt=run_child('C4',HERE/'c4/verify.py',out)
    lines=(out/'C4.stdout.txt').read_text(encoding='utf-8').splitlines()
    c=json.loads(lines[-1])
    if not (c['status']=='PASS_PORTABLE_STRUCTURAL_PROOF' and c['cases']==64
            and c['unit_steps']==2331 and c['witness_splits']==0):
        raise ValueError('C4_COMPLETE_PROOF_REQUIREMENTS_NOT_MET')
    verify_manifest()  # Executed sources and proof bytes stayed unchanged.
    answer={'status':'PASS_RELOCATED_R64_AND_C4_64_STRUCTURAL_PREMISES',
        'actual_pid':os.getpid(),'python':sys.version,'platform':sys.platform,'package_manifest':pin(HERE/'MANIFEST.json'),
        'R':{'cases':64,'proof_nodes':35244,'unit_steps':562548,'result':pin(rr),'receipt':r_receipt},
        'C4':{'cases':64,'unit_steps':2331,'result':c,'receipt':c_receipt},
        'scope':'Finite R and C4 premises only; written coverage/encoding/gluing remains a separate mathematical argument. Not D2/fixed-seven or B5/six-query replay.',
        'historical_paths_opened':False,'new_theorem':False,'new_model_API_calls':0,'human_review':False,
        'proof_assistant_formalization':False,'whole_project_complete':False}
    save(out/'RESULT.json',answer)
    print(json.dumps({'status':answer['status'],'R_cases':64,'C4_cases':64,'output':str(out/'RESULT.json')}))

if __name__=='__main__': main()
