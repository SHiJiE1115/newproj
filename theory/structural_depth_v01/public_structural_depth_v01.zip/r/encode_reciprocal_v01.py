"""Exact full-parent AND/S and false-R formulas; no model data lookup."""
import itertools

PAIRS=tuple(itertools.combinations(range(5),2))
AFFORDABLE=((1,2),(1,3),(2,4)) # q,p,r,u,v are bits0,1,2,3,4

class Formula:
 def __init__(self):self.variables=[];self.ids={};self.clauses=[];self.seen=set()
 def var(self,*name):
  if name not in self.ids:self.ids[name]=len(self.variables)+1;self.variables.append(list(name))
  return self.ids[name]
 def add(self,*literals):
  s=set(literals)
  if any(-x in s for x in s):return
  c=tuple(sorted(s,key=lambda x:(abs(x),x)))
  if c not in self.seen:self.seen.add(c);self.clauses.append(list(c))
 def OR(self,v,terms):
  self.add(-v,*terms)
  for x in terms:self.add(-x,v)
 def AND(self,v,terms):
  for x in terms:self.add(-v,x)
  self.add(v,*[-x for x in terms])

def parameters():
 return [{'cross_at_p':a,'cross_at_r':b,'orientations':list(o)} for a,b in itertools.product(range(2),repeat=2) for o in itertools.product(range(2),repeat=4)]

def leaf_and_label(word,par):
 q=word&1
 child=(word>>(1 if q==0 else 2))&1
 last=(2 if child==par['cross_at_p'] else 3) if q==0 else (1 if child==par['cross_at_r'] else 4)
 answer=(word>>last)&1
 return (q,child,answer),answer^par['orientations'][2*q+child]

def build(par):
 f=Formula();m={(h,w):f.var('M',h,w) for h in range(2) for w in range(32)}
 for h in range(2):
  f.add(*[m[h,w] for w in range(32)])
  for a in range(32):
   for b in range(a,32):f.add(-m[h,a],-m[h,b],m[h,a&b])
  for i,j in PAIRS:
   atoms=[]
   for code in range(4):
    v=f.var('P',h,i,j,code);atoms.append(v)
    f.OR(v,[m[h,w] for w in range(32) if ((w>>i)&1)+2*((w>>j)&1)==code])
   e00,e10,e01,e11=atoms
   f.add(-e00,-e11,-e01,e10);f.add(-e00,-e11,-e10,e01)
 for w in range(32):f.add(-m[0,w],-m[1,w])
 leaves={k:[] for k in itertools.product(range(2),repeat=3)}
 for w in range(32):
  leaf,h=leaf_and_label(w,par);f.add(-m[1-h,w]);leaves[leaf].append(m[h,w])
 for leaf in sorted(leaves):
  assert len(leaves[leaf])==4;f.add(*leaves[leaf])
 collisions={}
 for b in range(2):
  for i,j in AFFORDABLE:
   cs=[]
   for code in range(4):
    atoms=[]
    for h in range(2):
     v=f.var('X',h,b,i,j,code);atoms.append(v)
     f.OR(v,[m[h,w] for w in range(32) if w&1==b and ((w>>i)&1)+2*((w>>j)&1)==code])
    c=f.var('C',b,i,j,code);f.AND(c,atoms);cs.append(c);collisions[b,i,j,code]=c
   f.add(*cs) # no fixed separator, for every maximal affordable pair
 for b,root,others in [(0,2,(1,4)),(1,1,(2,3))]:
  bads=[]
  for answer in range(2):
   failures=[]
   for nxt in others:
    i,j=sorted((root,nxt));codes=[c for c in range(4) if ((c>>(0 if root==i else 1))&1)==answer]
    v=f.var('F',b,root,answer,nxt);f.OR(v,[collisions[b,i,j,c] for c in codes]);failures.append(v)
   v=f.var('B',b,root,answer);f.AND(v,failures);bads.append(v)
  f.add(*bads) # some root-answer face defeats both allowable second queries
 return f
