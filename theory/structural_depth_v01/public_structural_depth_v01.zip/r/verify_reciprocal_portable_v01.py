"""Independent axiom/proof/model check for the frozen reciprocal-tree task.

No production module is imported. SAT semantics are checked from support sets;
UNSAT requires every saved unit inference and both branches of every split.
"""
from pathlib import Path, PurePosixPath
from functools import lru_cache
import argparse
import datetime
import hashlib
import itertools
import json
import os
import sys
import time

HERE = Path(__file__).resolve().parent
START = time.monotonic()
MAX_BYTES = 48 * 1024 * 1024
if sys.flags.optimize:
    raise RuntimeError("Assertions must remain enabled; do not use -O/-OO")


def tick():
    if time.monotonic() - START > 210:
        raise TimeoutError("Independent checking exceeded its 210-second bound")


def load(path, bound=MAX_BYTES):
    if path.stat().st_size > bound:
        raise ValueError("Input exceeds bounded reader: " + str(path))
    return json.loads(path.read_bytes())


def pin(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def json_digest(value):
    data = json.dumps(value, separators=(",", ":")).encode()
    return hashlib.sha256(data).hexdigest()


def require_int(value, lower, upper):
    assert type(value) is int and lower <= value <= upper
    return value


ALL_WORDS = tuple(range(32))
LABELS = (0, 1)
PAIRS = tuple(itertools.combinations(range(5), 2))
MAXIMAL = ((1, 2), (1, 3), (2, 4))
MAX_MASKS = (6, 10, 20)
BAD_ROOTS = ((0, 2, (1, 4)), (1, 1, (2, 3)))
EXPECTED_PARAMETERS = []
for first_cross in (0, 1):
    for second_cross in (0, 1):
        for number in range(16):
            EXPECTED_PARAMETERS.append({
                "cross_at_p": first_cross, "cross_at_r": second_cross,
                "orientations": [(number >> bit) & 1 for bit in (3, 2, 1, 0)]})


def expected_names():
    names = {("M", h, w) for h in LABELS for w in ALL_WORDS}
    names |= {("P", h, i, j, code) for h in LABELS for i, j in PAIRS
              for code in range(4)}
    names |= {("X", h, face, i, j, code) for h in LABELS for face in LABELS
              for i, j in MAXIMAL for code in range(4)}
    names |= {("C", face, i, j, code) for face in LABELS for i, j in MAXIMAL
              for code in range(4)}
    for face, root, neighbours in BAD_ROOTS:
        for answer in LABELS:
            names.add(("B", face, root, answer))
            for nxt in neighbours:
                names.add(("F", face, root, answer, nxt))
    return names


EXPECTED_NAMES = expected_names()
assert len(EXPECTED_NAMES) == 228


def tree_evaluation(word, parameters):
    bits = [(word >> index) & 1 for index in range(5)]
    face = bits[0]
    second_index = (1, 2)[face]
    second_answer = bits[second_index]
    crossed_at = (parameters["cross_at_p"], parameters["cross_at_r"])[face]
    cross_index, private_index = ((2, 3), (1, 4))[face]
    last_index = cross_index if second_answer == crossed_at else private_index
    last_answer = bits[last_index]
    label = last_answer ^ parameters["orientations"][2 * face + second_answer]
    return (face, second_answer, last_answer), label, (0, second_index, last_index)


def rebuild_axioms(variables, parameters):
    assert type(variables) is list and len(variables) == 228
    for name in variables:
        assert type(name) is list and name and type(name[0]) is str
        assert all(type(item) is int for item in name[1:])
    named = [tuple(name) for name in variables]
    assert len(set(named)) == len(named) and set(named) == EXPECTED_NAMES
    # The support list exported by production uses these 0-based model slots.
    assert named[:64] == [("M", h, w) for h in LABELS for w in ALL_WORDS]
    ids = {name: index + 1 for index, name in enumerate(named)}
    axioms = set()

    def add(values):
        clause = frozenset(values)
        if not any(-literal in clause for literal in clause):
            axioms.add(clause)

    def equivalent_or(name, members):
        head = ids[name]
        add([-head] + members)
        for member in members:
            add([head, -member])

    def equivalent_and(name, factors):
        head = ids[name]
        add([head] + [-factor for factor in factors])
        for factor in factors:
            add([-head, factor])

    for h in LABELS:
        add([ids["M", h, w] for w in ALL_WORDS])
        for a, b in itertools.combinations_with_replacement(ALL_WORDS, 2):
            add([-ids["M", h, a], -ids["M", h, b], ids["M", h, a & b]])
        for i, j in PAIRS:
            for left, right in itertools.product(LABELS, repeat=2):
                code = left + 2 * right
                selected = [ids["M", h, w] for w in ALL_WORDS
                            if (w >> i) & 1 == left and (w >> j) & 1 == right]
                equivalent_or(("P", h, i, j, code), selected)
            p00, p10, p01, p11 = [ids["P", h, i, j, c] for c in range(4)]
            add([-p00, -p11, p10, -p01])
            add([-p00, -p11, p01, -p10])
    for word in ALL_WORDS:
        add([-ids["M", 0, word], -ids["M", 1, word]])

    leaf_members = {leaf: [] for leaf in itertools.product(LABELS, repeat=3)}
    for word in ALL_WORDS:
        leaf, correct_label, _ = tree_evaluation(word, parameters)
        add([-ids["M", 1 - correct_label, word]])
        leaf_members[leaf].append(ids["M", correct_label, word])
    assert all(len(members) == 4 for members in leaf_members.values())
    for members in leaf_members.values():
        add(members)

    for face in LABELS:
        for i, j in MAXIMAL:
            for code in range(4):
                for h in LABELS:
                    selected = [ids["M", h, w] for w in ALL_WORDS
                                if w % 2 == face and (w >> i) & 1 == code % 2
                                and (w >> j) & 1 == code // 2]
                    equivalent_or(("X", h, face, i, j, code), selected)
                equivalent_and(("C", face, i, j, code),
                               [ids["X", h, face, i, j, code] for h in LABELS])
            add([ids["C", face, i, j, code] for code in range(4)])
    for face, root, neighbours in BAD_ROOTS:
        for answer in LABELS:
            for nxt in neighbours:
                ordered_pair = tuple(sorted((root, nxt)))
                codes = []
                for other_answer in LABELS:
                    bit_values = {root: answer, nxt: other_answer}
                    code = bit_values[ordered_pair[0]] + 2 * bit_values[ordered_pair[1]]
                    codes.append(ids[("C", face) + ordered_pair + (code,)])
                equivalent_or(("F", face, root, answer, nxt), codes)
            equivalent_and(("B", face, root, answer),
                           [ids["F", face, root, answer, nxt] for nxt in neighbours])
        add([ids["B", face, root, answer] for answer in LABELS])
    return axioms


def validate_clause_list(row, axioms):
    clauses = row["clauses"]
    assert type(clauses) is list and clauses
    for clause in clauses:
        assert type(clause) is list
        assert all(type(lit) is int and lit != 0 and abs(lit) <= 228 for lit in clause)
        assert len(set(clause)) == len(clause)
        assert not any(-lit in clause for lit in clause)
    assert len({frozenset(clause) for clause in clauses}) == len(clauses)
    assert {frozenset(clause) for clause in clauses} == axioms
    assert json_digest(clauses) == row["CNF_sha256"]
    return clauses


def check_unsat_proof(proof, clauses):
    counts = {"nodes": 0, "unit_steps": 0, "splits": 0, "conflict_leaves": 0}

    def visit(node, inherited):
        tick()
        assert type(node) is dict
        kind = node["kind"]
        if kind == "CONFLICT":
            assert set(node) == {"kind", "units", "clause"}
        else:
            assert kind == "SPLIT"
            assert set(node) == {"kind", "units", "split", "positive", "negative"}
        counts["nodes"] += 1
        assert counts["nodes"] <= 200000
        assigned = dict(inherited)
        assert type(node["units"]) is list
        for step in node["units"]:
            assert type(step) is list and len(step) == 2
            literal, reason = step
            require_int(literal, -228, 228)
            assert literal != 0 and abs(literal) not in assigned
            require_int(reason, 0, len(clauses) - 1)
            clause = clauses[reason]
            assert literal in clause
            for other in clause:
                if other != literal:
                    assert abs(other) in assigned and assigned[abs(other)] != (other > 0)
            assigned[abs(literal)] = literal > 0
            counts["unit_steps"] += 1
        if kind == "CONFLICT":
            reason = require_int(node["clause"], 0, len(clauses) - 1)
            assert all(abs(lit) in assigned and assigned[abs(lit)] != (lit > 0)
                       for lit in clauses[reason])
            counts["conflict_leaves"] += 1
            return
        variable = require_int(node["split"], 1, 228)
        assert variable not in assigned
        counts["splits"] += 1
        visit(node["positive"], {**assigned, variable: True})
        visit(node["negative"], {**assigned, variable: False})

    visit(proof, {})
    assert counts["conflict_leaves"] == counts["splits"] + 1
    return counts


def check_countermodel(row, clauses):
    model = row["model"]
    assert type(model) is list and len(model) == 228 and all(type(v) is bool for v in model)
    assert all(any(model[abs(lit) - 1] == (lit > 0) for lit in c) for c in clauses)
    supports = row["supports"]
    assert type(supports) is list and len(supports) == 2
    assert supports == [[w for w in ALL_WORDS if model[h * 32 + w]] for h in LABELS]
    worlds = [set(supports[h]) for h in LABELS]
    assert all(worlds) and not worlds[0] & worlds[1]
    for h in LABELS:
        assert all((a & b) in worlds[h] for a in worlds[h] for b in worlds[h])
        for i, j in PAIRS:
            projection = {((w >> i) & 1, (w >> j) & 1) for w in worlds[h]}
            if (0, 0) in projection and (1, 1) in projection:
                assert ((1, 0) in projection) == ((0, 1) in projection)
    reached = set()
    masks = set()
    for h in LABELS:
        for word in worlds[h]:
            leaf, predicted, queries = tree_evaluation(word, row["parameters"])
            assert predicted == h and len(queries) == len(set(queries)) == 3
            reached.add(leaf)
            masks.add(sum(1 << q for q in queries))
    assert reached == set(itertools.product(LABELS, repeat=3))
    assert masks == {7, 11, 21}

    def separator(subtask, coordinates):
        projections = [{tuple((word >> q) & 1 for q in coordinates)
                        for label, word in subtask if label == h} for h in LABELS]
        return not projections[0] & projections[1]

    face_tasks = [tuple((h, w) for h in LABELS for w in sorted(worlds[h]) if w % 2 == b)
                  for b in LABELS]
    collision_checks = []
    for face in LABELS:
        for pair in MAXIMAL:
            assert not separator(face_tasks[face], pair)
            collision_checks.append({"face": face, "pair": list(pair), "collision": True})
    bad_answers = []
    for face, root, neighbours in BAD_ROOTS:
        bad = []
        for answer in LABELS:
            subtask = tuple((h, w) for h, w in face_tasks[face] if (w >> root) & 1 == answer)
            if all(not separator(subtask, (nxt,)) for nxt in neighbours):
                bad.append(answer)
        assert bad
        bad_answers.append({"face": face, "root": root, "bad_answers": bad})

    def ordered_feasible(task, order):
        @lru_cache(None)
        def continue_at(position, compatible, bought):
            tick()
            if len({h for h, _ in compatible}) <= 1:
                return True
            if position == len(order):
                return False
            if continue_at(position + 1, compatible, bought):
                return True
            query = order[position]
            new_bought = bought | (1 << query)
            if not any((new_bought & maximum) == new_bought for maximum in MAX_MASKS):
                return False
            children = [tuple((h, w) for h, w in compatible if (w >> query) & 1 == answer)
                        for answer in LABELS]
            return all(continue_at(position + 1, child, new_bought) for child in children)
        return continue_at(0, task, 0)

    order_checks = []
    for order in itertools.permutations((1, 2, 3, 4)):
        values = [ordered_feasible(task, order) for task in face_tasks]
        order_checks.append({"order": list(order), "face_feasible": values,
                             "common_feasible": all(values)})
    assert len(order_checks) == 24 and not any(x["common_feasible"] for x in order_checks)
    return {"supports": supports, "parent_AND_and_S_checked": True,
            "S_imposed_on_conditional_faces": False, "eight_nonempty_leaves_checked": True,
            "parent_envelope_masks": sorted(masks), "no_fixed_separator": collision_checks,
            "opposite_root_obstructions": bad_answers, "all24_suffix_orders": order_checks,
            "all24_common_orders_infeasible": True,
            "physical_complete_fibre_realizability_established": False,
            "all120_orders_allowing_q_elsewhere_checked": False}


def package_path(member):
    # Public input pins use canonical POSIX paths relative to this r directory.
    if type(member) is not str or not member:
        raise ValueError("INVALID_PACKAGE_MEMBER")
    q = PurePosixPath(member)
    if (q.is_absolute() or q.as_posix() != member or ".." in q.parts
            or ":" in member or "\\" in member or member in (".", "..")):
        raise ValueError("UNSAFE_PACKAGE_MEMBER:" + member)
    current = HERE
    for part in q.parts:
        current = current / part
        if current.is_symlink():
            raise ValueError("SYMLINK_PACKAGE_MEMBER:" + member)
    if not current.resolve().is_relative_to(HERE) or not current.is_file():
        raise ValueError("MISSING_OR_EXTERNAL_PACKAGE_MEMBER:" + member)
    return current


def check_relative_pin(record):
    if type(record) is not dict or set(record) != {"path", "bytes", "sha256"}:
        raise ValueError("INVALID_RELATIVE_PIN")
    actual = pin(package_path(record["path"]))
    assert actual["bytes"] == record["bytes"] and actual["sha256"] == record["sha256"]
    return actual



def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--result", type=str, default="RECIPROCAL_RESULT_V01.json")
    parser.add_argument("--out", type=Path, default=HERE / "RECIPROCAL_INDEPENDENT_CHECK_V01.json")
    args = parser.parse_args()
    output = args.out
    if output.exists():
        raise FileExistsError("Refuse to overwrite independent result")
    protocol_path = package_path("FROZEN_RECIPROCAL_PROTOCOL_V01.json")
    result_path = package_path(args.result)
    protocol = load(protocol_path, 1024 * 1024)
    result = load(result_path)
    check_relative_pin(result["frozen_protocol"])
    assert protocol["parameters"] == EXPECTED_PARAMETERS
    assert protocol["S_on_conditional_faces"] is False and protocol["q_is_paid"] is True
    assert protocol["J_maximal_masks_without_q"] == list(MAX_MASKS)
    assert protocol["parent_envelope_masks"] == [7, 11, 21]
    for record in protocol["code_pins"]:
        check_relative_pin(record)
    check_relative_pin(protocol["written_auxiliary_proofs"])
    rows = result["cases"]
    assert type(rows) is list and 1 <= len(rows) <= 64
    assert result["attempted"] == len(rows)
    assert result["not_attempted"] == list(range(len(rows), 64))
    checked = []
    total_nodes = total_units = 0
    complete_unsat = 0
    sat_found = False
    open_ids = []
    for index, row in enumerate(rows):
        tick()
        assert row["id"] == index and row["parameters"] == EXPECTED_PARAMETERS[index]
        axioms = rebuild_axioms(row["variables"], row["parameters"])
        clauses = validate_clause_list(row, axioms)
        item = {"id": index, "status": row["status"], "variable_registry_checked": True,
                "independently_rebuilt_clause_count": len(axioms), "CNF_sha256": row["CNF_sha256"]}
        if row["status"] == "UNSAT_DERIVATION_CHECKER_PENDING":
            counts = check_unsat_proof(row["proof"], clauses)
            assert counts["nodes"] == row["DPLL_nodes"]
            item["verified_derivation"] = counts
            complete_unsat += 1
            total_nodes += counts["nodes"]
            total_units += counts["unit_steps"]
        elif row["status"] == "SAT_COUNTERMODEL_CHECKER_PENDING":
            assert index == len(rows) - 1
            item["independent_semantic_check"] = check_countermodel(row, clauses)
            sat_found = True
        else:
            assert row["status"] in ("OPEN_RESOURCE_BOUND", "OPEN_OUTPUT_BOUND")
            assert index == len(rows) - 1 and type(row["reason"]) is str
            open_ids.append(index)
            item["proof_complete"] = False
            item["reason"] = row["reason"]
        checked.append(item)
    assert result["DPLL_nodes"] == sum(row["DPLL_nodes"] for row in rows)
    all_closed = complete_unsat == 64
    if all_closed:
        assert result["status"] == "ALL64_UNSAT_CHECKER_PENDING"
        assert total_nodes == result["DPLL_nodes"] and total_units == result["unit_steps_generated"]
        status = "PASS_ALL64_REBUILT_AXIOMS_AND_COMPLETE_UNSAT_DERIVATIONS_LOCAL_R_ONLY"
    elif sat_found:
        assert result["status"] == "COUNTERMODEL_TO_AND_S_STRENGTHENING_CHECKER_PENDING"
        status = "PASS_VERIFIED_COUNTERMODEL_TO_AND_S_STRENGTHENING_ONLY"
    else:
        assert open_ids and result["status"] == "PARTIAL_RETAIN_OPEN"
        status = "PASS_CHECKED_COMPLETED_PREFIX_PARTIAL_TASK_REMAINS_OPEN"
    answer = {"schema": 1, "status": status, "actual_pid": os.getpid(),
              "checked_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "checker": pin(Path(__file__)), "production_result": pin(result_path),
              "frozen_protocol": pin(protocol_path), "attempted": len(rows),
              "verified_UNSAT_cases": complete_unsat, "verified_SAT_countermodel": sat_found,
              "open_case_ids": open_ids, "not_attempted": result["not_attempted"],
              "all64_UNSAT_verified": all_closed, "verified_proof_nodes": total_nodes,
              "verified_unit_inferences": total_units, "cases": checked,
              "imports_production_encoder_or_solver": False,
              "written_coverage_and_gluing_formally_verified": False,
              "scope": "Exact frozen parent-AND/S false-R propositional cases. A checked local proof still depends on the separately written template coverage, complete-fibre necessity and gluing argument. A SAT model does not establish physical realizability or refute D1/B5.",
              "S_imposed_on_conditioned_faces": False, "B5_removed_from_manuscript": False,
              "G6_proved": False, "new_model_API_calls": 0, "human_review": False,
              "whole_project_complete": False, "elapsed_seconds": time.monotonic() - START}
    encoded = json.dumps(answer, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    assert len(encoded.encode("utf-8")) < 1024 * 1024
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(encoded)
    print(json.dumps({"status": status, "verified_UNSAT_cases": complete_unsat,
                      "verified_SAT_countermodel": sat_found, "open_case_ids": open_ids,
                      "not_attempted_count": len(result["not_attempted"])}))


if __name__ == "__main__":
    main()
