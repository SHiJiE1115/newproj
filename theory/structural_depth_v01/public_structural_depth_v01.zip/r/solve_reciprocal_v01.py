"""One bounded DPLL attempt; preserve all exact derivations or first model."""
from pathlib import Path
import hashlib,json,os,sys,time
H=Path(__file__).resolve().parent;sys.path.insert(0,str(H))
from encode_reciprocal_v01 import build,parameters

def sha(b):return hashlib.sha256(b).hexdigest()
def serial(x):return json.dumps(x,separators=(',',':')).encode()
def pin(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
protocol=json.loads((H/'FROZEN_RECIPROCAL_PROTOCOL_V01.json').read_bytes())
for p in protocol['code_pins']:assert pin(p['path'])==p
started=time.monotonic();deadline=started+protocol['limits']['internal_seconds']
nodes=0;unit_count=0;cases=[];estimated=0
class Budget(Exception):pass
def tick():
 if time.monotonic()>deadline or nodes>=protocol['limits']['max_DPLL_nodes']:raise Budget()

def solve(clauses,assigned):
 global nodes,unit_count
 tick();nodes+=1;units=[]
 while True:
  changed=False;unresolved=[]
  for idx,cl in enumerate(clauses):
   if idx%128==0:tick()
   pending=[];satisfied=False
   for lit in cl:
    val=assigned.get(abs(lit))
    if val is None:pending.append(lit)
    elif val==(lit>0):satisfied=True;break
   if satisfied:continue
   if not pending:return {'kind':'CONFLICT','units':units,'clause':idx},None
   if len(pending)==1:
    lit=pending[0];assigned[abs(lit)]=lit>0;units.append([lit,idx]);unit_count+=1;changed=True
   else:unresolved.append(pending)
  if not changed:break
 if not unresolved:return {'kind':'SAT','units':units},dict(assigned)
 # Deterministic shortest unresolved clause, then most frequent variable.
 freq={}
 for cl in unresolved:
  weight=1/(2**min(len(cl),12))
  for lit in cl:freq[abs(lit)]=freq.get(abs(lit),0)+weight
 short=min(unresolved,key=lambda c:(len(c),tuple(c)))
 split=max((abs(x) for x in short),key=lambda v:(freq[v],-v))
 pos,model=solve(clauses,{**assigned,split:True})
 if model is not None:return {'kind':'SAT_BRANCH','units':units,'split':split,'branch':True},model
 neg,model=solve(clauses,{**assigned,split:False})
 if model is not None:return {'kind':'SAT_BRANCH','units':units,'split':split,'branch':False},model
 return {'kind':'SPLIT','units':units,'split':split,'positive':pos,'negative':neg},None

outcome='ALL64_UNSAT_CHECKER_PENDING';reason=None
for idx,par in enumerate(parameters()):
 f=build(par);before=nodes;t=time.monotonic()
 row={'id':idx,'parameters':par,'variables':f.variables,'clauses':f.clauses,'CNF_sha256':sha(serial(f.clauses))}
 try:
  proof,model=solve(f.clauses,{})
  if model is not None:
   values=[bool(model.get(i,False)) for i in range(1,len(f.variables)+1)]
   assert all(any(values[abs(l)-1]==(l>0) for l in c) for c in f.clauses)
   row.update(status='SAT_COUNTERMODEL_CHECKER_PENDING',model=values,supports=[[w for w in range(32) if values[h*32+w]] for h in range(2)])
   outcome='COUNTERMODEL_TO_AND_S_STRENGTHENING_CHECKER_PENDING'
  else:row.update(status='UNSAT_DERIVATION_CHECKER_PENDING',proof=proof)
 except Budget:
  row.update(status='OPEN_RESOURCE_BOUND',reason='Time or DPLL node limit reached; not UNSAT')
  outcome='PARTIAL_RETAIN_OPEN';reason=row['reason']
 row.update(DPLL_nodes=nodes-before,elapsed_seconds=time.monotonic()-t)
 size=len(serial(row))
 if estimated+size>protocol['limits']['maximum_result_bytes']-1048576:
  row={k:v for k,v in row.items() if k not in ['proof','model']};row.update(status='OPEN_OUTPUT_BOUND',reason='Complete proof would exceed frozen output budget')
  outcome='PARTIAL_RETAIN_OPEN';reason=row['reason'];size=len(serial(row))
 cases.append(row);estimated+=size
 if outcome!='ALL64_UNSAT_CHECKER_PENDING':break
result={'status':outcome,'actual_pid':os.getpid(),'frozen_protocol':pin(H/'FROZEN_RECIPROCAL_PROTOCOL_V01.json'),'cases':cases,'attempted':len(cases),'not_attempted':list(range(len(cases),64)),'DPLL_nodes':nodes,'unit_steps_generated':unit_count,'elapsed_seconds':time.monotonic()-started,'reason':reason,'claim_scope':'AND+S falseR constraints only; no B5/source-catalogue lookup; proof still requires independent check and coverage argument','B5_removed_from_manuscript':False,'new_model_calls':0,'human_review':False,'whole_project_complete':False}
data=serial(result)+b'\n';assert len(data)<=protocol['limits']['maximum_result_bytes']
with (H/'RECIPROCAL_RESULT_V01.json').open('xb') as fp:fp.write(data)
print(json.dumps({'status':outcome,'cases':len(cases),'nodes':nodes,'bytes':len(data),'seconds':time.monotonic()-started}))
