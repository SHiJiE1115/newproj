"""Independently rebuild axioms and verify each literal-by-literal unit proof.

The handwritten mathematical template-coverage proof remains outside this
small propositional checker; no external human/kernel review is claimed.
"""
import itertools
import json
import os
import sys
from pathlib import Path
H=Path(__file__).resolve().parent
import hashlib
import time
START=time.monotonic()
def tick():
    assert time.monotonic()-START<210,'bounded verification exceeded'
def read(path):
    return json.loads(Path(path).read_bytes())
def digest(value):
    return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')).hexdigest()
expected={'verify.py','proof.json','template_derivation.txt','case_proof.txt','four_query_all_monotone.txt','README.txt'}
manifest=read(H/'manifest.json')
assert {row['name'] for row in manifest['files']}==expected
assert len(manifest['files'])==len(expected)
for row in manifest['files']:
    path=H/row['name']
    assert path.resolve().parent==H.resolve()
    data=path.read_bytes()
    assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
print('MANIFEST_OK',flush=True)


r=read(H/'proof.json')
word_var={(h,w):h*16+w+1 for h in [0,1] for w in range(16)}
pairs=tuple(itertools.combinations(range(4),2))
projection={(h,i,j,u,v):33+(h*6+pairs.index((i,j)))*4+u+2*v
            for h in [0,1] for i,j in pairs for u,v in itertools.product([0,1],repeat=2)}


def tidy(clause):
    values=frozenset(clause)
    return None if any(-value in values for value in values) else values


def base_axioms():
    result=set()
    def add(clause):
        clause=tidy(clause)
        if clause is not None:result.add(clause)
    for h in [0,1]:
        for a,b in itertools.combinations_with_replacement(range(16),2):
            add([-word_var[h,a],-word_var[h,b],word_var[h,a&b]])
        for i,j in pairs:
            for u,v in itertools.product([0,1],repeat=2):
                variable=projection[h,i,j,u,v]
                members=[word_var[h,w] for w in range(16) if ((w>>i)&1)==u and ((w>>j)&1)==v]
                add([-variable,*members])
                for m in members:add([-m,variable])
            p00,p10,p01,p11=(projection[h,i,j,u,v] for u,v in [(0,0),(1,0),(0,1),(1,1)])
            add([-p00,-p11,-p01,p10]);add([-p00,-p11,-p10,p01])
    for word in range(16):add([-word_var[0,word],-word_var[1,word]])
    return result


def template_axioms(name,coordinates,selector,flip):
    if name=='T':required=({0,3},{2,7});allowed=({0,1,3,4},{2,6,7})
    else:required=({7},{2,3,6});allowed=({0,4,5,7},{2,3,6})
    def atom(h,canonical_word):
        positions={coordinates[q] for q in range(3) if canonical_word&(1<<q)}
        actual=sum(1<<q for q in positions)+8*selector
        return word_var[h^flip,actual]
    axioms=set()
    for h in [0,1]:
        for w in required[h]:axioms.add(frozenset([atom(h,w)]))
        for w in set(range(8))-allowed[h]:axioms.add(frozenset([-atom(h,w)]))
    if name=='E':axioms.add(frozenset([atom(0,0),atom(0,4)]))
    return axioms,atom


expected_params=[]
for good in [0,1]:
 for family_a in ['T','E']:
  for root_b in [1,2]:
   for coordinates_b in sorted((root_b,)+remaining for remaining in itertools.permutations(sorted(set(range(3))-{root_b}))):
    for flip_b in [0,1]:
     for family_b in ['T','E']:
        expected_params.append({'good_selector_answer':good,'family_A':family_a,'root_B':root_b,
            'coordinates_B':list(coordinates_b),'flip_B':flip_b,'family_B':family_b})
assert len(expected_params)==64
base=base_axioms();total_units=0;cores=[]
for case,parameters in zip(r['cases'],expected_params):
    tick();assert case['id']==len(cores) and case['parameters']==parameters
    axioms=set(base)
    aa,_=template_axioms(parameters['family_A'],(0,1,2),parameters['good_selector_answer'],0)
    bb,atom_b=template_axioms(parameters['family_B'],tuple(parameters['coordinates_B']),1-parameters['good_selector_answer'],parameters['flip_B'])
    axioms|=aa|bb
    if parameters['family_B']=='E' and parameters['coordinates_B'][2]==0:axioms.add(frozenset([atom_b(0,4)]))
    clauses=case['clauses']
    assert len({frozenset(c) for c in clauses})==len(clauses)
    assert {frozenset(c) for c in clauses}==axioms
    assert digest(clauses)==case['clause_sha256']
    proof=case['proof'];assert proof['status']=='CONFLICT' and case['closed'] is True
    assigned={};reason_for={}
    for literal,reason in proof['units']:
        assert 0<=reason<len(clauses)
        assert literal in clauses[reason] and abs(literal) not in assigned
        others=[value for value in clauses[reason] if value!=literal]
        assert all(abs(value) in assigned and assigned[abs(value)]!=(value>0) for value in others)
        assigned[abs(literal)]=literal>0;reason_for[abs(literal)]=(literal,reason)
    conflict=proof['clause'];assert 0<=conflict<len(clauses)
    assert all(abs(value) in assigned and assigned[abs(value)]!=(value>0) for value in clauses[conflict])
    total_units+=len(proof['units'])
    # Retain only proof ancestors needed for the contradiction, for readable review.
    needed=set();stack=[abs(value) for value in clauses[conflict]]
    while stack:
        variable=stack.pop()
        if variable in needed:continue
        needed.add(variable);literal,reason=reason_for[variable]
        stack.extend(abs(other) for other in clauses[reason] if other!=literal)
    core_steps=[[literal,reason] for literal,reason in proof['units'] if abs(literal) in needed]
    cores.append({'case':case['id'],'parameters':parameters,'all_unit_steps':len(proof['units']),
        'essential_unit_steps':core_steps,'final_conflict_clause':conflict,
        'clause_ids_used':sorted({reason for literal,reason in core_steps}|{conflict})})
assert len(r['cases'])==len(cores)==64 and total_units==2331
assert r['all_cases_closed'] and not r['open_case_ids'] and r['aggregate']['splits']==0
print(json.dumps({'status':'PASS_PORTABLE_STRUCTURAL_PROOF','cases':64,'unit_steps':total_units,'essential_units':sum(len(c['essential_unit_steps']) for c in cores),'witness_splits':0,'scope':'four-query structural branch identity; all-fee deduction is in the accompanying mathematical proof, not a formalized six-query result'}))
