Portable structural four-query proof review packet

Run with Python standard library only:
  python -I -B verify.py
The checker reads local packet files and prints its result. It makes no
network calls and writes no files. No credentials or host filesystem paths
are included or needed. All64canonical CNFs are reconstructed from the
mathematical template/source axioms and all2331unit inferences are checked.
The manifest provides local byte integrity, not external authentication.

Read template_derivation.txt for complete template coverage; case_proof.txt
for every essential contradiction; four_query_all_monotone.txt for the
all-fee deduction. The Python checker is a small propositional checker,
not Lean/HOLformalization of the mathematical reduction or all-fee proof,
and not external human review. Literature priority remains OPEN. Original
five/six-query structural proofs and actual application gain remain open.
Prepared for private research review; no blanket project licence or public
release is added by this packet.
