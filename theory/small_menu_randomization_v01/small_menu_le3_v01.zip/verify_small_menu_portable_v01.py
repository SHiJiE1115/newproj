"""Public exact <=3 source/ideal proof; no old four-query package is executed or bundled."""
import argparse,hashlib,itertools,json,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--out',required=True);parser.add_argument('--expected-manifest-sha256')
args=parser.parse_args();OUT=Path(args.out)
assert OUT.is_absolute() and not OUT.exists(),'Use a fresh absolute output directory'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
manifest_path=HERE/'REPLAY_MANIFEST_V01.json'
if args.expected_manifest_sha256:assert sha(manifest_path)==args.expected_manifest_sha256
manifest=json.loads(manifest_path.read_bytes())
for item in manifest['files']:
 name=item['name'];assert '/' not in name and '\\' not in name
 path=HERE/name;assert path.is_file() and path.stat().st_size==item['bytes'] and sha(path)==item['sha256']
OUT.mkdir()
def save(name,data):
 with (OUT/name).open('x',encoding='utf-8',newline='\n') as stream:json.dump(data,stream,ensure_ascii=False,indent=2);stream.write('\n')
protocol_sha=sha(HERE/'CERTIFICATE_IDEAL_PROTOCOL_V01.json')
assert protocol_sha=='c74265b0ae568a7eddd5adf128c51cdb485f6c203bdb37614f708d2b06a3ea5e'
started = time.monotonic()
edges = list(itertools.combinations(range(6), 2))
edge_index = {pair: i for i, pair in enumerate(edges)}
partitions = []
for graph in range(1 << 15):
    parent = list(range(6))

    def representative(x):
        while parent[x] != x:
            x = parent[x]
        return x

    for i, (a, b) in enumerate(edges):
        if (graph >> i) & 1:
            a, b = representative(a), representative(b)
            parent[max(a,b)] = min(a,b)
    row = tuple(representative(x) for x in range(6))
    closed = sum(1 << i for i, (a, b) in enumerate(edges) if row[a] == row[b])
    if graph == closed:
        partitions.append((graph, row))
assert len(partitions) == 203 and len({row for graph, row in partitions}) == 203
all_worlds = (1 << len(partitions)) - 1
answer_worlds = [0] * 8
different_worlds = []
for i, pair in enumerate(edges):
    different_worlds.append(sum(1 << j for j, (graph, row) in enumerate(partitions) if not ((graph >> i) & 1)))
for j, (graph, row) in enumerate(partitions):
    answer = sum(int(row[2*q] == row[2*q+1]) << q for q in range(3))
    answer_worlds[answer] |= 1 << j
source_supports = set()
specifications = 0
for base_graph, base in partitions:
    base_worlds = sum(1 << j for j, (graph, row) in enumerate(partitions) if graph & base_graph == base_graph)
    blocks = sorted(set(base))
    different_choices = [edge_index[tuple(sorted(pair))] for pair in itertools.combinations(blocks, 2)]
    active = [0] * (1 << len(different_choices))
    active[0] = base_worlds
    for choice in range(len(active)):
        if choice:
            bit = choice & -choice
            k = bit.bit_length() - 1
            active[choice] = active[choice ^ bit] & different_worlds[different_choices[k]]
        assert active[choice]
        specifications += 1
        support = sum(1 << answer for answer in range(8) if active[choice] & answer_worlds[answer])
        source_supports.add(support)
assert specifications == 53071 and len(source_supports) == 55
producer_catalog = json.loads((HERE/'COMPLETE_THREE_QUERY_FIBRES_V01.json').read_bytes())
assert source_supports == set(map(int, producer_catalog['support_witnesses']))
for key, witness in producer_catalog['support_witnesses'].items():
    same = witness['same_partition']
    different = witness['different_record_pairs']
    actual = set()
    for graph, row in partitions:
        if any(same[a] == same[b] and row[a] != row[b] for a, b in edges):
            continue
        if any(row[a] == row[b] for a, b in different):
            continue
        actual.add(sum(int(row[2*q] == row[2*q+1]) << q for q in range(3)))
    assert sum(1 << x for x in actual) == int(key)
print(json.dumps({'stage': 'INDEPENDENT_SOURCE_CATALOG', 'partitions': 203,
    'specifications': specifications, 'supports': len(source_supports)}), flush=True)


def downsets(n):
    answer = set()
    subsets = list(range(1 << n))
    for chosen in itertools.product([False, True], repeat=len(subsets)):
        if not chosen[0]:
            continue
        included = {mask for mask in subsets if chosen[mask]}
        if all(not (small & large == small) or small in included for large in included for small in subsets):
            answer.add(sum(1 << mask for mask in included))
    return answer


def walk(tree, x, n, order):
    paid = set()
    last = -1
    node = tree
    while type(node) is not int:
        assert isinstance(node, list) and len(node) == 3
        q = node[0]
        assert type(q) is int and 0 <= q < n and q not in paid
        position = order.index(q)
        assert position > last
        last = position
        paid.add(q)
        node = node[2] if (x >> q) & 1 else node[1]
    assert node in [0,1]
    return node, sum(1 << q for q in paid)


reports = []
for n in [1,2,3]:
    report_path = HERE/('IDEAL_COVER_DIM%d_V01.json' % n)
    report = json.loads(report_path.read_bytes())
    ideals = downsets(n)
    assert len(ideals) == {1:2, 2:5, 3:19}[n]
    if n < 3:
        expected_tasks = {tuple(task) for task in itertools.product([0,1,2], repeat=2**n) if {1,2} <= set(task)}
    else:
        expected_tasks = set()
        for positive in source_supports:
            for negative in source_supports:
                if positive & negative:
                    continue
                task = [0]*8
                for x in range(8):
                    if positive & (1 << x): task[x] = 2
                    if negative & (1 << x): task[x] = 1
                expected_tasks.add(tuple(task))
    tasks = [tuple(task) for task in report['tasks']]
    assert len(tasks) == len(set(tasks)) == {1:2, 2:50, 3:924}[n]
    assert set(tasks) == expected_tasks and set(report['downsets']) == ideals
    rows = report['rows']
    covered = {(row['task_index'], row['ideal_mask']) for row in rows}
    expected_pairs = set(itertools.product(range(len(tasks)), ideals))
    assert len(rows) == len(covered) and covered == expected_pairs
    applicable, inapplicable, full_paths, supplied_certificates = 0,0,0,0
    for row in rows:
        task = tasks[row['task_index']]
        domain = [x for x, label in enumerate(task) if label]
        ideal = row['ideal_mask']
        allowed = [mask for mask in range(1 << n) if ideal & (1 << mask)]
        all_available = True
        possible = {}
        for x in domain:
            opposite = [y for y in domain if task[y] != task[x]]
            possible[x] = [mask for mask in allowed if all((x & mask) != (y & mask) for y in opposite)]
            all_available &= bool(possible[x])
        if not all_available:
            inapplicable += 1
            assert 'no_allowed_certificate_at' in row
            assert row['no_allowed_certificate_at'] in domain and not possible[row['no_allowed_certificate_at']]
            continue
        applicable += 1
        assert 'total_tree' in row and 'global_order' in row
        for x in domain:
            assert row['certificate_choices'][str(x)] in possible[x]
            supplied_certificates += 1
        order = row['global_order']
        assert sorted(order) == list(range(n)) and len(order) == n
        for x in range(1 << n):
            output, paid = walk(row['total_tree'], x, n, order)
            assert ideal & (1 << paid)
            if task[x]:
                assert output == task[x] - 1
            full_paths += 1
    assert report['failure'] is None and report['checked_cases'] == len(rows)
    assert report['applicable_cases'] == applicable
    item = {'dimension': n, 'tasks': len(tasks), 'nonempty_downsets': len(ideals),
        'checked_source_ideal_pairs': len(rows), 'applicable_tree_witnesses': applicable,
        'inapplicable_certificates': inapplicable, 'full_cube_paths_checked': full_paths,
        'source_certificate_witnesses_checked': supplied_certificates,
        'producer_report_sha256': sha(report_path)}
    reports.append(item)
    print(json.dumps(item), flush=True)

lower={'independent_source_reconstruction':{'closed_graphs_of32768_edge_assignments':len(partitions),
 'fibre_specifications':specifications,'distinct_supports':len(source_supports),'nonconstant_disjoint_source_pairs':924},
 'reports':reports,'checked_source_ideal_pairs':sum(row['checked_source_ideal_pairs'] for row in reports),
 'applicable_total_priority_tree_witnesses':sum(row['applicable_tree_witnesses'] for row in reports),
 'full_cube_paths_checked':sum(row['full_cube_paths_checked'] for row in reports)}
assert lower==json.loads((HERE/'EXPECTED_SMALL_MENU_LOWER_V01.json').read_bytes())
result={'status':'PASS_FRESH_LE3_IDEAL_PROOF',
 'mathematics':lower,'protocol_sha256':protocol_sha,'manifest_sha256':sha(manifest_path),
 'four_query_reexecuted':False,'fresh_lower_bound_replayed':True,
 'same_checker_portability_not_another_independent_implementation':True,
 'literature_priority_established':False,'human_review':False,'new_model_API_calls':0,
 'wall_seconds':time.monotonic()-started}
save('VERIFICATION_RESULT_V01.json',result)
print(json.dumps({'status':result['status'],'checked_pairs':lower['checked_source_ideal_pairs'],
 'four_query_reexecuted':False}),flush=True)
