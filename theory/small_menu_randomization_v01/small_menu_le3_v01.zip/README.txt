Complete-equivalence small-menu certificate-ideal proof (public derivative)

Python3.10+ standard library only. Extract these10flat members and run:
 python verify_small_menu_portable_v01.py --out A_FRESH_ABSOLUTE_OUTPUT_DIRECTORY
Optional --expected-manifest-sha256 pins the exact manifest.

The command independently reconstructs203endpoint partitions,53071specifications,
55supports and924ordered disjoint3querysources, then directly checks all17810
source/ideal pairs,10974total globally ordered trees and87308full-cube paths.
The all-monotone price conclusion uses the threshold-downset argument in the
paper, not extrapolation from a finite price grid. Six original proof/input
files and the finite mathematical checker core are byte-identical to accepted
private371evidence. The outer result/manifest wrapper is a declared derivative.

The old4query acceptance and old ZIP contained local absolute path descriptors.
They remain immutable privately and are NOT bundled/executed by this command.
The separate inherited reference records their hashes and exact9/2versus5
claim. Appendix I in the V12reading copy supplies its full analytical source,
mixture, lower bound and completion collision proof. Do not describe this new
command as a fresh computation of the old4query games.

The private seed may randomize the priority order; correctness is zero error.
The completion quantifier is forall source forall cost exists completion/tree.
The sharp minimum4differs from the main deterministic adaptive/order6/7boundary.
Arbitrary partial3bit functions, largest4queryratio and the first randomized
adaptive/order gap are not settled. Bibliographic priority remains open.
This is the same independent checker core transported across systems, not a
third independent implementation, human review, formal proof kernel, original
historical scientific execution, human gold label or application advantage.
No model calls, dependency installation or new blanket project licence.
