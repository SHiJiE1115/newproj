"""Frozen old witnesses; exact minimax with a full causal-SKIP baseline."""
import hashlib,itertools,json,time
from functools import lru_cache
from pathlib import Path
H=Path(__file__).resolve().parent
start=time.monotonic()
def tick():
    assert time.monotonic()-start<210
def read(name): return json.loads((H/name).read_bytes())
def save(name,value):
    with (H/name).open('x',encoding='utf-8') as f: json.dump(value,f,indent=2);f.write('\n')
p=read('FIXED_DEPTH_WITNESS_PROTOCOL_V01.json')
source_path=(H/p['source_manuscript']).resolve()
assert not Path(p['source_manuscript']).is_absolute() and source_path.is_relative_to(H)
assert hashlib.sha256(source_path.read_bytes()).hexdigest()==p['source_sha256']
INF=10**6
def partitions(n):
    def rec(xs,m):
        if len(xs)==n: yield tuple(xs);return
        for x in range(m+2): yield from rec(xs+[x],max(m,x))
    yield from rec([0],0)
def physical(case,label):
    blocks=case['same_blocks_'+str(label)]
    record_to_block={r:i for i,b in enumerate(blocks) for r in b}
    supports=set();n=0
    for labels in partitions(len(blocks)):
        if any(labels[record_to_block[a]]==labels[record_to_block[b]] for a,b in case['different_'+str(label)]):continue
        n+=1
        supports.add(sum((labels[record_to_block[2*i]]==labels[record_to_block[2*i+1]])<<i for i in range(case['queries'])))
    return {'partitions':n,'support':sorted(supports)}
def solve(case):
    q=case['queries'];prices=case['prices'];labels={w:h for h in (0,1) for w in case['W'+str(h)]}
    worlds=tuple(sorted(labels))
    def pure(ws): return len({labels[w] for w in ws})==1
    def split(ws,i):return tuple(tuple(w for w in ws if (w>>i)&1==b) for b in (0,1))
    @lru_cache(None)
    def adaptive(ws,avail,depth):
        tick()
        if pure(ws):return (0,labels[ws[0]])
        if not depth:return INF,None
        candidates=[]
        for i in range(q):
            if not avail>>i&1:continue
            parts=split(ws,i)
            if not all(parts):continue
            a,b=[adaptive(s,avail^(1<<i),depth-1) for s in parts]
            cost=prices[i]+max(a[0],b[0])
            if cost<INF:candidates.append((cost,[i,a[1],b[1]]))
        return min(candidates,key=lambda x:x[0]) if candidates else (INF,None)
    @lru_cache(None)
    def ordered(ws,remaining):
        tick()
        if pure(ws):return 0
        if not remaining:return INF
        i=remaining[0];tail=remaining[1:]
        skip=ordered(ws,tail)
        parts=split(ws,i)
        take=prices[i]+max(ordered(s,tail) for s in parts if s)
        return min(skip,take)
    def replay(tree):
        paths=[]
        for w in worlds:
            t=tree;indices=[]
            while isinstance(t,list):
                i=t[0];assert i not in indices;indices.append(i);t=t[1+((w>>i)&1)]
            assert t==labels[w]
            paths.append({'word':w,'label':t,'queries':indices,'set':sum(1<<i for i in indices),'cost_units':sum(prices[i] for i in indices)})
        sets={x['set'] for x in paths};env=sorted(s for s in sets if not any(s!=t and s&t==s for t in sets))
        return {'paths':paths,'max_depth':max(len(x['queries']) for x in paths),'max_cost_units':max(x['cost_units'] for x in paths),'envelope':env}
    opt,tree=adaptive(worlds,(1<<q)-1,q)
    orders=[{'order':list(order),'value_units':ordered(worlds,order)} for order in itertools.permutations(range(q))]
    limited={str(d):adaptive(worlds,(1<<q)-1,d)[0] for d in (1,2,3,4) if d<=q}
    result={'adaptive_optimum_units':opt,'adaptive_tree':tree,'adaptive_replay':replay(tree),'depth_limited_optima_units':{d:(None if c>=INF else c) for d,c in limited.items()},'priority_optimum_units':min(x['value_units'] for x in orders),'all_orders':orders}
    assert opt==case['expected_adaptive_cost_units'];assert result['priority_optimum_units']==case['expected_priority_cost_units']
    if 'adaptive_tree' in case:
        result['original_adaptive_replay']=replay(case['adaptive_tree'])
        result['original_priority_depth2_replay']=replay(case['priority_tree_depth2'])
        assert result['original_adaptive_replay']['envelope']==case['expected_adaptive_envelope']
        assert result['original_adaptive_replay']['max_depth']==4
        assert result['original_adaptive_replay']['max_cost_units']==9
        assert result['original_priority_depth2_replay']['max_depth']==2
        assert result['original_priority_depth2_replay']['max_cost_units']==10
        result['physical']=[physical(case,h) for h in (0,1)]
        for h in (0,1):assert result['physical'][h]['support']==case['W'+str(h)]
    else:
        assert result['adaptive_replay']['max_depth']==3
        assert all(not w&1 or w&2 for w in case['W0']) and 2 in case['W0']
    return result
r={'schema':1,'status':'PASS_FIXED_OLD_WITNESS_DEPTH_AND_FULL_SKIP_COST_REPLAY','seven':solve(p['seven']),'horn_control':solve(p['horn_control']),'new_model_calls':0,'not_universal_D3_proof':True,'wall_seconds':time.monotonic()-start}
save('FIXED_DEPTH_WITNESS_RESULT_V01.json',r)
print(json.dumps({k:{'adaptive':r[k]['adaptive_optimum_units']/2,'priority':r[k]['priority_optimum_units']/2,'depth_limited_units':r[k]['depth_limited_optima_units'],'orders':len(r[k]['all_orders'])} for k in ('seven','horn_control')}))
