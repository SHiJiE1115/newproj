"""Replay only the two fixed old controls and compare exact scientific fields."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
H=Path(__file__).resolve().parent
if sys.version_info<(3,10) or sys.flags.optimize:
 raise RuntimeError("Python 3.10+ required; do not run with optimization (-O or -OO)")
def load(p):return json.loads(p.read_bytes())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
 with p.open('x',encoding='utf-8') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
manifest=load(H/'MANIFEST.json')
for name,expected in manifest['files'].items():
 p=(H/name).resolve()
 if not p.is_relative_to(H) or not p.is_file():raise ValueError('missing or outside packet input: '+name)
 if p.stat().st_size!=expected['bytes'] or digest(p)!=expected['sha256']:raise ValueError('input digest mismatch: '+name)
for name in ['FIXED_DEPTH_WITNESS_RESULT_V01.json','INDEPENDENT_FIXED_DEPTH_BUDGET_RESULT_V01.json','FIXED.PROCESS_START.json','FIXED.PROCESS_TERMINAL.json','VERIFY.PROCESS_START.json','VERIFY.PROCESS_TERMINAL.json','PORTABLE_REPLAY_RESULT_V01.json','FIXED.stdout.txt','FIXED.stderr.txt','VERIFY.stdout.txt','VERIFY.stderr.txt']:
 if (H/name).exists():raise FileExistsError('Use a fresh extraction; output already exists: '+name)
def run(phase,script):
 cmd=[sys.executable,'-I','-X','utf8','-B',str(H/script)]
 t=time.monotonic()
 with (H/(phase+'.stdout.txt')).open('xb') as out,(H/(phase+'.stderr.txt')).open('xb') as err:
  proc=subprocess.Popen(cmd,cwd=H,stdout=out,stderr=err)
  save(H/(phase+'.PROCESS_START.json'),{'pid':proc.pid,'command':cmd,'started_utc':now(),'script_sha256':digest(H/script),'origin':'new portable replay; not original595'})
  timed_out=False
  try:proc.wait(timeout=220)
  except subprocess.TimeoutExpired:timed_out=True;proc.kill();proc.wait()
  terminal={'pid':proc.pid,'actual_exit_code':proc.returncode,'timed_out':timed_out,'completed_utc':now(),'wall_seconds':time.monotonic()-t,'origin':'new portable replay; actual retained Popen handle, not original595'}
  save(H/(phase+'.PROCESS_TERMINAL.json'),terminal)
  if proc.returncode!=0 or timed_out:raise RuntimeError(phase+' failed; retained receipt and stderr explain the failure')
 return terminal
fixed=run('FIXED','check_fixed_depth_witnesses_v01.py')
verify=run('VERIFY','verify_fixed_depth_budget_v01.py')
producer=load(H/'FIXED_DEPTH_WITNESS_RESULT_V01.json')
checker=load(H/'INDEPENDENT_FIXED_DEPTH_BUDGET_RESULT_V01.json')
original_p=load(H/'expected/FIXED_DEPTH_WITNESS_RESULT_V01.json')
original_v=load(H/'expected/INDEPENDENT_FIXED_DEPTH_BUDGET_RESULT_V01.json')
exclude_p={'wall_seconds'}
exclude_v={'protocol_sha256','production_sha256','production_exit_receipt_sha256','checker_sha256','wall_seconds'}
def scientific(x,excluded):return {k:v for k,v in x.items() if k not in excluded}
assert producer.keys()==original_p.keys() and checker.keys()==original_v.keys()
assert scientific(producer,exclude_p)==scientific(original_p,exclude_p)
assert scientific(checker,exclude_v)==scientific(original_v,exclude_v)
assert checker['protocol_sha256']==digest(H/'FIXED_DEPTH_WITNESS_PROTOCOL_V01.json')
assert checker['production_sha256']==digest(H/'FIXED_DEPTH_WITNESS_RESULT_V01.json')
assert checker['production_exit_receipt_sha256']==digest(H/'FIXED.PROCESS_TERMINAL.json')
assert checker['checker_sha256']==digest(H/'verify_fixed_depth_budget_v01.py')
for name,expected in manifest['files'].items():assert digest(H/name)==expected['sha256']
result={'status':'PASS_PORTABLE_FIXED_DEPTH_EXACT_SCIENTIFIC_REPLAY','completed_utc':now(),'root':str(H),'python':sys.version,'platform':sys.platform,'fresh_processes':[fixed,verify],'production_scientific_fields_exact':True,'independent_scientific_fields_exact':True,'production_metadata_exclusions':sorted(exclude_p),'independent_metadata_exclusions':sorted(exclude_v),'new_metadata_recomputed_and_bound':True,'original595_receipts_preserved_only_under_provenance':True,'counts':{'orders':5064,'physical_partitions':sum(p['partitions'] for p in producer['seven']['physical'])},'seven':{'adaptive_cost':producer['seven']['adaptive_optimum_units']/2,'priority_cost':producer['seven']['priority_optimum_units']/2,'depth_limited_units':producer['seven']['depth_limited_optima_units']},'horn_control':{'adaptive_cost':producer['horn_control']['adaptive_optimum_units']/2,'priority_cost':producer['horn_control']['priority_optimum_units']/2},'B5_reexecuted':False,'universal_D3_proved_by_this_replay':False,'human_review':False,'new_model_calls':0}
save(H/'PORTABLE_REPLAY_RESULT_V01.json',result)
print(json.dumps(result))
