"""Independent integer-budget feasibility checks of two frozen old instances.

Uses feasible/not-feasible recursion over compatible-world bitsets, never imports
the production solver. Physical reconstruction inserts components into explicit
set blocks, rather than generating restricted-growth strings.
"""
from __future__ import annotations
from functools import lru_cache
from pathlib import Path
import hashlib
import itertools
import json
import time

HERE = Path(__file__).resolve().parent
START = time.monotonic()


def tick():
    if time.monotonic() - START > 210:
        raise TimeoutError("independent checker internal 210-second bound")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def replay(tree, spec):
    words = sorted((word, label) for label in (0, 1) for word in spec[f"W{label}"])
    paths = []
    for word, label in words:
        tick()
        node, bought, compatible = tree, [], words
        while isinstance(node, list):
            assert len(node) == 3
            query = node[0]
            assert type(query) is int and 0 <= query < spec["queries"]
            assert query not in bought
            assert len({other_label for _, other_label in compatible}) == 2
            answer = (word >> query) & 1
            bought.append(query)
            compatible = [(w, y) for w, y in compatible if ((w >> query) & 1) == answer]
            node = node[answer + 1]
        assert type(node) is int and node == label
        assert {y for _, y in compatible} == {label}
        mask = sum(1 << q for q in bought)
        paths.append({"word": word, "label": label, "queries": bought,
                      "set": mask, "cost_units": sum(spec["prices"][q] for q in bought)})
    sets = {row["set"] for row in paths}
    maximal = sorted(s for s in sets if not any(s != t and (s & t) == s for t in sets))
    return {"paths": paths, "max_depth": max(len(p["queries"]) for p in paths),
            "max_cost_units": max(p["cost_units"] for p in paths), "envelope": maximal}


def feasibility_check(spec, observed):
    m, prices = spec["queries"], spec["prices"]
    words = tuple((word, label) for label in (0, 1) for word in spec[f"W{label}"])
    assert len({word for word, _ in words}) == len(words)
    full = (1 << len(words)) - 1
    label_one = sum(1 << i for i, (_, label) in enumerate(words) if label)
    answer_one = tuple(sum(1 << i for i, (word, _) in enumerate(words) if (word >> q) & 1)
                       for q in range(m))

    def pure(worlds):
        return not (worlds & label_one) or not (worlds & (full ^ label_one))

    @lru_cache(None)
    def adaptive(worlds, remaining, budget, depth):
        tick()
        if budget < 0:
            return False
        if pure(worlds):
            return True
        if depth == 0:
            return False
        for q in range(m):
            bit = 1 << q
            if not remaining & bit or prices[q] > budget:
                continue
            yes, no = worlds & answer_one[q], worlds & (full ^ answer_one[q])
            if not yes or not no:
                continue
            if (adaptive(no, remaining ^ bit, budget - prices[q], depth - 1)
                    and adaptive(yes, remaining ^ bit, budget - prices[q], depth - 1)):
                return True
        return False

    a = observed["adaptive_optimum_units"]
    assert adaptive(full, (1 << m) - 1, a, m)
    assert not adaptive(full, (1 << m) - 1, a - 1, m)
    for depth_text, value in observed["depth_limited_optima_units"].items():
        depth = int(depth_text)
        if value is None:
            assert not adaptive(full, (1 << m) - 1, sum(prices), depth)
        else:
            assert adaptive(full, (1 << m) - 1, value, depth)
            assert not adaptive(full, (1 << m) - 1, value - 1, depth)

    expected_orders = list(itertools.permutations(range(m)))
    rows = observed["all_orders"]
    assert len(rows) == len(expected_orders)
    assert [tuple(row["order"]) for row in rows] == expected_orders
    min_value = min(row["value_units"] for row in rows)
    assert min_value == observed["priority_optimum_units"] == spec["expected_priority_cost_units"]
    audit = []
    feasible_at_global = 0
    for order, row in zip(expected_orders, rows):
        tick()

        @lru_cache(None)
        def priority(position, worlds, budget):
            tick()
            if budget < 0:
                return False
            if pure(worlds):
                return True
            if position == m:
                return False
            # SKIP is selected from the current compatible observed history;
            # it supplies no answer and permanently advances the same order.
            if priority(position + 1, worlds, budget):
                return True
            q = order[position]
            if prices[q] > budget:
                return False
            yes, no = worlds & answer_one[q], worlds & (full ^ answer_one[q])
            if not yes or not no:
                return False
            return (priority(position + 1, no, budget - prices[q])
                    and priority(position + 1, yes, budget - prices[q]))

        value = row["value_units"]
        at_value = priority(0, full, value)
        below_value = priority(0, full, value - 1)
        at_global = priority(0, full, min_value)
        below_global = priority(0, full, min_value - 1)
        assert at_value and not below_value and not below_global
        feasible_at_global += int(at_global)
        audit.append({"order": list(order), "value_units": value,
                      "value_feasible": at_value, "one_less_infeasible": not below_value,
                      "global_min_feasible": at_global, "below_global_min_infeasible": not below_global})
        priority.cache_clear()
    assert feasible_at_global > 0
    own_replay = replay(observed["adaptive_tree"], spec)
    assert own_replay == observed["adaptive_replay"]
    assert own_replay["max_cost_units"] == a == spec["expected_adaptive_cost_units"]
    return {"orders_checked": len(audit), "all_order_threshold_checks": audit,
            "adaptive_budget_threshold_checked": a,
            "adaptive_depth_budget_thresholds_checked": observed["depth_limited_optima_units"],
            "adaptive_tree_replay": own_replay,
            "priority_global_min_units": min_value,
            "orders_feasible_at_global_min": feasible_at_global,
            "all_orders_infeasible_one_below_global_min": True}


def reconstruct_physical(spec):
    results = []
    for label in (0, 1):
        blocks = spec[f"same_blocks_{label}"]
        assert sorted(r for b in blocks for r in b) == list(range(14))
        component = {record: i for i, block in enumerate(blocks) for record in block}
        # Each integer is a bitset of SAME-component indices in one equivalence
        # class. Insert the next component into one old block or one new block.
        partitions = [()]
        for new_component in range(len(blocks)):
            tick()
            bit = 1 << new_component
            following = []
            for partition in partitions:
                following.append(partition + (bit,))
                for j in range(len(partition)):
                    following.append(partition[:j] + (partition[j] | bit,) + partition[j + 1:])
            assert len(following) == len(set(following))
            partitions = following
        support, accepted = set(), 0
        for partition in partitions:
            tick()
            group = {c: j for j, block in enumerate(partition)
                     for c in range(len(blocks)) if (block >> c) & 1}
            if any(group[component[a]] == group[component[b]]
                   for a, b in spec[f"different_{label}"]):
                continue
            accepted += 1
            word = sum(1 << q for q in range(7)
                       if group[component[2*q]] == group[component[2*q + 1]])
            support.add(word)
        assert sorted(support) == spec[f"W{label}"]
        results.append({"partitions": accepted, "support": sorted(support),
                        "all_quotient_partitions_before_DIFFERENT": len(partitions)})
    return results


def main():
    protocol_path = HERE / "FIXED_DEPTH_WITNESS_PROTOCOL_V01.json"
    production_path = HERE / "FIXED_DEPTH_WITNESS_RESULT_V01.json"
    receipt_path = HERE / "FIXED.PROCESS_TERMINAL.json"
    out = HERE / "INDEPENDENT_FIXED_DEPTH_BUDGET_RESULT_V01.json"
    assert not out.exists()
    protocol = json.loads(protocol_path.read_bytes())
    production = json.loads(production_path.read_bytes())
    receipt = json.loads(receipt_path.read_bytes())
    assert receipt["actual_exit_code"] == 0 and receipt["timed_out"] is False
    assert digest(Path(protocol["source_manuscript"])) == protocol["source_sha256"]
    physical = reconstruct_physical(protocol["seven"])
    assert [{"partitions": row["partitions"], "support": row["support"]} for row in physical] == production["seven"]["physical"]
    result = {"schema": 1, "status": "PASS_INDEPENDENT_BOOLEAN_BUDGET_ALL5064_ORDERS_AND_COMPLETE_PHYSICAL_SOURCE",
              "protocol_sha256": digest(protocol_path), "production_sha256": digest(production_path),
              "production_exit_receipt_sha256": digest(receipt_path),
              "checker_sha256": digest(Path(__file__)),
              "seven": feasibility_check(protocol["seven"], production["seven"]),
              "horn_control": feasibility_check(protocol["horn_control"], production["horn_control"]),
              "physical": physical,
              "independent_algorithm": "integer-budget feasibility over compatible-world bitsets; explicit set-block insertion for complete physical fibres",
              "imports_production_solver": False, "new_model_calls": 0,
              "new_sources_or_prices": False, "human_review": False,
              "not_universal_D3_proof": True, "literature_priority": "OPEN"}
    spec = protocol["seven"]
    original_a = replay(spec["adaptive_tree"], spec)
    original_p = replay(spec["priority_tree_depth2"], spec)
    assert original_a == production["seven"]["original_adaptive_replay"]
    assert original_p == production["seven"]["original_priority_depth2_replay"]
    assert original_a["envelope"] == spec["expected_adaptive_envelope"]
    assert original_a["max_depth"] == 4 and original_a["max_cost_units"] == 9
    assert original_p["max_depth"] == 2 and original_p["max_cost_units"] == 10
    assert all(path["queries"] == sorted(path["queries"]) for path in original_p["paths"])
    assert result["horn_control"]["adaptive_tree_replay"]["max_depth"] == 3
    result["original_seven_depth4_separating_tree"] = original_a
    result["original_seven_depth2_priority_tree"] = original_p
    result["wall_seconds"] = time.monotonic() - START
    tick()
    encoded = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    assert len(encoded.encode("utf-8")) < 64 * 1024 * 1024
    with out.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(encoded)
    print(json.dumps({"status": result["status"], "orders": 5064,
                      "seven_adaptive_depth4_cost_units": 9,
                      "seven_priority_threshold_units": 10,
                      "horn_adaptive_depth3_cost_units": 10,
                      "horn_priority_threshold_units": 12,
                      "wall_seconds": result["wall_seconds"]}))


if __name__ == "__main__":
    main()
