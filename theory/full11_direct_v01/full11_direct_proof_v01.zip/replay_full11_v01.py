"""Portable exact replay of the specified full11 copy/pin theorem.

Python 3.9+, standard library only; no API, LP solver, producer import,
original drive paths, or seven/eight-query theorem-result imports.
"""
from pathlib import Path
from fractions import Fraction as F
from functools import lru_cache
from collections import Counter
import argparse, gc, gzip, hashlib, importlib.util, itertools, json, os, platform, sys, time

HERE=Path(__file__).resolve().parent
A=['a',1,'a','b','a','c','c','a','b','b','c']
B=['u','u',0,'v','w','w','v','v','u','w','u']
TARGET=F(5,4)
PARAM={'AD_frontier_cap':50000,'AD_product_cap':100000000}

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()

class Budget:
    def __init__(self,seconds):self.start=time.monotonic();self.end=self.start+seconds
    def check(self,force=False):
        if time.monotonic()>self.end:raise TimeoutError('PORTABLE_REPLAY_TIME_CAP')

def context_children(stack,context,policy_id,paths):
    assert paths and paths==sorted(set(paths))
    address,selected,_,_=context
    for j in reversed(range(len(paths))):
        mask=paths[j];stack.append((address+[j],selected+[[policy_id,mask]],address,mask))

def row_context(Q,row,ci,U,context):
    Q.context_check(row,ci,U,context)

def scalar_order(source,order,prices,budget):
    """One precommitted order; min SKIP vs TAKE at each observed history."""
    infinity=sum(prices)+1
    @lru_cache(maxsize=None)
    def cost(state,remaining):
        if source.flag(state)!=3:return 0
        if not remaining:return infinity
        q,tail=remaining[0],remaining[1:]
        skip=cost(state,tail)
        if not source.varying(state,q):return skip
        return min(skip,prices[q]+max(cost(source.step(state,q,0),tail),cost(source.step(state,q,1),tail)))
    budget.check();answer=cost(source.root,tuple(order));cost.cache_clear();return answer

def controls(Q,budget):
    original=Q.controls(budget,PARAM)
    assert original['status']=='PASS'
    tests=0
    for T0,T1,prices,expected in [([0,0],[0,1],(9,2),2),(['a','a'],[0,1],(1,2),3),([0],[1],(0,),0)]:
        source=Q.GroupSource(T0,T1)
        for order in itertools.permutations(range(len(prices))):
            assert scalar_order(source,order,prices,budget)==expected;tests+=1
    # New coverage plumbing: no missing required child or swapped path context.
    stack=[];context_children(stack,([],[],None,None),0,[1,2])
    ci,U=0,[0,1];context=stack.pop()
    row={'cone_index':ci,'U':U,'address':[0],'selected_constraints':[[0,1]],'parent_address':[],'via_path':1}
    row_context(Q,row,ci,U,context)
    rejected=0
    for bad in (dict(row,address=[1]),dict(row,selected_constraints=[]),dict(row,via_path=2)):
        try:row_context(Q,bad,ci,U,context)
        except AssertionError:rejected+=1
    assert rejected==3 and len(stack)==1
    return {'original_mathematical_controls':original,'scalar_traces':tests,'coverage_context_rejections':rejected,'one_unwritten_child_remains_pending':True}

def library(Q,path,source,budget):
    result=[];seen=set();tree_nodes=0
    with gzip.open(path,'rt',encoding='utf8') as f:
        for i,line in enumerate(f):
            budget.check();assert line.endswith('\n')
            row=json.loads(line);assert type(row['policy_id']) is int and row['policy_id']==i
            E,n,_=Q.replay(source,row['tree'],row['order'])
            assert E==row['envelope'] and row['support']==Q.union(E,11)
            assert tuple(E) not in seen;seen.add(tuple(E));tree_nodes+=n
            result.append({k:row[k] for k in ('policy_id','envelope','support')})
    return result,tree_nodes

def tree(Q,stream,ci,E,U,policies,budget,counters):
    stack=[([],[],None,None)];count=0
    while stack:
        budget.check();context=stack.pop();line=next(stream,None)
        assert line is not None and line.endswith('\n'),'MISSING_REQUIRED_NODE'
        row=json.loads(line);assert row['node_index']==counters['nodes']
        row_context(Q,row,ci,U,context)
        for policy_id,path in context[1]:
            assert type(policy_id) is int and 0<=policy_id<len(policies)
            assert path in policies[policy_id]['envelope'] and set(policies[policy_id]['support'])<=set(U)
        upper,cU=Q.certificate(E,U,[path for _,path in context[1]],row['certificate'])
        if upper<=TARGET:
            assert row['action']=='bound_leaf' and row['branch_policy_id'] is None and row['child_paths']==[]
            counters['leaves']+=1
        else:
            assert row['action']=='branch','ABOVE_TARGET_OR_UNRESOLVED_LEAF'
            j=row['branch_policy_id'];assert type(j) is int and 0<=j<len(policies)
            assert j not in [k for k,_ in context[1]]
            policy=policies[j]
            assert set(policy['support'])<=set(U) and row['child_paths']==policy['envelope']
            prices=[F(0)]*11
            for q,c in zip(U,cU):prices[q]=c
            assert Q.value(policy['envelope'],prices)<upper
            context_children(stack,context,j,policy['envelope']);counters['branches']+=1
        counters['nodes']+=1;count+=1
    return count

def replay(seconds):
    budget=Budget(seconds)
    manifest_path=HERE/'MANIFEST_V01.json'
    manifest=json.loads(manifest_path.read_bytes())
    assert manifest['format']=='fixed-full11-direct-proof-v1'
    expected={'replay_full11_v01.py','group_math_v01.py','frontier.json','proof_index.json',
        'policies.jsonl.gz','main_nodes.jsonl.gz','direct_nodes.jsonl.gz','README_EN.txt','README_ZH.txt'}
    assert set(manifest['files'])==expected
    for name,d in manifest['files'].items():
        path=HERE/name
        assert path.is_file() and not path.is_symlink()
        assert path.stat().st_size==d['bytes'] and sha(path)==d['sha256']
    assert manifest['files']['group_math_v01.py']['sha256']=='5d3eddb8813920e010cbdf0468609d206cbd8596a9486b9fc208c5c3197ecb24'
    spec=importlib.util.spec_from_file_location('retained_group_math',str(HERE/'group_math_v01.py'))
    Q=importlib.util.module_from_spec(spec);spec.loader.exec_module(Q)
    checked=controls(Q,budget)
    index=json.loads((HERE/'proof_index.json').read_bytes())
    assert index['A']==A and index['B']==B and index['target']=='5/4'
    source=Q.GroupSource(A,B)
    front=json.loads((HERE/'frontier.json').read_bytes())
    assert [front['A_worlds'],front['B_worlds']]==source.world_signatures()
    solver=Q.Adaptive(source,budget,PARAM)
    adaptive=Q.masks(solver.solve(source.root))
    assert adaptive==front['adaptive_frontier'] and len(adaptive)==2193
    adstates,adproducts=solver.states,solver.products
    solver.solve.cache_clear();gc.collect()
    policies,policy_nodes=library(Q,HERE/'policies.jsonl.gz',source,budget)
    assert len(policies)==index['policies']
    main=Counter();direct=Counter();used_direct=0
    assert len(index['cones'])==len(adaptive)
    with gzip.open(HERE/'main_nodes.jsonl.gz','rt',encoding='utf8') as old,gzip.open(HERE/'direct_nodes.jsonl.gz','rt',encoding='utf8') as extra:
        for ci,E in enumerate(adaptive):
            c=index['cones'][ci];U=Q.union(E,11)
            assert c['cone_index']==ci and c['envelope']==E and c['U']==U
            assert c['source'] in ('main','direct')
            stream,counter=(old,main) if c['source']=='main' else (extra,direct)
            assert c['nodes_before']==counter['nodes']
            n=tree(Q,stream,ci,E,U,policies,budget,counter)
            assert n==c['nodes_after']-c['nodes_before'] and counter['nodes']==c['nodes_after']
            used_direct+=int(c['source']=='direct')
        assert next(old,None) is None and next(extra,None) is None,'UNREFERENCED_NODES'
    assert main['nodes']==125288 and direct['nodes']==index['direct_nodes'] and used_direct==166
    prices=(2,2,3,0,1,1,1,10,10,10,10)
    av=min(Q.value(E,list(map(F,prices))) for E in adaptive)
    assert av==4
    # Exhaustive global-order lower; SKIP never reveals an answer.
    seven=Q.GroupSource(A[:7],B[:7]);hist=Counter();digest=hashlib.sha256();best=None
    for order in itertools.permutations(range(7)):
        v=scalar_order(seven,order,prices[:7],budget)
        hist[v]+=1;digest.update((str(order)+':'+str(v)+'\n').encode('ascii'))
        best=v if best is None else min(best,v)
    assert sum(hist.values())==5040 and best==5
    # A legal cost5 priority witness plus high-price exclusion proves the full
    # priority cost5: every added coordinate costs10>5 on any reached purchase.
    upper_tree=[0,[1,1,0],[2,1,0]]
    E,_,_=Q.replay(source,upper_tree,list(range(11)))
    assert Q.value(E,list(map(F,prices)))==5
    for name,d in manifest['files'].items():assert sha(HERE/name)==d['sha256']
    return {'schema':1,'status':'PASS_SELF_CONTAINED_EXACT_FULL11_AND16_MENUS',
        'manifest_sha256':sha(manifest_path),'AD_envelopes':2193,'AD_states':adstates,'AD_products':adproducts,
        'complete_roots':len(adaptive),'direct_replacement_roots':used_direct,
        'main_certificates':dict(main),'direct_certificates':dict(direct),
        'policies':len(policies),'policy_tree_nodes':policy_nodes,'true_lower_prices':list(prices),
        'full_adaptive_at_lower':'4','seven_priority_min_over_all_orders':'5','global_orders_checked':5040,
        'order_optimum_histogram':dict(sorted(hist.items())),'order_trace_sha256':digest.hexdigest(),
        'full_priority_at_lower':'5','max_ratio':'5/4','sixteen_original7_containing_menus_max_ratio':'5/4',
        'arbitrary_identifiable_coordinate_submenus_upper':'5/4; no matching lower asserted for each',
        'old7_or8_upper_or_lower_results_loaded':False,'producer_math_imported':False,'LP_solver_used':False,
        'controls':checked,'API_calls':0,'human_review_claim':False,'novelty_claim':False,
        'runtime':{'python':platform.python_version(),'system':platform.system()},'wall_seconds':time.monotonic()-budget.start}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,help='New result file; parent must already exist. Omit for stdout only.')
    parser.add_argument('--seconds',type=int,default=900)
    args=parser.parse_args()
    assert sys.dont_write_bytecode,'Use python -B'
    assert 1<=args.seconds<=3600
    if args.out:assert args.out.parent.is_dir() and not args.out.exists()
    result=replay(args.seconds)
    if args.out:
        with args.out.open('x',encoding='utf8') as f:
            json.dump(result,f,indent=2,ensure_ascii=False);f.write('\n');f.flush();os.fsync(f.fileno())
    print(json.dumps(result,ensure_ascii=False),flush=True)
