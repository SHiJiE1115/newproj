"""Independent group-ternary AD and legal-library upper-certificate audit.

No producer imports, no LP solver, no fixed-price substitute for AD completeness.
Uses frozen producer artifacts as evidence, not as mathematical helpers.
"""
from pathlib import Path
from functools import lru_cache
from itertools import product
from fractions import Fraction as F
from collections import Counter
import ctypes
from ctypes import wintypes
import gc
import gzip
import hashlib
import json
import os
import re
import shutil
import sys
import time

HERE = Path(__file__).resolve().parent
EMPTY = frozenset()
PURE = (frozenset((EMPTY,)),)
VOID = (frozenset(),)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def rational(text):
    assert isinstance(text, str) and re.fullmatch(r'-?\d+(?:/[1-9]\d*)?', text)
    return F(text)


class MemoryCounters(ctypes.Structure):
    _fields_ = [('cb', wintypes.DWORD), ('PageFaultCount', wintypes.DWORD)] + [
        (name, ctypes.c_size_t) for name in ('PeakWorkingSetSize', 'WorkingSetSize',
        'QuotaPeakPagedPoolUsage', 'QuotaPagedPoolUsage', 'QuotaPeakNonPagedPoolUsage',
        'QuotaNonPagedPoolUsage', 'PagefileUsage', 'PeakPagefileUsage')]


def memory():
    assert os.name == 'nt'
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    psapi = ctypes.WinDLL('psapi', use_last_error=True)
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(MemoryCounters), wintypes.DWORD]
    psapi.GetProcessMemoryInfo.restype = wintypes.BOOL
    data = MemoryCounters()
    data.cb = ctypes.sizeof(data)
    if not psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(), ctypes.byref(data), data.cb):
        raise OSError('GetProcessMemoryInfo failed')
    return data.WorkingSetSize, data.PeakWorkingSetSize


class Budget:
    def __init__(self, protocol):
        self.p = protocol
        self.start = time.monotonic()
        self.deadline = self.start + protocol['seconds_cap']
        self.last = 0
        self.peak = 0

    def check(self, force=False):
        now = time.monotonic()
        if now > self.deadline:
            raise TimeoutError('QA_TIME_CAP')
        if force or now - self.last >= 1:
            current, peak = memory()
            self.peak = max(self.peak, peak)
            if current > self.p['observed_working_set_cap_bytes']:
                raise MemoryError('QA_OBSERVED_MEMORY_CAP')
            if shutil.disk_usage('C:/').free < 10 * 1024**3 + self.p['local_cap_bytes']:
                raise OSError('C_RESERVE_STOP')
            self.last = now


class GroupSource:
    """Each label is a direct conjunction of pin/copy constraints.

    State components are base3 assignments of that label's free groups, or -1
    for an inconsistent label. They are not sets or bitmasks of source worlds.
    """
    def __init__(self, A, B):
        assert len(A) == len(B)
        self.templates = [A, B]
        self.m = len(A)
        self.names = [sorted({x for x in T if isinstance(x, str)}) for T in self.templates]
        self.powers = [tuple(3**j for j in range(len(names))) for names in self.names]
        self.domains = [3**len(names) for names in self.names]
        self.maps = []
        for names, T in zip(self.names, self.templates):
            mapping = []
            for item in T:
                if type(item) is int:
                    assert item in (0, 1)
                    mapping.append(('pin', item))
                else:
                    assert isinstance(item, str)
                    mapping.append(('group', names.index(item)))
            self.maps.append(mapping)
        self.table = []
        self.literal_cubes = []
        self.transition_checks = 0
        for label in (0, 1):
            cubes = [self.expand(label, code) for code in range(self.domains[label])]
            self.literal_cubes.append(cubes)
            table = []
            for code in range(self.domains[label]):
                row = []
                for q in range(self.m):
                    children = tuple(self.side_step(label, code, q, bit) for bit in (0, 1))
                    for bit, child in enumerate(children):
                        expected = {w for w in cubes[code] if w[q] == bit}
                        actual = set() if child == -1 else cubes[child]
                        assert expected == actual
                        self.transition_checks += 1
                    row.append(children)
                table.append(row)
            self.table.append(table)
        assert self.literal_cubes[0][0] and self.literal_cubes[1][0]
        assert self.literal_cubes[0][0].isdisjoint(self.literal_cubes[1][0])
        self.root = (0, 0)

    def expand(self, label, code):
        """Independent literal expansion of one group's partial assignment."""
        names = self.names[label]
        ds = tuple((code // power) % 3 for power in self.powers[label])
        worlds = set()
        for bits in product((0, 1), repeat=len(names)):
            if any(d and d - 1 != bit for d, bit in zip(ds, bits)):
                continue
            assignment = dict(zip(names, bits))
            worlds.add(tuple(assignment[item] if isinstance(item, str) else item
                             for item in self.templates[label]))
        return worlds

    def side_step(self, label, code, q, bit):
        if code == -1:
            return -1
        kind, item = self.maps[label][q]
        if kind == 'pin':
            return code if item == bit else -1
        power = self.powers[label][item]
        digit = (code // power) % 3
        return code + (bit + 1) * power if digit == 0 else code if digit - 1 == bit else -1

    def step(self, state, q, bit):
        return tuple(-1 if code == -1 else self.table[label][code][q][bit]
                     for label, code in enumerate(state))

    @staticmethod
    def flag(state):
        return sum(1 << label for label, code in enumerate(state) if code != -1)

    def varying(self, state, q):
        return self.flag(self.step(state, q, 0)) != 0 and self.flag(self.step(state, q, 1)) != 0

    def world_signatures(self):
        return [sorted(sum(bit << q for q, bit in enumerate(w)) for w in cubes[0])
                for cubes in self.literal_cubes]


def envelope_key(E):
    return tuple(sorted(sum(1 << q for q in S) for S in E))


def masks(front):
    return sorted([list(envelope_key(E)) for E in front])


def dominates(E, G):
    return all(any(S <= T for T in G) for S in E)


class Adaptive:
    def __init__(self, source, budget, p):
        self.source, self.budget, self.p = source, budget, p
        self.states = self.products = self.options = 0
        self.largest_frontier = 0
        self.paid_sets = {EMPTY: EMPTY}
        self.solve = lru_cache(maxsize=1024)(self._solve)

    def intern(self, S):
        if S not in self.paid_sets:
            self.paid_sets[S] = S
        return self.paid_sets[S]

    def join(self, q, E, G):
        paths = frozenset(self.intern(S | {q}) for S in E | G)
        return frozenset(S for S in paths if not any(S < T for T in paths))

    def add(self, frontier, candidate):
        for index, old in enumerate(frontier):
            if index % 64 == 0:
                self.budget.check()
            if dominates(old, candidate):
                return frontier
        kept = []
        for index, old in enumerate(frontier):
            if index % 64 == 0:
                self.budget.check()
            if not dominates(candidate, old):
                kept.append(old)
        kept.append(candidate)
        if len(kept) > self.p['AD_frontier_cap']:
            raise MemoryError('QA_AD_FRONTIER_CAP')
        self.largest_frontier = max(self.largest_frontier, len(kept))
        return kept

    def _solve(self, state):
        self.states += 1
        self.budget.check()
        flag = self.source.flag(state)
        if flag == 0:
            return VOID
        if flag != 3:
            return PURE
        frontier = []
        for q in range(self.source.m):
            if not self.source.varying(state, q):
                continue
            left = self.solve(self.source.step(state, q, 0))
            right = self.solve(self.source.step(state, q, 1))
            for E in left:
                for G in right:
                    self.products += 1
                    if self.products > self.p['AD_product_cap']:
                        raise MemoryError('QA_AD_PRODUCT_CAP')
                    if self.products % 128 == 0:
                        self.budget.check()
                    frontier = self.add(frontier, self.join(q, E, G))
        assert frontier
        return tuple(sorted(frontier, key=envelope_key))


def replay(source, tree, order):
    assert all(type(q) is int and 0 <= q < source.m for q in order)
    assert len(order) == len(set(order))
    # A saved U-order is extended by permanently skipping all omitted queries.
    # The tree itself must only use coordinates in the saved prefix.
    positions = {q: i for i, q in enumerate(order)}
    paths = []
    nodes = 0

    def visit(node, state, paid, previous):
        nonlocal nodes
        flags = source.flag(state)
        if flags == 0:
            return
        nodes += 1
        if type(node) is int:
            assert node in (0, 1) and flags == 1 << node
            paths.append(paid)
            return
        assert isinstance(node, list) and len(node) == 3
        q = node[0]
        assert type(q) is int and 0 <= q < source.m and q not in paid
        assert q in positions
        assert positions[q] > previous
        visit(node[1], source.step(state, q, 0), paid | {q}, positions[q])
        visit(node[2], source.step(state, q, 1), paid | {q}, positions[q])

    visit(tree, source.root, EMPTY, -1)
    values = frozenset(paths)
    maximum = frozenset(S for S in values if not any(S < T for T in values))
    return list(envelope_key(maximum)), nodes, len(paths)


def union(E, m):
    return [q for q in range(m) if any(mask >> q & 1 for mask in E)]


def value(E, prices):
    return max(sum(prices[q] for q in range(len(prices)) if mask >> q & 1) for mask in E)


def certificate(E, U, selected_paths, cert):
    n = len(U) + 1
    x = list(map(rational, cert['primal']))
    assert len(x) == n
    rows = [([-int(j == k) for j in range(n)], 0) for k in range(n)]
    rows += [([int(mask >> q & 1) for q in U] + [0], 1) for mask in E]
    rows.append(([-1] * len(U) + [1], 0))
    rows += [([-int(mask >> q & 1) for q in U] + [1], 0) for mask in selected_paths]
    y = [F(0)] * len(rows)
    seen = set()
    for index, text in cert['dual_sparse']:
        assert type(index) is int and 0 <= index < len(rows) and index not in seen
        seen.add(index)
        y[index] = rational(text)
        assert y[index] >= 0
    assert all(sum(a * b for a, b in zip(row, x)) <= rhs for row, rhs in rows)
    assert all(sum(v * row[j] for v, (row, _) in zip(y, rows)) == int(j == n - 1) for j in range(n))
    upper = rational(cert['objective'])
    assert x[-1] == upper == sum(v * rhs for v, (_, rhs) in zip(y, rows))
    return upper, x[:-1]


def bound_file(item):
    path = Path(item['file'])
    assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256']
    return path


def old_theorems(protocol, source):
    """Hash inheritance only; no old checker or old experiment is executed."""
    old = {}
    for role, binding in protocol['old_theorem_bindings'].items():
        old[role] = json.loads(bound_file(binding).read_text(encoding='utf-8'))
    p7, r7 = old['seven_protocol'], old['seven_result']
    s8, r8 = old['eight_scope'], old['eight_result']
    assert r7['status'] == 'PASS_COMPLETE_FRONTIERS_AND_ALL_RATIONAL_CERTIFICATES'
    assert r7['protocol_sha256'] == protocol['old_theorem_bindings']['seven_protocol']['sha256']
    assert rational(r7['exact_global_ratio']) == F(5, 4)
    assert r8['status'] == 'PASS_FOUR_COMPLETE_ALLPRICE_PROOFS'
    assert len(r8['cases']) == 4
    assert all(c['status'] == 'PASS_COMPLETE_FRONTIERS_AND_EXACT_BB'
               and rational(c['bb']['exact_ratio']) == F(5, 4) for c in r8['cases'])
    assert p7['A'] == source.templates[0][:7] == s8['base_A']
    assert p7['B'] == source.templates[1][:7] == s8['base_B']
    # Prior delivery manifests pin the exact result objects inherited here.
    for prefix in ('seven', 'eight'):
        descriptors = old[prefix + '_manifest']['files']
        result_binding = protocol['old_theorem_bindings'][prefix + '_result']
        manifest_parent = Path(protocol['old_theorem_bindings'][prefix + '_manifest']['file']).parent
        matched = False
        for d in descriptors:
            path = Path(d.get('file', d.get('path')))
            if not path.is_absolute():
                path = manifest_parent / path
            if path.resolve() == Path(result_binding['file']).resolve():
                assert d['sha256'] == result_binding['sha256'] and d['bytes'] == result_binding['bytes']
                matched = True
        assert matched
    menus = [{'menu_id': 'seven', 'coordinates': list(range(7)), 'A': p7['A'], 'B': p7['B'],
              'QA_sha256': protocol['old_theorem_bindings']['seven_result']['sha256'],
              'producer_result_sha256': r7['producer_summary_sha256']}]
    for index, case in enumerate(s8['cases']):
        assert case['id'] == r8['cases'][index]['case_id'] == index
        assert case['chord'] == [source.templates[0][7 + index], source.templates[1][7 + index]]
        menus.append({'menu_id': 'eight_%d' % index, 'coordinates': list(range(7)) + [7 + index],
                      'A': p7['A'] + [case['chord'][0]], 'B': p7['B'] + [case['chord'][1]],
                      'QA_sha256': protocol['old_theorem_bindings']['eight_result']['sha256'],
                      'producer_result_sha256': r8['cases'][index]['source_result_sha256']})
    for menu in menus:
        for label, key in ((0, 'A'), (1, 'B')):
            assert [source.templates[label][q] for q in menu['coordinates']] == menu[key]
            projected = {tuple(w[q] for q in menu['coordinates']) for w in source.literal_cubes[label][0]}
            T = menu[key]
            names = sorted({x for x in T if isinstance(x, str)})
            literal = {tuple(dict(zip(names, bits))[x] if isinstance(x, str) else x for x in T)
                       for bits in product((0, 1), repeat=len(names))}
            assert projected == literal
    initial = list(map(rational, protocol['true_lower_prices']))
    assert initial[:7] == list(map(F, (2, 2, 3, 0, 1, 1, 1)))
    assert initial[7:] == [sum(initial[:7])] * 4 == [F(10)] * 4
    ad7 = min(value(E, initial[:7]) for E in r7['adaptive_frontier'])
    pr7 = min(value(E, initial[:7]) for E in r7['priority_frontier'])
    assert (ad7, pr7) == (F(4), F(5))
    return menus, {'prices': list(map(str, initial)), 'adaptive': '4', 'priority': '5',
                   'ratio': '5/4', 'route': 'Pinned complete old7 theorem plus high-price extension for both policy classes.'}


def inherited_menu(U, menus):
    added = [q for q in U if q >= 7]
    assert len(added) <= 1, 'MORE_THAN_ONE_NEW_QUERY_CANNOT_USE_OLD_MENU_THEOREM'
    menu = menus[0 if not added else added[0] - 7 + 1]
    assert set(U) <= set(menu['coordinates'])
    return menu


def controls(budget, p):
    cases = []
    for A, B, expected in [([0], [1], [[1]]), (['a', 'a'], [0, 1], [[3]]),
                            ([0, 'x'], [1, 'y'], [[1]])]:
        source = GroupSource(A, B)
        solver = Adaptive(source, budget, p)
        assert masks(solver.solve(source.root)) == expected
        cases.append({'source': [A, B], 'AD_frontier': expected,
                      'literal_transition_checks': source.transition_checks})
        solver.solve.cache_clear()
    good = {'primal': ['1', '1'], 'dual_sparse': [[2, '1'], [3, '1']], 'objective': '1'}
    assert certificate([1], [0], [], good)[0] == 1
    rejected = []
    for name, bad in [
        ('negative_price', {**good, 'primal': ['-1', '1']}),
        ('wrong_objective', {**good, 'objective': '2'}),
        ('duplicate_dual', {**good, 'dual_sparse': [[2, '1'], [2, '1'], [3, '1']]}),
        ('negative_dual', {**good, 'dual_sparse': [[2, '-1'], [3, '1']]})]:
        try:
            certificate([1], [0], [], bad)
        except AssertionError:
            rejected.append(name)
        else:
            raise AssertionError('Bad certificate accepted')
    high = {'primal': ['1', '1', '2'], 'dual_sparse': [[3, '1'], [4, '1'], [5, '1']], 'objective': '2'}
    upper, _ = certificate([1, 2], [0, 1], [], high)
    try:
        assert upper <= F(5, 4)
    except AssertionError:
        rejected.append('above_target_cannot_be_closed')
    else:
        raise AssertionError('Above-target leaf accepted')
    source = GroupSource(['a', 'a'], [0, 1])
    tree = [0, [1, 0, 1], 0]
    assert replay(source, tree, [0, 1])[0] == [3]
    for name, T, order in [('wrong_leaf', [0, [1, 1, 0], 0], [0, 1]),
                           ('reversed_priority_order', tree, [1, 0])]:
        try:
            replay(source, T, order)
        except AssertionError:
            rejected.append(name)
        else:
            raise AssertionError('Illegal policy accepted')
    try:
        inherited_menu([0, 7, 8], [])
    except AssertionError:
        rejected.append('two_new_queries_cannot_inherit_old8')
    else:
        raise AssertionError('Invalid inherited cone accepted')
    pending = []
    push_children(pending, ([], [], None, None), 2, [1, 2])
    first = pending.pop()
    row = {'cone_index': 0, 'U': [0, 1], 'address': [0], 'selected_constraints': [[2, 1]],
           'parent_address': [], 'via_path': 1}
    context_check(row, 0, [0, 1], first)
    try:
        context_check({**row, 'address': [1]}, 0, [0, 1], first)
    except AssertionError:
        rejected.append('wrong_child_address')
    else:
        raise AssertionError('Wrong child accepted')
    try:
        assert not pending
    except AssertionError:
        rejected.append('missing_required_child')
    else:
        raise AssertionError('Missing child accepted')
    return {'status': 'PASS', 'small_AD_frontiers': cases, 'negative_controls_rejected': rejected}


def external_file(item, root):
    path = Path(item['path'])
    assert path.resolve().is_relative_to(root.resolve())
    assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256']
    return path


def library_audit(path, source, seed, seed_sha, budget, p):
    library, envelopes = [], set()
    nodes = leaves = 0
    with gzip.open(path, 'rt', encoding='utf-8') as stream:
        for index, line in enumerate(stream):
            budget.check()
            assert line.endswith('\n') and index < p['policy_cap']
            row = json.loads(line)
            assert row['policy_id'] == index
            E, n, l = replay(source, row['tree'], row['order'])
            assert E == row['envelope'] and tuple(E) not in envelopes
            assert row['support'] == union(E, source.m)
            envelopes.add(tuple(E))
            if index < len(seed['priority']):
                old = seed['priority'][index]
                assert row['origin'] == {'type': 'frozen251', 'record_index': index, 'file_sha256': seed_sha}
                assert row['tree'] == old['tree'] and E == old['envelope']
                assert row['order'] == old['order'] + list(range(7, source.m))
            else:
                assert row['origin']['type'] == 'scalar_oracle'
            library.append({k: row[k] for k in ('policy_id', 'envelope', 'order', 'support', 'origin')})
            nodes += n
            leaves += l
    assert len(library) >= len(seed['priority']) == 6
    return library, {'policies': len(library), 'tree_nodes_replayed': nodes,
                     'reachable_leaves_replayed': leaves, 'seed_policies': len(seed['priority']),
                     'library_is_complete_priority_frontier': False}


def push_children(stack, context, policy_id, paths):
    address, selected, _, _ = context
    assert paths and paths == sorted(set(paths))
    for index in reversed(range(len(paths))):
        path = paths[index]
        stack.append((address + [index], selected + [[policy_id, path]], address, path))


def context_check(row, ci, U, context):
    address, selected, parent, via = context
    assert row['cone_index'] == ci and row['U'] == U and row['address'] == address
    assert row['selected_constraints'] == selected
    assert row['parent_address'] == parent and row['via_path'] == via


def coverage_audit(path, adaptive, library, full, menus, historical, budget, p):
    target = F(5, 4)
    node_index = 0
    active_library = 6
    oracle_orders = oracle_states = 0
    actions = Counter()
    completed = inherited = 0
    incomplete = None
    assert len(full['cones']) <= len(adaptive)
    source_complete = full['status'] == 'COMPLETE_FULL11_UPPER_AND_MATCHING_LOWER_PENDING_INDEPENDENT_QA'
    with gzip.open(path, 'rt', encoding='utf-8') as stream:
        for ci, cone in enumerate(full['cones']):
            budget.check()
            E = adaptive[ci]
            U = union(E, 11)
            assert cone['cone_index'] == ci and cone['envelope'] == E and cone['U'] == U
            assert cone['nodes_before'] == node_index
            added = [q for q in U if q >= 7]
            if len(added) <= 1:
                menu = inherited_menu(U, menus)
                closure = cone['closure']
                old_index = 0 if not added else 6 + added[0] - 7
                expected_id = 'seven' if not added else added[0] - 7
                assert cone['complete'] is True and closure['type'] == 'inherited_old_menu'
                assert closure['menu_id'] == expected_id
                assert closure['old_to_full_coordinates'] == menu['coordinates']
                assert closure['historical_binding_index'] == old_index
                assert closure['old_result_sha256'] == historical[old_index]['sha256']
                assert closure['old_result_sha256'] == menu['producer_result_sha256']
                assert rational(closure['universal_upper']) == target
                inherited += 1
            else:
                stack = [([], [], None, None)]
                while stack:
                    budget.check()
                    context = stack.pop()
                    line = next(stream, None)
                    if line is None:
                        incomplete = {'cone_index': ci, 'reason': 'MISSING_UNWRITTEN_NODE_PREFIX',
                                      'next_address': context[0], 'pending_subtrees': len(stack) + 1}
                        break
                    assert line.endswith('\n')
                    row = json.loads(line)
                    assert row['node_index'] == node_index
                    context_check(row, ci, U, context)
                    for policy_id, selected_path in context[1]:
                        assert 0 <= policy_id < active_library
                        assert selected_path in library[policy_id]['envelope']
                        assert set(library[policy_id]['support']) <= set(U)
                    upper, cU = certificate(E, U, [path for _, path in context[1]], row['certificate'])
                    prices = [F(0)] * 11
                    for q, cost in zip(U, cU):
                        prices[q] = cost
                    before, after = row['library_count_before'], row['library_count_after']
                    assert type(before) is int and type(after) is int
                    assert before == active_library and before <= after <= min(before + 1, len(library))
                    if upper <= target:
                        assert row['action'] == 'bound_leaf'
                        assert row['branch_policy_id'] is None and row['child_paths'] == []
                        assert row['oracle'] is None and after == before
                    else:
                        assert row['action'] in ('branch', 'unresolved')
                        oracle = row['oracle']
                        assert oracle['library_count_before'] == before and oracle['library_count_after'] == after
                        evaluated = oracle['orders_evaluated']
                        assert type(evaluated) is int and 0 <= evaluated <= p['oracle_orders_per_node_cap']
                        improving = [j for j in range(before) if set(library[j]['support']) <= set(U)
                                     and value(library[j]['envelope'], prices) < upper]
                        if oracle['source'] == 'existing_library':
                            assert evaluated == 0 and after == before and improving
                            assert row['action'] == 'branch' and row['branch_policy_id'] == improving[0]
                        else:
                            assert oracle['source'] == 'scalar_oracle' and not improving
                            states = oracle['scalar_states']
                            assert type(states) is int and states >= 0
                            oracle_states += states
                            if row['action'] == 'branch':
                                assert evaluated > 0 and after == before + 1
                                policy_id = row['branch_policy_id']
                                assert policy_id == before and oracle['stop'] == 'IMPROVING_LEGAL_POLICY'
                                origin = library[policy_id]['origin']
                                assert origin['cone_index'] == ci and origin['address'] == context[0]
                                assert origin['node_index'] == node_index and origin['order_ordinal_at_node'] == evaluated - 1
                                assert rational(origin['cost_at_discovery']) == value(library[policy_id]['envelope'], prices)
                            else:
                                assert after == before
                                assert oracle['stop'] in ('GLOBAL_ORACLE_CAP', 'NODE_ORACLE_CAP_OR_POOL_EXHAUSTED')
                        oracle_orders += evaluated
                        assert oracle_orders <= p['oracle_orders_total_cap']
                        if row['action'] == 'branch':
                            policy_id = row['branch_policy_id']
                            assert type(policy_id) is int and 0 <= policy_id < after
                            assert policy_id not in [j for j, _ in context[1]]
                            policy = library[policy_id]
                            assert set(policy['support']) <= set(U)
                            assert value(policy['envelope'], prices) < upper
                            assert row['child_paths'] == policy['envelope']
                            push_children(stack, context, policy_id, policy['envelope'])
                        else:
                            assert row['branch_policy_id'] is None and row['child_paths'] == []
                            incomplete = {'cone_index': ci, 'reason': 'EXPLICIT_UNRESOLVED_NOT_A_GAP',
                                          'address': context[0], 'pending_subtrees': len(stack) + 1,
                                          'node_upper': str(upper)}
                    active_library = after
                    actions[row['action']] += 1
                    node_index += 1
                    assert node_index <= p['BB_node_cap']
                    if incomplete is not None:
                        break
                if incomplete is not None:
                    assert not source_complete and cone['complete'] is False
                    assert ci == len(full['cones']) - 1
                    break
                assert cone['complete'] is True
                assert cone['closure']['type'] == 'complete_library_BB'
                assert rational(cone['closure']['universal_upper']) == target
            assert cone['nodes_after'] == node_index
            completed += 1
        assert stream.read() == ''
    assert node_index == full['BB_nodes']
    assert actions['branch'] == full['BB_branches'] and actions['bound_leaf'] == full['BB_bound_leaves']
    assert len(library) == full['policies']
    assert oracle_orders <= full['oracle_orders'] and oracle_states <= full['oracle_states']
    assert active_library <= len(library)
    if source_complete:
        assert oracle_orders == full['oracle_orders'] and oracle_states == full['oracle_states']
        assert active_library == len(library)
    complete = incomplete is None and completed == len(adaptive)
    assert not source_complete or complete
    return {'complete_upper': complete, 'AD_cones': len(adaptive), 'completed_cones': completed,
            'inherited_cones': inherited, 'completed_library_BB_cones': completed - inherited,
            'nodes_checked': node_index, 'actions': dict(actions), 'incomplete': incomplete,
            'not_started_cones': len(adaptive) - len(full['cones']),
            'archived_node_oracle_orders': oracle_orders,
            'archived_node_oracle_states': oracle_states,
            'reported_unarchived_tail_oracle_orders': full['oracle_orders'] - oracle_orders,
            'reported_unarchived_tail_oracle_states': full['oracle_states'] - oracle_states,
            'valid_unreferenced_tail_policies': len(library) - active_library,
            'oracle_optimality_or_failed_order_costs_recomputed': False,
            'oracle_optimality_needed_for_upper_soundness': False}


def main():
    assert sys.dont_write_bytecode, 'Require -B'
    protocol_path = HERE / 'LIBRARY_UPPER_QA_PROTOCOL_V01.json'
    p = json.loads(protocol_path.read_text(encoding='utf-8'))
    assert sha(__file__) == p['script_sha256']
    assert sha(HERE.parent / 'ROOT_SCOPE_V01.json') == p['root_scope_sha256']
    producer_dir = HERE.parent / 'producer'
    pp_path = producer_dir / 'FULL_MENU_PROTOCOL_V01.json'
    assert sha(pp_path) == p['producer_protocol_sha256']
    assert sha(producer_dir / 'full_menu_upper_v01.py') == p['producer_script_sha256']
    pp = json.loads(pp_path.read_text(encoding='utf-8'))
    assert pp['full_A'] == p['full_A'] and pp['full_B'] == p['full_B']
    assert sha(HERE.parent / 'theory/GROUP_STATE_LIBRARY_AND_INHERITANCE_PROOF_V01.json') == p['theory_sha256']
    budget = Budget(p)
    result = {'schema': 1, 'status': 'INCOMPLETE_OR_FAILED', 'script_sha256': sha(__file__),
              'protocol_sha256': sha(protocol_path), 'full_upper_established': False,
              'full_priority_frontier_enumerated': False, 'new_lower_from_library': False}
    solver = None
    try:
        budget.check(force=True)
        result['controls'] = controls(budget, p)
        historical = pp['historical_inputs']
        for item in historical:
            path = Path(item['path'])
            assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256']
        source = GroupSource(p['full_A'], p['full_B'])
        assert list(map(len, source.world_signatures())) == [8, 8]
        menus, lower = old_theorems(p, source)
        result['true_lower'] = lower
        summary_path = producer_dir / 'FULL_MENU_RESULT_V01.json'
        summary = json.loads(summary_path.read_text(encoding='utf-8'))
        assert summary['protocol_sha256'] == sha(pp_path)
        result['producer_summary_sha256'] = sha(summary_path)
        external_root = Path(p['external_root'])
        full_path = external_file(summary['full_result'], external_root)
        full = json.loads(full_path.read_text(encoding='utf-8'))
        assert full['protocol_sha256'] == sha(pp_path) and full['status'] == summary['status']
        assert full['priority_frontier_complete'] is False and full['new_lower_bound_from_library'] is False
        result['producer_full_result_binding'] = summary['full_result']
        result['producer_failure'] = full['failure']
        external = {}
        for item in full['external_evidence']:
            path = external_file(item, external_root)
            assert path.name not in external
            external[path.name] = path
        result['external_bindings'] = full['external_evidence']
        assert full['AD_complete'] is True, 'PRODUCER_AD_INCOMPLETE_UNRESOLVED'
        assert 'AD_FRONTIER_V01.json' in external
        raw_ad = json.loads(external['AD_FRONTIER_V01.json'].read_text(encoding='utf-8'))
        assert raw_ad['AD_complete'] is True and raw_ad['protocol_sha256'] == sha(pp_path)
        assert [raw_ad['A_worlds'], raw_ad['B_worlds']] == source.world_signatures()
        started_ad = time.monotonic()
        solver = Adaptive(source, budget, p)
        adaptive = masks(solver.solve(source.root))
        assert adaptive == raw_ad['adaptive_frontier'] and len(adaptive) == full['AD_envelopes']
        result.update(AD_complete=True, AD_envelopes=len(adaptive),
                      independent_AD_seconds=time.monotonic() - started_ad,
                      AD_group_states=solver.states, AD_products=solver.products,
                      AD_largest_state_frontier=solver.largest_frontier,
                      interned_paid_sets=len(solver.paid_sets),
                      literal_group_transition_checks=source.transition_checks,
                      adaptive_frontier_sha256=hashlib.sha256(json.dumps(adaptive, separators=(',', ':')).encode()).hexdigest())
        print(json.dumps({'stage': 'INDEPENDENT_AD_COMPLETE', 'envelopes': len(adaptive),
                          'seconds': result['independent_AD_seconds'], 'states': solver.states}), flush=True)
        solver.solve.cache_clear()
        gc.collect()
        initial = list(map(rational, p['true_lower_prices']))
        assert min(value(E, initial) for E in adaptive) == 4
        assert full['true_lower_witness']['prices'] == p['true_lower_prices']
        assert all(rational(full['true_lower_witness'][k]) == v for k, v in
                   [('full_AD', 4), ('old_AD', 4), ('old_priority', 5), ('full_priority', 5), ('ratio', F(5, 4))])
        required = {'AD_FRONTIER_V01.json', 'POLICY_LIBRARY_V01.jsonl.gz', 'BB_NODES_V01.jsonl.gz'}
        assert set(external) == required, 'MISSING_LIBRARY_OR_BB_PREFIX_UNRESOLVED'
        seed_path = Path(historical[1]['path'])
        seed = json.loads(seed_path.read_text(encoding='utf-8'))
        library, lib_evidence = library_audit(external['POLICY_LIBRARY_V01.jsonl.gz'], source, seed,
                                             historical[1]['sha256'], budget, p)
        result['library'] = lib_evidence
        coverage = coverage_audit(external['BB_NODES_V01.jsonl.gz'], adaptive, library, full,
                                  menus, historical, budget, p)
        result['coverage'] = coverage
        if coverage['complete_upper']:
            assert full['status'] == 'COMPLETE_FULL11_UPPER_AND_MATCHING_LOWER_PENDING_INDEPENDENT_QA'
            assert full['failure'] is None and rational(full['exact_supremum']) == F(5, 4)
            result.update(status='PASS_COMPLETE_FULL11_UPPER_AND_TRUE_MATCHING_LOWER',
                          full_upper_established=True, exact_supremum='5/4',
                          intermediate_menus_corollary=16)
        else:
            assert full['status'] == 'UNRESOLVED' and full['failure'] is not None
            result['status'] = 'PASS_VALID_PARTIAL_EVIDENCE_FULL_UPPER_UNRESOLVED'
    except Exception as exc:
        result['failure'] = {'type': type(exc).__name__, 'message': str(exc)}
    finally:
        if solver is not None:
            solver.solve.cache_clear()
        gc.collect()
    result.update(wall_seconds=time.monotonic() - budget.start, peak_working_set_bytes=budget.peak,
                  producer_math_helpers_imported=False, LP_solver_used=False,
                  oracle_prices_are_not_new_samples=True, old_experiments_rerun=False,
                  arbitrary_graph_bound=False, novelty_claim=False, API_calls=0, P1_access=False)
    encoded = (json.dumps(result, separators=(',', ':'), allow_nan=False) + '\n').encode()
    assert sum(f.stat().st_size for f in HERE.rglob('*') if f.is_file()) + len(encoded) <= p['local_cap_bytes']
    dest = HERE / 'LIBRARY_UPPER_QA_RESULT_V01.json'
    with dest.open('xb') as stream:
        stream.write(encoded)
    print(json.dumps({'status': result['status'], 'seconds': result['wall_seconds'],
                      'sha256': sha(dest), 'failure': result.get('failure')}), flush=True)
    if result['status'] != 'PASS_COMPLETE_FULL11_UPPER_AND_TRUE_MATCHING_LOWER':
        raise SystemExit(2)


if __name__ == '__main__':
    main()
