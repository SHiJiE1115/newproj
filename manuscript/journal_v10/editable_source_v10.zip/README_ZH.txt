V10 editable source: reviewed public reading release

The paper has34pages and13numbered results. The original11statements and proofs are retained. AppendixGadds exact certificate-completion comparisons on the specified complete seven-query source. The body credits the existing2026completion framework; no general framework or literature-priority claim is made.

Build with Python3.10+ and an installed LaTeX distribution:
 python build_source_portable_v01.py --out /absolute/fresh/build/directory
Use --regenerate-bibliography after bibliography edits; that option needs BibTeX. No packages are installed automatically and shell escape is disabled. The original private editable packet was actually compiled in a fresh directory, with all34page texts identical to the reviewed PDF. This public packaging changes only this README and its manifest; all build inputs, PDF and the inner frozen certificate packet are byte-identical.

The inner certificate snapshot retains its pre-deposit provenance, including private/not-yet-uploaded fields at that earlier check time. Current publication and subsequent execution status are recorded in the repository's versioned public README files. Those old flags are not rewritten as retrospective evidence of publication or human review.

The complete six-query archive and other older supplements are linked from the paper and RESEARCH_INDEX.md; they are not all included in this editing packet. Source compilation is separate from scientific proof replay. Author facts and final approval remain pending; this is not a submitted or accepted article. Practical academic-evaluation advantage and precise literature priority remain unestablished. The publisher template and original notices are retained.
