"""Build the supplied source in a fresh directory, without automatic installs."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

HERE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--out', required=True, help='A fresh build directory that does not exist')
parser.add_argument('--tex-engine', default='pdflatex')
parser.add_argument('--regenerate-bibliography', action='store_true')
args = parser.parse_args()
out = Path(args.out).resolve()
assert not out.exists(), 'Use a fresh directory; existing files are not overwritten'
engine = shutil.which(args.tex_engine)
assert engine, 'Install/configure a LaTeX distribution before building; this script does not install one'
version = subprocess.run([engine, '--version'], capture_output=True, text=True, errors='replace', timeout=20)
assert version.returncode == 0
is_miktex = 'miktex' in version.stdout.lower()
options = ['--disable-installer', '--disable-write18'] if is_miktex else ['-no-shell-escape']
out.mkdir(parents=True)
for name in ['paper.tex', 'references.bib', 'sn-jnl.cls', 'sn-mathphys-num.bst', 'paper.bbl']:
    shutil.copyfile(HERE / name, out / name)
for file in sorted((HERE / 'runtime').iterdir()):
    if file.is_file():
        shutil.copyfile(file, out / file.name)
stages = []
receipt = {'status': 'BUILD_PENDING', 'source_sha256': hashlib.sha256((HERE / 'paper.tex').read_bytes()).hexdigest(),
           'bibliography_sha256': hashlib.sha256((HERE / 'references.bib').read_bytes()).hexdigest(),
           'uses_reviewed_bbl': not args.regenerate_bibliography, 'automatic_installs': False,
           'shell_escape': False, 'engine_version': version.stdout, 'stages': stages}


def run(name, command):
    begin = time.monotonic()
    with (out / (name + '.stdout.txt')).open('xb') as stdout, (out / (name + '.stderr.txt')).open('xb') as stderr:
        child = subprocess.Popen(command, cwd=out, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
            env={**os.environ, 'TEMP': str(out), 'TMP': str(out), 'TMPDIR': str(out)})
        timed_out = False
        try:
            code = child.wait(timeout=60)
        except subprocess.TimeoutExpired:
            timed_out = True
            child.kill()
            code = child.wait()
    stages.append({'stage': name, 'argv': command, 'pid': child.pid, 'retained_Popen_wait': True,
                   'actual_exit_code': code, 'timed_out': timed_out, 'wall_seconds': time.monotonic() - begin})
    assert code == 0 and not timed_out, 'Actual build stage failed; logs are retained'


try:
    command = [engine] + options + ['-interaction=nonstopmode', '-halt-on-error', 'paper.tex']
    run('compile1', command)
    if args.regenerate_bibliography:
        candidate = Path(engine).parent / ('bibtex.exe' if os.name == 'nt' else 'bibtex')
        bibtex = str(candidate) if candidate.is_file() else shutil.which('bibtex')
        assert bibtex, 'BibTeX is required to regenerate the bibliography'
        run('bibtex', [bibtex] + (['--disable-installer'] if is_miktex else []) + ['paper'])
        raw = (out / 'paper.bbl').read_bytes()
        (out / 'paper.bbl.before_location_adapter').write_bytes(raw)
        cleaned = raw.replace(b', \\blocation{???}', b'')
        assert cleaned.count(b'\\bibitem') == raw.count(b'\\bibitem') and b'???' not in cleaned
        (out / 'paper.bbl').write_bytes(cleaned)
        receipt['bibliography_adapter'] = 'Remove only absent publisher-location placeholders, preserving every bibliographic entry'
    run('compile2', command)
    run('compile3', command)
    log = (out / 'paper.log').read_text(errors='replace')
    forbidden = ['Overfull', 'undefined references', 'undefined citations', 'Missing character:', 'LaTeX Error:']
    issues = [line for line in log.splitlines() if any(needle in line for needle in forbidden)]
    assert not issues, 'Review retained compile log'
    receipt.update(status='PASS_FRESH_SOURCE_BUILD', pdf_sha256=hashlib.sha256((out / 'paper.pdf').read_bytes()).hexdigest(), issues=issues)
except BaseException as exc:
    receipt.update(status='FAILED_SOURCE_BUILD_PRESERVED', error=type(exc).__name__ + ': ' + str(exc))
with (out / 'PORTABLE_BUILD_RECEIPT_V01.json').open('x', encoding='utf-8') as stream:
    json.dump(receipt, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps({'status': receipt['status'], 'stages': stages}), flush=True)
raise SystemExit(0 if receipt['status'] == 'PASS_FRESH_SOURCE_BUILD' else 1)
