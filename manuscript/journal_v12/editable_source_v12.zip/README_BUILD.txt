Public V12editable manuscript source.39pages,15numbered results.
All nine compile inputs and template/style notice are exact to the reviewed
private V12packet. Only this README and packaging manifest are changed.
Use included reviewed paper.bbl and run pdflatex three times on paper.tex.
The local extracted-source rebuild matched all39page texts/content streams/boxes.
No publisher server conversion, actual author approval or journal submission
is implied. The PDF's private-availability statement describes its build time;
current public small-menu availability is in ../../theory/small_menu_randomization_v01.
See TEMPLATE_SOURCE_NOTICE.md. No new blanket project licence is selected.
