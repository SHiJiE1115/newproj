V13 editable manuscript source (private technical preparation)

All inputs are flat. Compile paper.tex with the supplied sn-jnl.cls, BST,
four style files, references.bib and reviewed paper.bbl. Three pdflatex
passes using this BBL reproduce all40page texts, decoded page content
streams and boxes in the actual relocated build. No shell escape or new
package installation was used. Recreating the bibliography uses the supplied
BST; the recorded adapter omits only comma/whitespace plus absent publisher
location placeholders. No bibliography entry is dropped or invented.

The15numbered statements,12proof environments and5floating tables remain
exactly V12. The CDM citation uses the inspected2025formal journal extension;
other18entries are unchanged. Public availability and actual Linux receipts
are updated, with source/archive and original/derivative distinctions.

Local source build is not publisher server conversion or journal acceptance.
Actual author facts, final declarations and informed human approval remain
user-deferred. This is not human peer review or established priority.
