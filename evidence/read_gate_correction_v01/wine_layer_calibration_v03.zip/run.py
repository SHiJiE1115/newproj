"""Offline relocation replay; references are read only after both children terminate."""
from __future__ import annotations
import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import time

BUNDLE = Path(__file__).resolve().parent
REFERENCE_NAMES = {'references/CANDIDATE_RESULT_V01.json', 'references/BASELINE_RESULT_V02.json'}
MIN_FREE = 64 * 1024 * 1024

def need(ok, message):
    if not ok:
        raise ValueError(message)

def sha(b):
    return hashlib.sha256(b).hexdigest()

def canonical_hash(x):
    return sha(json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode())

def read_json(path):
    def pairs(items):
        out = {}
        for k, v in items:
            need(k not in out, 'DUPLICATE_JSON_KEY:' + k)
            out[k] = v
        return out
    return json.loads(path.read_bytes(), object_pairs_hook=pairs)

def write_json(path, x):
    with path.open('xb') as f:
        f.write((json.dumps(x, indent=2, ensure_ascii=False, allow_nan=False) + '\n').encode())

def desc(path):
    b = path.read_bytes()
    return {'path': path.as_posix(), 'bytes': len(b), 'sha256': sha(b)}

def safe_path(text):
    rel = PurePosixPath(text)
    need(text and str(rel) == text and not rel.is_absolute() and '..' not in rel.parts
         and '\\' not in text and ':' not in text, 'UNSAFE_MANIFEST_PATH')
    path = (BUNDLE / text).resolve()
    need(path.is_relative_to(BUNDLE) and path.is_file(), 'MISSING_OR_OUTSIDE_BUNDLE')
    return path

def inventory(manifest, include_references):
    files = manifest['files']
    names = [x['path'] for x in files]
    need(len(names) == len(set(names)) == 24, 'MANIFEST_COUNT')
    actual = {p.relative_to(BUNDLE).as_posix() for p in BUNDLE.rglob('*') if p.is_file()}
    need(actual == set(names) | {'MANIFEST.json'}, 'EXACT_BUNDLE_INVENTORY')
    for item in files:
        path = safe_path(item['path'])
        if not include_references and item['path'] in REFERENCE_NAMES:
            continue
        b = path.read_bytes()
        need(len(b) == item['bytes'] and sha(b) == item['sha256'], 'MANIFEST_PIN:' + item['path'])

def child(name, command, cwd, logs, env):
    started = datetime.now(timezone.utc).isoformat()
    start = time.perf_counter()
    outcome = {'name': name, 'command': command, 'started_utc': started,
               'attempts': 1, 'automatic_retry': False}
    stdout, stderr = b'', b''
    try:
        completed = subprocess.run(command, cwd=cwd, env=env, capture_output=True, timeout=120)
        stdout, stderr = completed.stdout, completed.stderr
        outcome.update(actual_returncode=completed.returncode, terminal='EXITED')
    except subprocess.TimeoutExpired as e:
        stdout, stderr = e.stdout or b'', e.stderr or b''
        outcome.update(actual_returncode=None, terminal='TIMEOUT_KILLED_AND_WAITED')
    except OSError as e:
        outcome.update(actual_returncode=None, terminal='LAUNCH_ERROR', error=str(e))
    for suffix, b in [('stdout', stdout), ('stderr', stderr)]:
        path = logs / (name + '.' + suffix + '.txt')
        with path.open('xb') as f:
            f.write(b)
        outcome[suffix] = desc(path)
    outcome.update(ended_utc=datetime.now(timezone.utc).isoformat(), elapsed_seconds=time.perf_counter()-start)
    write_json(logs / (name + '.process.json'), outcome)
    return outcome

def scope(snapshot):
    return {'scope_id': 'wine-retrospective-layer-calibration', 'scope_version': 'iteration302-v01',
        'snapshot_digest': snapshot, 'assumptions': [
        'A single explicit fact projection, not an exhaustive model of physical or historical worlds.',
        'Only scoped predicates supported by pinned archived material are admitted.',
        'The certificate checker checks semantic certificates; it does not authenticate the adapter facts.']}

def rebind_certificate(cert, snapshot):
    bound = copy.deepcopy(cert)
    bound['snapshot_digest'] = snapshot
    bound['scope_digest'] = canonical_hash(scope(snapshot))
    request = {'rule_version': bound['rule_version'], 'scope': bound['scope_digest'],
        'claim': bound['claim_digest'], 'records': bound['records_digest'], 'worlds': bound['worlds_digest'],
        'predicate': bound['predicate'], 'r': bound['replication_r'], 'quantifier': bound['quantifier'],
        'max_world_checks': bound['max_world_checks'], 'max_group_candidates': bound['max_group_candidates']}
    bound['input_digest'] = canonical_hash(request)
    bound['certificate_digest'] = ''
    bound['certificate_digest'] = canonical_hash(bound)
    return bound

def compare_candidate(old, new, p, new_protocol_sha):
    expected = copy.deepcopy(old)
    old_sha = p['portability']['original_protocol_sha256']
    need(old['protocol_sha256'] == old_sha and new['protocol_sha256'] == new_protocol_sha,
         'CANDIDATE_PROTOCOL_BINDING')
    expected['protocol_sha256'] = new_protocol_sha
    certificates = []
    allowed = {'snapshot_digest', 'scope_digest', 'input_digest', 'certificate_digest'}
    need(len(old['scenarios']) == len(new['scenarios']) == 6, 'CANDIDATE_SCENARIO_COUNT')
    for o, e, n in zip(old['scenarios'], expected['scenarios'], new['scenarios']):
        need(o['id'] == n['id'] and set(o['semantic_certificates']) == set(p['claim_layers']), 'CERTIFICATE_LAYER_SET')
        # V02 only: add the typed-exit diagnostics emitted on unchanged valid v01 inputs.
        exit_names = {'acceptance.download_exit', 'acceptance.verify_exit', 'gate_retained_crypto_exit'}
        expected_signature_sources = {'v07': 'v07', 'v08': 'v08', 'v09': 'v09',
            'mixed_identity': 'v09', 'mixed_output': 'v09', 'duplicate_v09': 'v09'}
        need(o['id'] in expected_signature_sources and
             o['retained_signature']['source'] == expected_signature_sources[o['id']],
             'OLD_SIGNATURE_SOURCE')
        matched = [edge for edge in e['retained_signature']['checks'] if edge['edge'] in exit_names]
        expected_count = 3 if expected_signature_sources[o['id']] == 'v09' else 0
        need(len(matched) == expected_count and len({x['edge'] for x in matched}) == expected_count,
             'EXACT_TYPED_EXIT_EDGE_SET')
        if expected_count:
            need({x['edge'] for x in matched} == exit_names, 'EXACT_TYPED_EXIT_NAMES')
        for edge in matched:
            need(set(edge) == {'edge', 'observed', 'expected', 'passed'} and
                 type(edge['observed']) is int and edge['observed'] == 0 and
                 type(edge['expected']) is int and edge['expected'] == 0 and edge['passed'] is True,
                 'OLD_SUCCESSFUL_INTEGER_EXIT_REQUIRED')
            edge['required_type'] = 'integer'
            edge['observed_type'] = 'int'
        for layer in p['claim_layers']:
            before = o['semantic_certificates'][layer]['certificate']
            need(before == rebind_certificate(before, old_sha), 'OLD_CERTIFICATE_HASH_FORMULA')
            rebound = rebind_certificate(before, new_protocol_sha)
            after = n['semantic_certificates'][layer]['certificate']
            need(after == rebound, 'EXACT_CERTIFICATE_REBIND:' + o['id'] + ':' + layer)
            changed = {k for k in before if before[k] != after[k]}
            need(changed == allowed, 'EXACT_FOUR_CERTIFICATE_FIELDS')
            need(n['semantic_certificates'][layer]['checker'] == {'valid': True, 'errors': []}, 'ACTUAL_NEW_CHECKER_RESULT')
            e['semantic_certificates'][layer]['certificate'] = rebound
            certificates.append({'scenario': o['id'], 'layer': layer,
                'old': {k: before[k] for k in sorted(allowed)}, 'new': {k: after[k] for k in sorted(allowed)}})
    need(len(certificates) == 30 and expected == new, 'CANDIDATE_FULL_REPORT_AFTER_EXACT_REBIND')
    return {'status': 'PASS', 'entire_report_equal_after_explicit_rebinding': True,
        'changed_top_level_field': 'protocol_sha256', 'changed_certificate_fields': sorted(allowed),
        'additional_exact_change': {'kind': 'typed_exit_diagnostic_fields', 'edge_count': 12,
            'fields': {'required_type': 'integer', 'observed_type': 'int'}},
        'certificate_count': 30, 'certificates': certificates,
        'note': 'Digest formulas checked; the child also ran the unchanged independent semantic certificate checker. No extractor truth or historical completeness is certified.'}

def compare_baseline(old, new, p, output):
    expected = copy.deepcopy(old)
    actual = copy.deepcopy(new)
    need(actual['protocol'] == desc(BUNDLE/'protocol.json'), 'BASELINE_NEW_PROTOCOL_DESCRIPTOR')
    need(actual['script'] == desc(BUNDLE/'sql_baseline_v02.py'), 'BASELINE_NEW_SCRIPT_DESCRIPTOR')
    need(actual['resource_check'] == desc(output/'RESOURCE_CHECK.json'), 'BASELINE_NEW_RESOURCE_DESCRIPTOR')
    need('guard' in expected and 'guard' not in actual, 'ADMINISTRATIVE_RESOURCE_CHANGE')
    specs = [d for r in p['runs'].values() for d in r['files'].values()]
    specs += list(p['v09_retained_signature_files'].values()) + list(p['existing_semantic_modules'].values())
    need(len(expected['original_input_bindings']) == len(actual['original_input_bindings']) == len(specs) == 17,
         'BASELINE_INPUT_COUNT')
    for prior, now, spec in zip(expected['original_input_bindings'], actual['original_input_bindings'], specs):
        need(now['path'] == safe_path(spec['path']).as_posix(), 'BASELINE_RESOLVED_INPUT')
        need(prior['bytes'] == spec['bytes'] and prior['sha256_before'] == spec['sha256']
             and prior['sha256_after'] == spec['sha256'] and prior['unchanged'] is True, 'OLD_BASELINE_INPUT_PIN')
        prior['path'] = now['path']
    # V03: derive only the added read-gate diagnostic from the pinned original reports.
    # Existing flags, missing/false entries, statuses and scientific conclusions are retained.
    scenario_contract = {s['id']: s for s in p['scenarios']}
    need(len(scenario_contract) == 6 and len(expected['scenarios']) == 6, 'READ_EXTENSION_SCENARIOS')
    read_extensions = []
    old_flag_order = [('candidate', k) for k in ['author_execve_same_pid', 'wine_open_observed',
        'wine_positive_read_observed', 'execve_wine_order']] + [('direct', k) for k in
        ['author_execve_same_pid', 'wine_open_and_read', 'execve_wine_order']]
    extra = 'candidate.trace_isolation_observed'
    for row in expected['scenarios']:
        source = scenario_contract[row['id']]['read']
        retained = read_json(safe_path(p['runs'][source]['files']['CANDIDATE_REPORT.json']['path']))
        checks = retained['receipt_audit']['checks']
        present = 'trace_isolation_observed' in checks
        value = checks.get('trace_isolation_observed')
        diag = row['diagnostics']['selected_read_gate']
        need([(f['report'], f['field']) for f in diag['flags']] == old_flag_order,
             'OLD_READ_FLAG_ORDER')
        need(extra not in diag['missing_flags'] and extra not in diag['false_flags'],
             'READ_FLAG_NOT_PREVIOUSLY_PRESENT')
        diag['flags'].insert(4, {'report': 'candidate', 'field': 'trace_isolation_observed', 'value': value})
        destination = 'missing_flags' if not present else ('false_flags' if value is not True else None)
        if destination:
            entries = diag[destination]
            cut = next((i for i, name in enumerate(entries) if name.startswith('direct.')), len(entries))
            entries.insert(cut, extra)
        positive = not diag['missing_flags'] and not diag['false_flags'] and all(
            s == 'PASS_PROSPECTIVE_STRACE_OBSERVATION_ONLY' for s in diag['retained_statuses'])
        detail = 'PASSED' if positive else ('UNAVAILABLE' if diag['missing_flags'] else 'NOT_PASSED')
        need(diag['positive'] is positive and diag['component_positive_before_target_join'] is positive
             and diag['detail_status'] == detail, 'ORIGINAL_READ_OUTCOME_CHANGED')
        read_extensions.append({'scenario': row['id'], 'retained_source': source, 'present': present,
            'value': value, 'added_diagnostic': destination})
    del expected['guard']
    del actual['resource_check']
    for key in ['protocol', 'script', 'elapsed_seconds', 'completed_at_utc']:
        del expected[key]
        del actual[key]
    need(expected == actual, 'BASELINE_ALL_SCIENTIFIC_AND_DIAGNOSTIC_FIELDS_EQUAL')
    return {'status': 'PASS', 'all_fields_equal_after_explicit_read_gate_extension': True,
        'read_gate_diagnostic_extensions': read_extensions, 'input_path_relocations': 17,
        'administrative_changes': ['protocol/script descriptors', 'guard replaced by fresh output-volume resource_check',
                                   'input descriptor path resolution', 'elapsed_seconds and completed_at_utc'],
        'old_guard_not_reused_as_current_permission': True}

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output', required=True, type=Path)
    args = ap.parse_args()
    output = args.output.resolve()
    need(not output.exists() and not output.is_relative_to(BUNDLE), 'OUTPUT_MUST_BE_NEW_AND_OUTSIDE_BUNDLE')
    need(output.parent.is_dir(), 'OUTPUT_PARENT_MUST_EXIST')
    need(shutil.disk_usage(output.parent).free >= MIN_FREE, 'INSUFFICIENT_OUTPUT_VOLUME_FREE_BYTES')
    output.mkdir()
    result = {'schema': 1, 'status': 'FAIL', 'human_review': False, 'new_scientific_sample': False,
              'fresh_signature_verification': False, 'fresh_physical_execution': False, 'children': []}
    started = time.perf_counter()
    try:
        manifest_bytes = (BUNDLE/'MANIFEST.json').read_bytes()
        manifest = read_json(BUNDLE/'MANIFEST.json')
        inventory(manifest, include_references=False)
        p = read_json(BUNDLE/'protocol.json')
        protocol_sha = sha((BUNDLE/'protocol.json').read_bytes())
        for name in ['candidate', 'baseline', 'logs', 'temp']:
            (output/name).mkdir()
        free = shutil.disk_usage(output).free
        need(free >= MIN_FREE, 'INSUFFICIENT_OUTPUT_VOLUME_FREE_BYTES')
        resource = {'schema': 1, 'status': 'PASS', 'checked_at_utc': datetime.now(timezone.utc).isoformat(),
            'output_directory': (output/'baseline').as_posix(), 'free_bytes': free,
            'minimum_free_bytes': MIN_FREE, 'purpose': 'Fresh administrative output-volume check; not a scientific evidence premise.',
            'replaces_original_machine_guard': True, 'original_guard_replayed': False}
        write_json(output/'RESOURCE_CHECK.json', resource)
        env = os.environ.copy()
        env.update({k: str(output/'temp') for k in ['TMP', 'TEMP', 'TMPDIR']})
        prefix = [sys.executable, '-I', '-X', 'utf8', '-B']
        jobs = [('candidate', prefix + [str(BUNDLE/'layer_candidate.py'), '--protocol', str(BUNDLE/'protocol.json'), '--output', str(output/'candidate')]),
                ('baseline', prefix + [str(BUNDLE/'sql_baseline_v02.py'), '--protocol', str(BUNDLE/'protocol.json'), '--output', str(output/'baseline'), '--resource-check', str(output/'RESOURCE_CHECK.json')])]
        for name, command in jobs:
            result['children'].append(child(name, command, output, output/'logs', env))
        result['both_children_terminal_before_reference_read'] = True
        need(all(c['terminal'] == 'EXITED' and c['actual_returncode'] == 0 for c in result['children']), 'CHILD_TERMINAL_FAILURE')
        # Complete old results are not read until this point. Neither child gets their locations.
        inventory(manifest, include_references=True)
        need((BUNDLE/'MANIFEST.json').read_bytes() == manifest_bytes, 'MANIFEST_CHANGED')
        old_c = read_json(BUNDLE/'references/CANDIDATE_RESULT_V01.json')
        old_b = read_json(BUNDLE/'references/BASELINE_RESULT_V02.json')
        new_c_path = output/'candidate/CANDIDATE_RESULT_V01.json'
        new_b_path = output/'baseline/BASELINE_RESULT_V02.json'
        new_c, new_b = read_json(new_c_path), read_json(new_b_path)
        result['candidate_comparison'] = compare_candidate(old_c, new_c, p, protocol_sha)
        result['baseline_comparison'] = compare_baseline(old_b, new_b, p, output)
        compact = lambda r: [{k: s[k] for k in ['id', 'layers', 'joint_distinct_identity_count']} for s in r['scenarios']]
        need(compact(new_c) == compact(new_b), 'CANDIDATE_BASELINE_30_LABELS_AND_COUNTS')
        result.update(status='PASS_PORTABLE_RETAINED_WINE_CALIBRATION', scenarios=compact(new_c),
            layer_label_count=sum(len(s['layers']) for s in new_c['scenarios']),
            output_files={'candidate': desc(new_c_path), 'baseline': desc(new_b_path)},
            manifest_sha256=sha(manifest_bytes), protocol_sha256=protocol_sha,
            bundle_unchanged_after_children=True, reference_comparison='Exact full reports after declared candidate digest/type diagnostics and SQL isolation-flag extension.',
            bootstrap_scope='Inventory, input/code hashes and output-volume checks are administrative bootstrap; no acquisition-cost study or performance advantage is claimed.')
    except Exception as e:
        result.update(error_type=type(e).__name__, error=str(e))
    result['elapsed_seconds'] = time.perf_counter()-started
    result['ended_utc'] = datetime.now(timezone.utc).isoformat()
    write_json(output/'RESULT.json', result)
    print(json.dumps({'status': result['status'], 'result': desc(output/'RESULT.json'), 'error': result.get('error')}))
    return 0 if result['status'].startswith('PASS_') else 1

if __name__ == '__main__':
    raise SystemExit(main())
