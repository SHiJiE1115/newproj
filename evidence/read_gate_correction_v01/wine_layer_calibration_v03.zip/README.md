# Portable retained Wine evidence calibration: v03

This Python 3.10+ standard-library package preserves the six retrospective
iteration302 scenarios and their thirty layer labels. It derives from v02 and
repairs one omitted mandatory premise in the independent SQL read-gate adapter.
It is a software correctness regression, not a new scientific sample.

## Run from a new directory

Extract the ZIP, including to a directory with spaces if desired, and run:

```text
python -I -X utf8 -B run.py --output "../new wine replay output"
```

The output must be new, outside this package, and have an existing parent.
`run.py` checks the complete 25-file inventory and every source pin. It runs the
candidate and SQL baseline once each in separate sequential processes with
120-second timeouts, retaining stdout, stderr and actual return codes. The SQL
baseline keeps its 60-second cooperative cap. No automatic retries occur.
Neither worker reads the other output or old result references. References are
parsed by the launcher only after both workers terminate. Temporary files use
the output directory. At least 64 MiB of output-volume free space is required;
this administrative check is not a scientific premise or acquisition charge.

## Exact fix and preserved evidence

The retained native Wine protocol requires observer isolation as well as the
selected exec/read/order events. In the pinned native verifier,
`trace_isolation_observed` records observer-directory and trace-file ownership
and permissions. The candidate already required this field. The SQL adapter now
also requires it to be present and exactly Boolean `true`; absence is UNAVAILABLE
and any other value is NOT_PASSED. A missing flag does not prove that physical
isolation or reading did not occur. This adapter consumes retained verification
reports; it does not reparse syscall traces or rerun the original experiment.

Only `sql_baseline_v02.py`, `run.py` and this README change relative to v02 among
the 24 manifest-listed payloads. The baseline filename is retained for compatibility
but its new digest is in this package's manifest. The protocol, all 17 original
evidence/semantic inputs, both old complete result references, and the typed-exit
candidate from v02 remain byte-identical. A new manifest binds the derived package;
the original v01/v02 packages are not overwritten.

The launcher derives the expected new isolation flag from each scenario's pinned
read-source candidate report, placing it after the four existing candidate flags
and before direct flags. It adds a missing/false diagnostic only for this field,
also before direct entries. In the retained data, v07 lacks the flag; v08 and v09
have Boolean `true`. The original layer labels, component admission statuses and
identity counts must remain unchanged. All other SQL scientific and diagnostic
fields remain exact; only known administrative paths, descriptors and clocks are
treated as administrative differences. No arbitrary diagnostic fields are dropped.

The v02 candidate comparison is preserved exactly: thirty semantic certificates
are checked against the original four-field snapshot/scope/request/self-digest
rebinding, and twelve named exit-check diagnostics receive only the declared
`required_type="integer"`, `observed_type="int"` additions. Both full reports are
then compared exactly under these explicit transformations.

## Interpretation and limits

The three retained runs are v07, v08 and v09; v07 has no CSV or author summary.
Two constructed splices and a duplicate reference are implementation controls,
not independent research runs. Identical run references count as one joint
identity; 25 draws are not 25 independent replications. The accepted current
prospective receipt is v09. Historical 2020 execution remains UNRESOLVED.
The same-information fixed SQL baseline and candidate agree on the original
scenarios. No method superiority or adaptive acquisition advantage follows.

Rules-v2.1 and its independent checker verify an explicit admitted fact model,
not the truth of the adapter facts or complete possible histories. The retained
signature material is not freshly cryptographically verified. No trust roots are
refreshed, no network is used, no author code is executed, and no training occurs.
The earlier typed-exit and this isolation-erasure helper controls motivate the
repairs; they are not rerun by this launcher and do not establish general
malformed-input robustness. Original archive paths and public provenance IDs
remain inert text. This is portable evidence, not an anonymized export or OS
isolation claim. Original rights/notices remain; the manifest is an integrity
inventory, not a signature, ownership grant or whole-project open-source license.
