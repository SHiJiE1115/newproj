"""Run the portable retained-file replay once, then compare its scientific projection.

The expected answer is first opened after subprocess termination. Raw source
files are only read by the worker's charged meter, never by this launcher.
"""
from __future__ import annotations
import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time


def sha(data):return hashlib.sha256(data).hexdigest()

def require(value,message):
    if not value:raise ValueError(message)

def descriptor(path):
    data=path.read_bytes()
    return {'path':path.name,'bytes':len(data),'sha256':sha(data)}

def scientific_projection(result):
    projected=copy.deepcopy(result)
    for key in ('started_utc','ended_utc','timings','protocol_sha256','timing_scope'):
        projected.pop(key,None)
    for event in projected.get('acquisition_events',[]):
        event.pop('wall_seconds',None)
        event.pop('python_parent_cpu_seconds',None)
    for checkpoint in projected.get('checkpoints',[]):
        checkpoint.pop('certificate_verification_timing',None)
    for child in projected.get('pdf_subprocesses',[]):
        child.pop('timing',None)
        child.pop('working_directory_and_TEMP',None)
    return projected


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--pdftotext',type=Path,required=True)
    args=ap.parse_args();bundle=Path(__file__).resolve().parent
    output=args.output.resolve();pdf=args.pdftotext.resolve(strict=True)
    require(output!=bundle and bundle not in output.parents,'OUTPUT_MUST_BE_OUTSIDE_BUNDLE')
    require(not output.exists(),'REFUSE_EXISTING_OUTPUT')
    output.mkdir(parents=True,exist_ok=False)
    began=datetime.now(timezone.utc).isoformat();start=time.perf_counter()
    receipt={'schema':1,'status':'FAIL_BEFORE_REPLAY','started_utc':began,'replay_invocations':0,
             'raw_sources_pre_read_by_launcher':False,'expected_read_before_child_terminal':False}
    exitcode=1
    try:
        manifest=json.loads((bundle/'MANIFEST.json').read_bytes())
        entries={row['path']:row for row in manifest['files']}
        require(len(entries)==len(manifest['files'])==13,'MANIFEST_DUPLICATE_OR_COUNT')
        actual={path.relative_to(bundle).as_posix() for path in bundle.rglob('*') if path.is_file()}
        require(actual==set(entries)|{'MANIFEST.json'},'MANIFEST_INVENTORY_MISMATCH')
        protocol=json.loads((bundle/'protocol.json').read_bytes())
        for spec in protocol['sources'].values():
            row=entries[spec['path']]
            require(row['bytes']==spec['bytes'] and row['sha256']==spec['sha256'],'RAW_MANIFEST_PROTOCOL_PIN_MISMATCH')
        for relative,row in entries.items():
            path=(bundle/relative).resolve(strict=True)
            require(bundle in path.parents,'BUNDLE_MEMBER_ESCAPE')
            if relative.startswith('sources/') or relative=='expected_scientific.json':continue
            data=path.read_bytes()
            require(len(data)==row['bytes'] and sha(data)==row['sha256'],'BOOTSTRAP_MANIFEST_MISMATCH:'+relative)
        command=[sys.executable,'-I','-X','utf8','-B',str(bundle/'budget_replay.py'),
                 '--protocol',str(bundle/'protocol.json'),'--output',str(output),'--pdftotext',str(pdf)]
        env=os.environ.copy();env.update(TEMP=str(output),TMP=str(output),TMPDIR=str(output),PYTHONDONTWRITEBYTECODE='1')
        child_start=time.perf_counter();receipt['replay_invocations']=1
        child=subprocess.run(command,cwd=output,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
        child_wall=time.perf_counter()-child_start
        (output/'process.stdout.txt').write_bytes(child.stdout)
        (output/'process.stderr.txt').write_bytes(child.stderr)
        receipt.update(actual_child_returncode=child.returncode,whole_child_process_wall_seconds=child_wall,
             command=command,stdout=descriptor(output/'process.stdout.txt'),stderr=descriptor(output/'process.stderr.txt'))
        require(child.returncode==0,'REPLAY_CHILD_FAILED')
        result_bytes=(output/'RESULT_V01.json').read_bytes();result=json.loads(result_bytes)
        receipt['result']=descriptor(output/'RESULT_V01.json')
        require(result['protocol_sha256']==sha((bundle/'protocol.json').read_bytes()),'RESULT_PROTOCOL_BINDING')
        # This postprocess runs only after the real child has terminated.
        qa_start=time.perf_counter();qa_cpu=time.process_time()
        answer=(bundle/'expected_scientific.json').read_bytes();row=entries['expected_scientific.json']
        require(len(answer)==row['bytes'] and sha(answer)==row['sha256'],'EXPECTED_MANIFEST_MISMATCH')
        expected=json.loads(answer);observed=scientific_projection(result)
        matches=observed==expected['scientific_projection']
        qa={'schema':1,'status':'PASS_SCIENTIFIC_PROJECTION_EQUAL' if matches else 'FAIL_SCIENTIFIC_PROJECTION_MISMATCH',
           'expected_opened_after_child_termination':True,'expected_sha256':sha(answer),
           'result_sha256':sha(result_bytes),'excluded_fields':expected['excluded_fields'],
           'timing':{'wall_seconds':time.perf_counter()-qa_start,'python_parent_cpu_seconds':time.process_time()-qa_cpu},
           'fresh_sample':False,'fresh_historical_authentication':False,'human_review':False}
        (output/'POSTPROCESS_QA_V01.json').write_text(json.dumps(qa,indent=2)+'\n',encoding='utf-8')
        receipt['postprocess_qa']=descriptor(output/'POSTPROCESS_QA_V01.json')
        require(matches,'POSTPROCESS_PROJECTION_MISMATCH')
        receipt['status']='PASS_RELOCATED_REPLAY_AND_POSTPROCESS';exitcode=0
    except Exception as error:
        receipt.update(status='FAIL_PORTABLE_REPLAY_PRESERVED',error_class=type(error).__name__,error=str(error))
    finally:
        receipt.update(ended_utc=datetime.now(timezone.utc).isoformat(),
             launcher_total_wall_seconds=time.perf_counter()-start,launcher_exit_code=exitcode,
             process_tree_cpu_measured=False,network_access=False,
             scope='Relocated replay and subsequent output comparison; no new scientific samples or method advantage.')
        (output/'EXECUTION_V01.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
        print(json.dumps({'status':receipt['status'],'actual_child_returncode':receipt.get('actual_child_returncode'),
              'launcher_exit_code':exitcode,'execution':descriptor(output/'EXECUTION_V01.json')}))
    return exitcode

if __name__=='__main__':raise SystemExit(main())
