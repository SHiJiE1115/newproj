"""Offline, source-pinned verification of five ValueEval paper/run/score rows.

This is a narrow reported-layer certificate. It does not certify the historical
execution of an uploaded prediction or the independence of its provenance.
The five examples were selected post hoc from the earlier 29-paper dev audit.
"""

from __future__ import annotations

import copy
import hashlib
import html
import json
import re
import subprocess
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path


HERE = Path(__file__).resolve().parent
DIAG = HERE.parent
STAGEC = DIAG / "valueeval_cited29_stagec_v01"
FIRST3 = DIAG / "valueeval_first3_paper_bridge_v01"
FRAME = DIAG / "tira_valueeval_full_cohort_frame_v01"
OUTPUT = HERE / "EXACT_ID_FIVE_CERTIFICATE.json"
EXPECTED_ORGANIZER_SHA = "f048152d2579be4d8fefa4c807221831233455de935d4ecb1b57f4a96e651fc8"
EXPECTED_ARCHIVE_SHA = "57c14d4055b28c52f0e644a5ff8a965a06c624d1a8987b79fe6b2be5074616ea"

# This selection and the immutable PDF hashes were taken from the already
# published Stage C projection before this verifier was written. Scores are
# deliberately absent: all three values must be parsed independently below.
CASES = (
    (3, "PAI (Theodor Zwinger)", "pai", "2023-01-27-04-05-18", "2023-01-27-04-07-49", "e7bbfaeceb1b1f8b4b3405130ed947eb60b368fc59552167bef5e91fbf34bdfb"),
    (13, "Søren Kierkegaard", "p13", "2023-01-25-15-47-28", "2023-01-25-15-49-17", "71e13b29f83eec1af659670370d8ccf6ca7d7d9cd041f35b5b9dfe0a586fc8d1"),
    (16, "Andronicus of Rhodes", "p16", "2023-01-28-10-02-00", "2023-01-28-10-03-45", "854b19cd82e0bb159df13833cb5213cb7c33342dca28b24468a03fd159446a29"),
    (35, "Quintilian", "p35", "2023-01-22-02-01-11", "2023-01-23-17-40-43", "2024c639c24de7bf285cbdec14de4e6dfef4c071e68b21480b3e02a26fa3ccce"),
    (41, "Friedrich Nietzsche", "p41", "2023-01-30-08-51-04", "2023-01-30-08-52-53", "f63bfb85abc690d1a1bfdf5b9a7e5e95f74b26567969bfc8257046a10e783375"),
)


class Reject(ValueError):
    pass


def require(condition: bool, reason: str) -> None:
    if not condition:
        raise Reject(reason)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_pinned(path: Path, expected: str) -> bytes:
    content = path.read_bytes()
    require(sha256(content) == expected, f"source hash changed: {path.name}")
    return content


def paper_row(case: tuple, paper_text: str) -> dict:
    ordinal, team, prefix, run_id, evaluation_id, pdf_sha = case
    del team, prefix, evaluation_id, pdf_sha
    lines = paper_text.splitlines()
    pattern = re.compile(r"^\s*" + re.escape(run_id) + r"\s+([.]\d+|0\.\d+|1\.0+)\b")
    matches = [(i, pattern.match(line)) for i, line in enumerate(lines) if pattern.match(line)]
    require(len(matches) == 1, f"ordinal {ordinal}: exact ID row count {len(matches)}")
    row_index, match = matches[0]
    header_indexes = [i for i in range(max(0, row_index - 11), row_index)
                      if re.search(r"Test set\s*/\s*Approach\s+All\b", lines[i], re.I)]
    require(len(header_indexes) == 1, f"ordinal {ordinal}: Main/All header not uniquely nearby")
    header_index = header_indexes[0]
    require(header_index + 1 < len(lines) and lines[header_index + 1].strip() == "Main",
            f"ordinal {ordinal}: nearby dataset is not Main")
    require(row_index - header_index <= 10, f"ordinal {ordinal}: row too far from Main header")
    caption_indexes = [i for i in range(row_index + 1, min(len(lines), row_index + 26))
                       if re.match(r"^Table\s+\d+:\s+Achieved F1", lines[i])]
    require(len(caption_indexes) == 1, f"ordinal {ordinal}: nearby F1 table caption not unique")
    caption_index = caption_indexes[0]
    caption = " ".join(lines[caption_index:caption_index + 3])
    require("test dataset" in caption and "(All)" in caption,
            f"ordinal {ordinal}: caption lacks test/All semantics")
    score = Decimal(match.group(1))
    require(Decimal(0) <= score <= Decimal(1), f"ordinal {ordinal}: invalid paper F1")
    return {
        "paper_main_all_display": str(score.quantize(Decimal("0.01"))),
        "paper_line_1based": row_index + 1,
        "main_header_line_1based": header_index + 1,
        "caption_line_1based": caption_index + 1,
        "row_sha256": sha256(lines[row_index].encode("utf-8")),
        "row_first_value_literal": match.group(1),
    }


def verify_case(case: tuple, paper_text: str, organizer_html: str, archive: dict) -> dict:
    ordinal, team, prefix, run_id, evaluation_id, pdf_sha = case
    del prefix, pdf_sha
    paper = paper_row(case, paper_text)
    row_match = re.findall(
        r"<tr><td>" + re.escape(team) + r"</td><td>" + re.escape(run_id)
        + r"</td><td>([0-9.]+)</td>", organizer_html,
    )
    require(len(row_match) == 1, f"ordinal {ordinal}: organizer exact team/ID row not unique")
    official = Decimal(row_match[0])
    require(paper["paper_main_all_display"] == str(official.quantize(Decimal("0.01"))),
            f"ordinal {ordinal}: paper/organizer display mismatch")
    context = archive.get("context", {})
    require(archive.get("status") == 0 and context.get("dataset_id") == "arguments-test-20221205-test",
            "archive dataset/status mismatch")
    require(context.get("ev_keys", [None])[0] == "F1", "archive first measure is not F1")
    matches = [e for e in context.get("evaluations", []) if e.get("input_run_id") == run_id]
    require(len(matches) == 1, f"ordinal {ordinal}: archive input ID not unique")
    ev = matches[0]
    require(ev.get("run_id") == evaluation_id and ev.get("dataset_id") == context["dataset_id"],
            f"ordinal {ordinal}: archive evaluation/dataset ID mismatch")
    require(ev.get("published") == 1 and ev.get("review_state") == "valid",
            f"ordinal {ordinal}: archived evaluation not publicly valid")
    require(ev.get("is_upload") is True and ev.get("is_software") is False,
            f"ordinal {ordinal}: unexpected archive input type")
    stored = Decimal(str(ev["measures"][0]))
    require(Decimal(0) <= stored <= Decimal(1), f"ordinal {ordinal}: invalid archived F1")
    # A stored three-decimal value has unknown sub-mill precision. These five
    # cases must remain unambiguous even within a +/-0.0005 interval.
    lo = (stored - Decimal("0.0005")).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    hi = (stored + Decimal("0.0005")).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    require(lo == hi == official, f"ordinal {ordinal}: archive precision/display mismatch")
    return {
        "main_ordinal": ordinal,
        "team": team,
        "prediction_run_id": run_id,
        "evaluation_run_id": evaluation_id,
        **paper,
        "organizer_main_display": str(official),
        "archive_stored_f1": str(stored),
        "archive_is_upload": True,
        "historical_execution_certified": False,
        "full_lineage_independence_certified": False,
    }


def main() -> None:
    organizer_bytes = read_pinned(FRAME / "organizer_main.raw", EXPECTED_ORGANIZER_SHA)
    archive_bytes = read_pinned(FRAME / "archive_evaluations.raw", EXPECTED_ARCHIVE_SHA)
    organizer_html = html.unescape(organizer_bytes.decode("utf-8"))
    archive = json.loads(archive_bytes)
    certificates = []
    texts = {}
    for case in CASES:
        ordinal, team, prefix, run_id, evaluation_id, pdf_sha = case
        del team, run_id, evaluation_id
        folder = FIRST3 if ordinal <= 3 else STAGEC
        raw_pdf = folder / f"{prefix}_pdf.raw"
        pdf_bytes = read_pinned(raw_pdf, pdf_sha)
        require(pdf_bytes.startswith(b"%PDF-"), f"ordinal {ordinal}: invalid PDF header")
        paper_text = subprocess.check_output(["pdftotext", "-layout", str(raw_pdf), "-"]).decode("utf-8")
        require(paper_text.encode("utf-8") == (folder / f"{prefix}_pdf.txt").read_bytes(),
                f"ordinal {ordinal}: regenerated PDF text differs")
        texts[ordinal] = paper_text
        certificate = verify_case(case, paper_text, organizer_html, archive)
        certificate["pdf_sha256"] = pdf_sha
        certificate["pdftotext_layout_sha256"] = sha256(paper_text.encode("utf-8"))
        certificates.append(certificate)

    # Synthetic, in-memory controls: alter one derived input at a time; never
    # overwrite the pinned source files or confuse these with real failures.
    case = CASES[0]
    source_text = texts[case[0]]
    source_row = next(line for line in source_text.splitlines()
                      if re.match(r"^\s*" + re.escape(case[3]) + r"\s+[.]\d+", line))
    controls = {
        "paper_wrong_score": (source_text.replace(source_row, source_row.replace(".54", ".53", 1), 1), organizer_html, archive),
        "paper_wrong_id": (source_text.replace(source_row, source_row.replace(case[3], "2023-01-27-04-05-19", 1), 1), organizer_html, archive),
        "paper_duplicate_id_row": (source_text.replace(source_row, source_row + "\n" + source_row, 1), organizer_html, archive),
        "paper_wrong_dataset_heading": (re.sub(r"(Test set / Approach\s+All\r?\n\s*)Main\b", r"\1Dev", source_text, count=1), organizer_html, archive),
        "paper_missing_all_caption": (source_text.replace("recall (All)", "recall (Other)", 1), organizer_html, archive),
        "organizer_wrong_score": (source_text, organizer_html.replace(f"<td>{case[3]}</td><td>0.54</td>", f"<td>{case[3]}</td><td>0.53</td>", 1), archive),
    }
    changed_archive = copy.deepcopy(archive)
    for ev in changed_archive["context"]["evaluations"]:
        if ev["input_run_id"] == case[3]:
            ev["measures"][0] = 0.528
            break
    controls["archive_wrong_f1"] = (source_text, organizer_html, changed_archive)
    control_results = {}
    for name, (paper_text, html_text, archive_json) in controls.items():
        require((paper_text, html_text, archive_json) != (source_text, organizer_html, archive),
                f"negative control did not mutate input: {name}")
        try:
            verify_case(case, paper_text, html_text, archive_json)
        except Reject as exc:
            control_results[name] = {"result": "REJECT", "reason": str(exc)}
        else:
            raise RuntimeError(f"negative control incorrectly accepted: {name}")
    result = {
        "kind": "VALUEEVAL_EXACT_ID_FIVE_REPORTED_LAYER_CERTIFICATE_DEV",
        "selection": "Post hoc subset of the frozen 29-paper Stage C development audit: five author PDFs directly print the leaderboard-selected prediction run ID.",
        "scope": "Pinned PDF row with exact run ID and first Main All F1, current captured organizer leaderboard row, and published valid archived evaluation of uploaded predictions. No historical execution or full lineage attestation.",
        "source_sha256": {"organizer_main_raw": EXPECTED_ORGANIZER_SHA, "archive_evaluations_raw": EXPECTED_ARCHIVE_SHA},
        "certified_reported_rows": len(certificates),
        "cases": certificates,
        "synthetic_negative_controls_rejected": len(control_results),
        "synthetic_negative_controls": control_results,
        "same_information_direct_baseline": "This fixed-source direct verifier itself; no adaptive acquisition or method advantage is claimed.",
        "human_gold": False,
        "historical_execution_certified": 0,
        "full_lineage_independence_certified": 0,
    }
    rendered = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if OUTPUT.exists():
        require(OUTPUT.read_text(encoding="utf-8") == rendered, "certificate output drift")
    else:
        OUTPUT.write_text(rendered, encoding="utf-8")
    print(f"PASS exact_id_reported={len(certificates)} synthetic_reject={len(control_results)} historical=0 independence=0")


if __name__ == "__main__":
    main()
