"""One frozen, seven-original ValueEval budget replay. No network or old TXT input."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import html
import json
import os
from pathlib import Path
import subprocess
import time
import types

PROTOCOL_SHA256='b434e14cc404afec3193ffc40c73184d95959b0493d7621ec3b4091045036c1a'


def sha(b):
    return hashlib.sha256(b).hexdigest()


def require(ok,message):
    if not ok:raise ValueError(message)


def measure(fn):
    wall=time.perf_counter();cpu=time.process_time();value=fn()
    return value,{'wall_seconds':time.perf_counter()-wall,'python_parent_cpu_seconds':time.process_time()-cpu}


def pinned_bootstrap(spec):
    b=Path(spec['path']).read_bytes()
    require(len(b)==spec['bytes'] and sha(b)==spec['sha256'],'BOOTSTRAP_PIN_MISMATCH:'+Path(spec['path']).name)
    return b


class Meter:
    def __init__(self,specs):
        self.specs=specs;self.budget=0;self.paid=0;self.raw_read_count=0
        self.cache={};self.events=[];self.acquisition_timings=[]

    def acquire(self,key):
        require(key not in self.cache,'ALREADY_ACQUIRED:'+key)
        spec=self.specs[key];before_count=self.raw_read_count;before_paid=self.paid
        event={'sequence':len(self.events)+1,'source_key':key,'budget_bytes':self.budget,
          'manifest_bytes':spec['bytes'],'raw_read_count_before':before_count,'paid_bytes_before':before_paid}
        self.events.append(event)
        if self.paid+spec['bytes']>self.budget:
            event.update(outcome='DENIED_BEFORE_READ',raw_read_count_after=self.raw_read_count,paid_bytes_after=self.paid)
            return None
        start=time.perf_counter();cpu=time.process_time()
        self.raw_read_count+=1
        try:
            # This is the sole acquisition/read of any raw scientific source.
            b=Path(spec['path']).read_bytes()
            self.paid+=len(b);digest=sha(b)
            event.update(actual_bytes=len(b),actual_sha256=digest)
            require(len(b)==spec['bytes'] and digest==spec['sha256'],'RAW_SOURCE_PIN_MISMATCH:'+key)
            require(self.paid<=self.budget,'OBSERVED_LENGTH_EXCEEDED_BUDGET')
            self.cache[key]=b;event['outcome']='ACQUIRED_AND_HASH_VERIFIED'
            return b
        finally:
            elapsed={'source_key':key,'wall_seconds':time.perf_counter()-start,
                     'python_parent_cpu_seconds':time.process_time()-cpu}
            self.acquisition_timings.append(elapsed);event.update(elapsed)
            event.update(raw_read_count_after=self.raw_read_count,paid_bytes_after=self.paid)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--protocol',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--pdftotext',type=Path,required=True)
    args=ap.parse_args();start=time.perf_counter();cpu_start=time.process_time()
    args.protocol=args.protocol.resolve();args.output=args.output.resolve()
    args.pdftotext=args.pdftotext.resolve(strict=True)
    require(args.output.is_dir(),'OUTPUT_DIRECTORY_REQUIRED')
    require(not (args.output/'RESULT_V01.json').exists(),'REFUSE_OVERWRITE')
    result={'schema':1,'status':'FAIL_INCOMPLETE','started_utc':datetime.now(timezone.utc).isoformat(),
            'certificates':[],'checkpoints':[],'pdf_subprocesses':[],'timings':{}}
    meter=None;exitcode=1
    try:
        bootstrap_start=time.perf_counter();bootstrap_cpu=time.process_time()
        pb=args.protocol.read_bytes();require(sha(pb)==PROTOCOL_SHA256,'PROTOCOL_PIN_MISMATCH')
        p=json.loads(pb);result['protocol_sha256']=sha(pb)
        bundle=args.protocol.parent
        def local_member(relative):
            require(isinstance(relative,str) and not Path(relative).is_absolute()
                    and '\\' not in relative and ':' not in relative
                    and '..' not in relative.split('/'),'UNSAFE_BUNDLE_PATH')
            resolved=(bundle/relative).resolve(strict=True)
            require(bundle in resolved.parents,'BUNDLE_PATH_ESCAPE')
            return str(resolved)
        for spec in p['sources'].values():spec['path']=local_member(spec['path'])
        p['parser']['path']=local_member(p['parser']['path'])
        p['pdf_executable']['path']=str(args.pdftotext)
        parser_bytes=pinned_bootstrap(p['parser']);pinned_bootstrap(p['pdf_executable'])
        # Import only definitions from the pinned module; its main and mutation controls are not called.
        parser_module=types.ModuleType('iteration303_frozen_pure_parser')
        parser_module.__file__=p['parser']['path']
        exec(compile(parser_bytes,p['parser']['path'],'exec'),parser_module.__dict__)
        verify_case=parser_module.verify_case
        require(tuple(tuple(c['parser_case']) for c in p['cases'])==parser_module.CASES,'PARSER_CASE_BINDING_MISMATCH')
        temp=args.output/'temp';temp.mkdir(exist_ok=False)
        env=os.environ.copy();env.update(TEMP=str(temp),TMP=str(temp),TMPDIR=str(temp),PYTHONDONTWRITEBYTECODE='1')
        result['bootstrap_bindings']={k:{'bytes':p[k]['bytes'],'sha256':p[k]['sha256']} for k in ['parser','pdf_executable']}
        result['timings']['bootstrap']={'wall_seconds':time.perf_counter()-bootstrap_start,
                  'python_parent_cpu_seconds':time.process_time()-bootstrap_cpu}
        pipeline_start=time.perf_counter();pipeline_cpu=time.process_time()
        meter=Meter(p['sources']);meter.budget=p['common_payload_bytes']
        require(p['fixed_order'][:2]==['organizer','archive'],'COMMON_ORDER_MISMATCH')
        organizer=meter.acquire('organizer');archive=meter.acquire('archive')
        require(organizer is not None and archive is not None,'COMMON_ACQUISITION_DENIED')
        def common_parse():return html.unescape(organizer.decode('utf-8')),json.loads(archive)
        (organizer_html,archive_json),common_timing=measure(common_parse)
        result['timings']['common_parse_once']=common_timing
        cases={c['source_key']:c for c in p['cases']}
        require([q['last_source'] for q in p['frontier']]==p['fixed_order'][2:],'FRONTIER_ORDER_MISMATCH')
        result['checkpoints'].append({'kind':'common_only','coverage':0,'paid_bytes':meter.paid,
           'raw_read_count':meter.raw_read_count,'acquired_sources':list(meter.cache)})
        for point in p['frontier']:
            key=point['last_source'];threshold=point['minimum_payload_budget_bytes'];case=cases[key]
            meter.budget=threshold-1;before=(meter.raw_read_count,meter.paid,len(meter.cache))
            denied=meter.acquire(key)
            require(denied is None and before==(meter.raw_read_count,meter.paid,len(meter.cache)),
                    'BOUNDARY_DENIAL_DID_NOT_PRESERVE_READ_STATE')
            result['checkpoints'].append({'kind':'budget_minus_one_denial','source_key':key,
                 'budget_bytes':meter.budget,'coverage':len(result['certificates']),
                 'paid_bytes':meter.paid,'raw_read_count':meter.raw_read_count,'denied_before_read':True})
            meter.budget=threshold;pdf=meter.acquire(key)
            require(pdf is not None and pdf.startswith(b'%PDF-'),'PDF_ACQUISITION_INVALID')
            require(meter.paid==threshold,'EXACT_FRONTIER_COST_MISMATCH')
            require(set(case['required_sources'])<=set(meter.cache),'CERTIFICATE_DEPENDENCIES_NOT_ACQUIRED')
            command=[p['pdf_executable']['path'],'-layout','-','-']
            child_start=time.perf_counter();child_cpu=time.process_time()
            try:
                child=subprocess.run(command,input=pdf,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                     cwd=args.output,env=env,timeout=60,check=False)
                stdout,stderr=child.stdout,child.stderr;returncode=child.returncode;timed_out=False
            except subprocess.TimeoutExpired as error:
                stdout=error.stdout or b'';stderr=error.stderr or b'';returncode=None;timed_out=True
            timing={'wall_seconds':time.perf_counter()-child_start,
                    'python_parent_cpu_seconds':time.process_time()-child_cpu}
            txt_name=key+'_pdf.txt';err_name=key+'_pdftotext.stderr.bin'
            (args.output/txt_name).write_bytes(stdout);(args.output/err_name).write_bytes(stderr)
            record={'source_key':key,'input_mode':'paid_bytes_stdin','stdin_bytes':len(pdf),'stdin_sha256':sha(pdf),
                    'argv_tail':['-layout','-','-'],'executable_sha256':p['pdf_executable']['sha256'],
                    'returncode':returncode,'timed_out':timed_out,'timing':timing,
                    'stdout':{'path':txt_name,'bytes':len(stdout),'sha256':sha(stdout)},
                    'stderr':{'path':err_name,'bytes':len(stderr),'sha256':sha(stderr)},
                    'working_directory_and_TEMP':'output/temp_for_TEMP;output_for_cwd'}
            result['pdf_subprocesses'].append(record)
            require(not timed_out and returncode==0,'PDF_STDIN_EXTRACTION_FAILED:'+key)
            text=stdout.decode('utf-8')
            certificate,cert_timing=measure(lambda:verify_case(tuple(case['parser_case']),text,organizer_html,archive_json))
            certificate.update(pdf_sha256=sha(pdf),pdftotext_layout_sha256=sha(stdout))
            result['certificates'].append(certificate)
            result['checkpoints'].append({'kind':'certificate_emitted','source_key':key,
                  'budget_bytes':threshold,'coverage':len(result['certificates']),'paid_bytes':meter.paid,
                  'raw_read_count':meter.raw_read_count,'acquired_sources':list(meter.cache),
                  'required_sources':case['required_sources'],'certificate_verification_timing':cert_timing})
            require(len(result['certificates'])==point['coverage'],'COVERAGE_MISMATCH')
        result['timings']['pipeline_after_bootstrap']={'wall_seconds':time.perf_counter()-pipeline_start,
                  'python_parent_cpu_seconds':time.process_time()-pipeline_cpu}
        require(meter.raw_read_count==7 and meter.paid==2415058,'FINAL_READ_ACCOUNTING_MISMATCH')
        require([e['source_key'] for e in meter.events if e['outcome']=='ACQUIRED_AND_HASH_VERIFIED']==p['fixed_order'],
                'FINAL_FIXED_ORDER_MISMATCH')
        require(sum(e['outcome']=='DENIED_BEFORE_READ' for e in meter.events)==5,'DENIAL_COUNT_MISMATCH')
        result.update(status='PASS_SCOPED_SEVEN_ORIGINAL_BUDGET_REPLAY',original_reads=7,
           original_payload_bytes=meter.paid,budget_denials=5,certified_reported_rows=len(result['certificates']),
           historical_execution_certified=0,lineage_independence_certified=0,human_gold=False,
           pricing=p['pricing'],optimality_scope=p['optimality_scope'],selection=p['selection'],
           old_txt_or_certificate_read=False,old_controls_executed=False,network_access=False,
           pdf_extraction_from_paid_bytes_only=True,shared_sources_parsed_once=True,
           adaptive_advantage_claimed=False)
        exitcode=0
    except Exception as error:
        result.update(status='FAIL_REPLAY_PRESERVED',error_class=type(error).__name__,error=str(error))
    finally:
        if meter is not None:
            result['acquisition_events']=meter.events
            result['observed_meter_state']={'raw_read_count':meter.raw_read_count,'paid_bytes':meter.paid,
                                           'cached_source_keys':list(meter.cache),'last_budget_bytes':meter.budget}
            result['timings']['raw_acquisition_hash_stages']=meter.acquisition_timings
        result['timings']['main_before_result_serialization']={'wall_seconds':time.perf_counter()-start,
                  'python_parent_cpu_seconds':time.process_time()-cpu_start}
        result['timing_scope']='Main includes separate protocol/parser/executable bootstrap. Python process_time is parent CPU only, not child or process-tree CPU. Launcher EXECUTION records whole child-process wall. Payload acquisition is logical unique bytes, not physical disk IO, HTTP, TLS, discovery or research labor.'
        result['ended_utc']=datetime.now(timezone.utc).isoformat()
        b=(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode()
        (args.output/'RESULT_V01.json').write_bytes(b)
        print(json.dumps({'status':result['status'],'result_sha256':sha(b),'result_bytes':len(b),
                 'original_reads':result.get('original_reads'),'original_payload_bytes':result.get('original_payload_bytes'),
                 'budget_denials':result.get('budget_denials'),'certified_reported_rows':result.get('certified_reported_rows'),
                 'exit_code':exitcode}))
    return exitcode

if __name__=='__main__':raise SystemExit(main())
