# ValueEval: portable seven-original budget replay

This package repeats the frozen iteration303 retained-file calibration. It is a
path/configuration derivative, not another scientific sample or a new method.
The original seven response bodies and the existing exact-ID parser are copied
byte for byte. No download is performed.

## Run once in a new directory

Requirements: Python 3.10 or newer (standard library only), and an **externally
installed MiKTeX Windows pdftotext** with this executable SHA-256:

`640b9a93fa31fc093860c635cd410a3e30f7d1e6166cb1130993fb1985f474ff`

The executable is 343,552 bytes. Its installation and dependent DLLs are external;
this package neither bundles them nor claims that copying the executable alone
is sufficient. Other Poppler builds and operating systems are not validated by
this package. A different executable hash is rejected before source acquisition.

From any working directory, with the extracted package path quoted if needed:

```text
python -I -X utf8 -B "path to package/run.py" --pdftotext "path to installed pdftotext.exe" --output "new output directory"
```

The output directory must not already exist and must be outside the package.
TEMP/TMP and subprocess working data stay under that output. The package is not
modified. The launcher runs the replay exactly once, records its real exit and
stdout/stderr, and only then reads `expected_scientific.json` for postprocess QA.
It never hashes or reads raw sources before the charged meter. Bootstrap reads
of code/configuration are reported separately from payload acquisition.

## Frozen scientific contract

The five exact-ID cases (main ordinals 3, 13, 16, 35, 41) were selected **post hoc
from the prior 29-paper development set**. They are known positive reported-layer
examples. This is not a blind accuracy estimate; the original 29 denominator and
remaining 24 cases are not changed. Every certificate requires the complete
organizer HTML, complete archive JSON, and its complete PDF. Sizes and hashes are
known inputs to this offline replay, not asserted to have been known before the
historical downloads.

The fixed source order is organizer, archive, paper_35, paper_16, paper_41,
paper_3, paper_13. The shared cost is 493,998 bytes. The coverage 1..5 thresholds
are 637,064; 920,962; 1,214,497; 1,721,954; and 2,415,058 bytes. Each PDF is denied
at its threshold minus one before any read, then bought at its exact threshold.
The final original-read count is 7, with 5 denials and 5 certificate emissions.

Each raw object is read and hashed once by the meter. Shared sources are parsed
once. Each PDF is sent as the already acquired bytes to `pdftotext -layout - -`.
The original parser's `verify_case` is called; its `main`, old TXT reads, old
certificate reads and synthetic controls are not called. The parser's old
repository-relative globals remain inert because this pure entry is used.

The fixed direct baseline is optimal for this declared dependency contract:
any k certificates need both shared sources and k distinct PDFs, and the k
cheapest PDFs attain the lower bound. This elementary observation is not a new
theorem, adaptive advantage, or performance gain. Costs are logical unique
retained-payload bytes, not physical disk reads, network traffic, or total
research cost. Timings are machine-specific local measurements. Python parent
CPU excludes the PDF children; process-tree CPU is not measured.

Certificates establish the retained exact-ID PDF/organizer/archive report
relationship only. They do not authenticate historical execution, establish
independent experimental lineages, or provide human gold.

## Output comparison and integrity

`RESULT_V01.json` preserves the certificates, frontier checkpoints, acquisition
ledger, raw/text/stderr hashes and scoped conclusions. Five newly extracted
`paper_*_pdf.txt` files are the exact child stdout; five stderr files are retained
even when empty. `process.stdout.txt`, `process.stderr.txt`, `EXECUTION_V01.json`
and `POSTPROCESS_QA_V01.json` retain execution and postprocess evidence.

The expected projection is derived from the actual iteration303 result. It omits
only clocks/CPU timings, the protocol edition hash, and runtime-path/timing-scope
metadata. It compares all remaining result fields, including every certificate,
non-timing event/checkpoint, source SHA and PDF subprocess input/output SHA.
The new protocol has its own fixed hash; its provenance records the original
protocol and source-code hashes. No old execution time is copied into a new run.
Failures remain in the new output directory. Do not retry into the same directory
or silently substitute cached PDF text.

`MANIFEST.json` lists and hashes the other 13 files; it does not hash or sign
itself. The outer ZIP/build receipt supplies its digest. Package preparation and
ZIP validation read source bytes outside the replay and are separate preparation
work, not free evidence available to the measured decision procedure.
