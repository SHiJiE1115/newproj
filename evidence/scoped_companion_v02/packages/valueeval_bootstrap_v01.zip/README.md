# ValueEval exact-source bootstrap

This public bootstrap reconstructs the previously verified fourteen-file offline
package. It is a new distribution edition, **not** the byte-identical original
full ZIP. The original complete ZIP stays separate. Twelve original members are
copied unchanged under `skeleton/`, including its unchanged original manifest,
five PDFs, parser, protocol, replay and entry script. The organizer HTML and
archive-evaluation JSON are deliberately absent. See [source attribution and
distribution scope](SOURCE_NOTICE.md); no blanket licence is asserted.

## Assemble first, replay separately

Python 3.10+ with the standard library is sufficient for assembly. To import exact
previously obtained source files, put `organizer_main.raw` and
`archive_evaluations.raw` in one directory and run:

```text
python -I -X utf8 -B hydrate.py --source-directory "retained raw files" --output "../complete valueeval package"
```

Alternatively omit `--source-directory` to request each official URL once:

```text
python -I -X utf8 -B hydrate.py --output "../complete valueeval package"
```

The output and its metadata receipt must be new and outside the bootstrap;
their parent directories must exist. The default receipt is the output name
with `.hydrate.json` appended, next to the assembled directory. Use `--receipt`
to select another new file outside it. At least 16 MiB free output-volume space
is required. Assembly uses a new sibling temporary directory and preserves
failed partial bytes and the receipt. There is no retry or replacement with
semantically similar or more recent content. Concurrent assembly to the same
output name is unsupported.

The two required exact inputs are:

| Member in complete package | Bytes | SHA-256 |
|---|---:|---|
| `sources/organizer_main.raw` | 83506 | `f048152d2579be4d8fefa4c807221831233455de935d4ecb1b57f4a96e651fc8` |
| `sources/archive_evaluations.raw` | 410492 | `57c14d4055b28c52f0e644a5ff8a965a06c624d1a8987b79fe6b2be5074616ea` |

Download mode uses the fixed official URLs in `hydrate.py`, HTTPS, no proxy or
cookie configuration, and bounded response-body reads. Online bytes may change;
the accompanying source notice records the limited current-fetch observation.
A changed size/hash fails. This is not a promise that any future reader can
retrieve the historical bytes online. Exact local import remains supported.

The recorded current fetch recovered the exact archive JSON, but the organizer
HTML had the same 83506-byte length and a different SHA-256. Therefore the
automatic two-URL path currently fails to restore this frozen package. A reader
without the exact previously retained organizer bytes cannot presently complete
the reconstruction through these URLs. The local-import assembly check does
not close that public source-availability gap. No changed-page substitution,
normalization or update of the frozen hash is allowed.

On PASS, all fourteen assembled members are checked against the unchanged
original manifest, whose SHA-256 is
`6dcc1b6062bffde1456a528f6b73cac51f3a2addde30d061ce2e0171db393b8f`.
The metadata receipt is outside that exact package. No source parser, acquisition
policy, expected scientific output or scientific verification is run by assembly.
Initialization downloading, importing and integrity reads are preparation outside
the original logical seven-object acquisition budget; they are not free inputs
credited to a scientific decision procedure.

Read the assembled package's unchanged README before invoking its original
`run.py`. Scientific replay additionally requires the externally installed
MiKTeX Windows `pdftotext.exe` of SHA-256
`640b9a93fa31fc093860c635cd410a3e30f7d1e6166cb1130993fb1985f474ff`
(343552 bytes), with its installation and DLL dependencies. Those are not
bundled. Other platforms/extractors are not validated. The earlier accepted
Windows replay used the original full ZIP; a local assembly check of this new
bootstrap is distinct and does not add a second scientific replay.

The five examples remain post hoc positives from twenty-nine development papers.
The same-information fixed baseline already attains the declared file-dependency
budget optimum. This bootstrap adds no scientific sample, accuracy estimate,
adaptive benefit, historical authentication, author approval or human gold.
`MANIFEST.json` inventories this bootstrap and is not a signature. Its paths
under `skeleton/` are incomplete until successful assembly; do not run the
skeleton's `run.py` directly or edit its original manifest.
