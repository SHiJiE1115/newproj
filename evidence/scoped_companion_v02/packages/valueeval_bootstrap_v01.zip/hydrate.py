"""Assemble the exact 14-file ValueEval package; do not execute its scientific replay."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import sys
import tempfile
import urllib.parse
import urllib.request

HERE = Path(__file__).resolve().parent
ORIGINAL_MANIFEST_SHA256 = '6dcc1b6062bffde1456a528f6b73cac51f3a2addde30d061ce2e0171db393b8f'
MISSING = {
    'sources/organizer_main.raw': {
        'url': 'https://touche.webis.de/semeval23/touche23-web/',
        'bytes': 83506, 'sha256': 'f048152d2579be4d8fefa4c807221831233455de935d4ecb1b57f4a96e651fc8'},
    'sources/archive_evaluations.raw': {
        'url': 'https://archive.tira.io/api/evaluations/valueeval-at-semeval-2023-human-value-detection/arguments-test-20221205-test',
        'bytes': 410492, 'sha256': '57c14d4055b28c52f0e644a5ff8a965a06c624d1a8987b79fe6b2be5074616ea'}}

def need(ok, message):
    if not ok:
        raise ValueError(message)

def sha(b):
    return hashlib.sha256(b).hexdigest()

def path_under(root, name):
    rel = PurePosixPath(name)
    need(name and str(rel) == name and not rel.is_absolute() and '..' not in rel.parts
         and '\\' not in name and ':' not in name, 'UNSAFE_RELATIVE_PATH')
    p = (root/name).resolve()
    need(p.is_relative_to(root.resolve()), 'OUTSIDE_ROOT')
    return p

def save(path, b):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as f:
        f.write(b)

class HTTPSRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, url):
        parsed = urllib.parse.urlsplit(url)
        need(parsed.scheme == 'https' and parsed.username is None and parsed.password is None,
             'NON_HTTPS_OR_CREDENTIAL_REDIRECT')
        return super().redirect_request(request, fp, code, message, headers, url)

def checked(data, pin, label):
    need(len(data) == pin['bytes'] and sha(data) == pin['sha256'], 'EXACT_SOURCE_PIN_MISMATCH:' + label)

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output', required=True, type=Path, help='New complete package directory outside this bootstrap')
    ap.add_argument('--source-directory', type=Path, help='Import the two exact .raw files from this directory; no network')
    ap.add_argument('--receipt', type=Path, help='New metadata receipt outside the assembled package; defaults to OUTPUT.hydrate.json')
    args = ap.parse_args()
    output = args.output.resolve()
    receipt = args.receipt.resolve() if args.receipt else output.with_name(output.name+'.hydrate.json')
    need(output.parent.is_dir() and not output.exists(), 'OUTPUT_MUST_BE_NEW_WITH_EXISTING_PARENT')
    need(not output.is_relative_to(HERE) and not receipt.is_relative_to(HERE), 'OUTPUTS_MUST_BE_OUTSIDE_BOOTSTRAP')
    need(not receipt.is_relative_to(output) and receipt != output and not receipt.exists() and receipt.parent.is_dir(),
         'RECEIPT_MUST_BE_NEW_OUTSIDE_ASSEMBLED_PACKAGE')
    need(shutil.disk_usage(output.parent).free >= 16*1024*1024, 'NEED_16_MIB_OUTPUT_VOLUME_FREE')
    report = {'schema': 1, 'status': 'FAIL', 'started_utc': datetime.now(timezone.utc).isoformat(),
        'mode': 'exact_local_import' if args.source_directory else 'official_url_download',
        'scientific_replay_executed': False, 'new_scientific_sample': False,
        'bootstrap_acquisition_is_outside_scientific_budget': True, 'attempts_per_source_maximum': 1,
        'output': str(output), 'sources': [], 'human_review': False}
    partial = None
    try:
        outer = json.loads((HERE/'MANIFEST.json').read_bytes())
        actual = {p.relative_to(HERE).as_posix() for p in HERE.rglob('*') if p.is_file()}
        names = [x['path'] for x in outer['files']]
        need(len(names) == len(set(names)) and actual == set(names)|{'MANIFEST.json'}, 'BOOTSTRAP_INVENTORY')
        for item in outer['files']:
            checked(path_under(HERE,item['path']).read_bytes(),item,item['path'])
        skeleton = HERE/'skeleton'
        manifest_bytes = (skeleton/'MANIFEST.json').read_bytes()
        need(sha(manifest_bytes) == ORIGINAL_MANIFEST_SHA256, 'ORIGINAL_MANIFEST_CHANGED')
        original = json.loads(manifest_bytes)
        originals = {x['path']: x for x in original['files']}
        need(len(originals) == len(original['files']) == 13 and set(MISSING).issubset(originals), 'ORIGINAL_MANIFEST_CONTENT')
        for name, spec in MISSING.items():
            need(originals[name]['bytes'] == spec['bytes'] and originals[name]['sha256'] == spec['sha256'], 'CONTRACT_PIN')
        expected_skeleton = (set(originals)|{'MANIFEST.json'})-set(MISSING)
        skeleton_actual = {p.relative_to(skeleton).as_posix() for p in skeleton.rglob('*') if p.is_file()}
        need(skeleton_actual == expected_skeleton and len(expected_skeleton) == 12, 'SKELETON_INVENTORY')
        partial = Path(tempfile.mkdtemp(prefix='.'+output.name+'.partial-',dir=output.parent))
        report['preserved_partial_directory'] = str(partial)
        for name in sorted(expected_skeleton):
            b = path_under(skeleton,name).read_bytes()
            if name != 'MANIFEST.json':
                checked(b, originals[name], name)
            save(path_under(partial,name), b)
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), HTTPSRedirects())
        for name, spec in MISSING.items():
            observation = {'member': name, 'expected_bytes': spec['bytes'], 'expected_sha256': spec['sha256'],
                           'attempts': 1, 'mode': report['mode']}
            report['sources'].append(observation)
            if args.source_directory:
                source = args.source_directory.resolve()/Path(name).name
                observation['source_filename'] = source.name
                with source.open('rb') as f:
                    b = f.read(spec['bytes']+1)
            else:
                observation['requested_url'] = spec['url']
                request = urllib.request.Request(spec['url'], headers={'User-Agent':'ScopedEvidence-ExactBootstrap/1.0', 'Accept-Encoding':'identity'})
                with opener.open(request, timeout=30) as response:
                    observation['http_status'] = response.status
                    observation['final_url'] = response.geturl()
                    need(response.status == 200, 'HTTP_STATUS')
                    need(response.headers.get('Content-Encoding','identity').lower() in ['', 'identity'], 'ENCODED_HTTP_BODY_UNSUPPORTED')
                    b = response.read(spec['bytes']+1)
            observation.update(observed_bytes_at_most_limit_plus_one=len(b), observed_sha256=sha(b))
            # Preserve mismatching bytes in the partial directory; no substitution or automatic retry.
            save(path_under(partial,name), b)
            checked(b,spec,name)
            observation['exact_pin_match'] = True
        assembled = {p.relative_to(partial).as_posix() for p in partial.rglob('*') if p.is_file()}
        need(assembled == set(originals)|{'MANIFEST.json'} and len(assembled) == 14, 'ASSEMBLED_INVENTORY')
        checked_files = []
        for name in sorted(assembled):
            b = path_under(partial,name).read_bytes()
            if name == 'MANIFEST.json':
                need(b == manifest_bytes, 'MANIFEST_BYTES_CHANGED')
            else:
                checked(b,originals[name],name)
            checked_files.append({'path':name,'bytes':len(b),'sha256':sha(b)})
        need(not output.exists(), 'OUTPUT_APPEARED_DURING_ASSEMBLY')
        partial.rename(output)
        report.pop('preserved_partial_directory')
        report.update(status='PASS_EXACT_FOURTEEN_FILE_ASSEMBLY', files=checked_files,
            original_manifest_sha256=sha(manifest_bytes), scientific_contract_unchanged=True,
            instruction='Run the unchanged run.py separately with its required external pdftotext; assembly does not execute the replay.')
    except Exception as e:
        report.update(error_type=type(e).__name__,error=str(e))
    report['ended_utc'] = datetime.now(timezone.utc).isoformat()
    save(receipt,(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode())
    print(json.dumps({'status':report['status'],'receipt':str(receipt),'error':report.get('error')}))
    return 0 if report['status'].startswith('PASS_') else 1

if __name__ == '__main__':
    raise SystemExit(main())
