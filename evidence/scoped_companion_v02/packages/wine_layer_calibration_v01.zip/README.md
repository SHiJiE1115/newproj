# Portable retained Wine evidence calibration

This offline Python 3.10+ package replays the finite iteration302 calibration.
It contains three actual retained run archives, two constructed splice scenarios,
and one duplicate-reference scenario. v07 has no retained CSV or author summary;
the three archives jointly supply the needed evidence, not three complete outputs.

## Run once in a relocated directory

Extract the ZIP to a new directory, including one containing spaces if desired.
With standard-library Python (including sqlite3), use:

```text
python -I -X utf8 -B run.py --output "../new wine replay output"
```

The output must not exist, must be outside the bundle, and its parent must exist.
No installation, network, training, downloaded-source execution, shell command,
or cryptographic verification is performed. Each of the candidate and independent
SQL baseline runs once in its own process, sequentially, with a 120-second parent
timeout. The baseline retains its original cooperative 60-second cap. Temporary
files and process logs go under the output directory. A timeout or nonzero exit is
preserved as a failure, without retries. Neither implementation reads the other
implementation's output or the old result references.

`run.py` requires at least 64 MiB free on the output volume and records a fresh
`RESOURCE_CHECK.json`. This administrative check replaces the baseline's old
machine-specific guard; it is not a replayed PASS and is not a scientific premise.
The project operator still applies its external storage policy for local runs.
Manifest and source-pin checks are bootstrap, not measured scientific acquisition
costs. The package makes no timing or memory superiority claim.

## What is checked

The 17 fixed inputs retain their original bytes and SHA-256: three tar archives,
nine retained gate/report files, three retained signature-related files, and two
rules-v2.1 semantic modules. Tar members are read in memory, never extracted or
executed. Archived absolute paths and public account/run identities may remain
inside exact historical inputs and complete old result references. They are
inert historical text; the adapters resolve only the explicit relative protocol
descriptors. This is a portable evidence package, not an anonymized export.

Both implementations use the same protocol and pinned evidence. They independently
recompute the retained CSV arithmetic and validate the retained summary, parameter,
nonce, digest and identity joins. The selected-read layer means the retained,
version-specific candidate and direct reports passed. A failed or absent flag is
not proof of no physical read. Only v09 has the matching successful retained
signature-verification evidence. Those saved bytes and embedded identities are
checked; no fresh cryptographic verification or trust-root refresh is claimed.

The five layers are artifact arithmetic, selected-read gate, retained signed
identity, the same-identity joint receipt, and original historical execution.
All historical-execution labels remain UNRESOLVED. A v08 numerical component
spliced with v09 gate/signature is not a joint v08 receipt. The v08 CSV spliced
into the v09 summary fails its digest binding. Repeating the v09 reference twice
still counts as one accepted run identity. Twenty-five draws are not twenty-five
independent runs. Expected output is six scenarios / thirty labels, and exact
agreement with the independent SQL baseline; equality is not method superiority.

The candidate uses the unchanged rules-v2.1 support semantics with open scope
and its unchanged independent certificate checker. These check the explicit
admitted fact model, not the truth of the extractor or all possible histories.
The relative protocol has a new digest, which is actually supplied to the
semantic Scope snapshot. Consequently its certificates are not byte-identical
to the old certificates. After both children terminate, the launcher independently
checks the hash formula for each old certificate and its new binding: exactly
snapshot_digest, scope_digest, input_digest and certificate_digest change. The
entire candidate result must then match the explicitly rebound old result; it
does not drop arbitrary digests. Internal run protocol hashes stay unchanged.
All baseline scientific fields and diagnostics must match its original V02
result; only relocated paths, protocol/script descriptors, fresh resource-check
metadata and clocks are treated as administrative changes.

## Version and limits

`protocol.json` preserves the original scientific contract and its 17 source
pins. It replaces input paths and removes the original guard/preparer/P1
administrative metadata, recording the original protocol digest and this version
change. The candidate and final SQL baseline V02 only adapt entry points, paths,
protocol pins and the administrative resource check. Scientific helper functions
are unchanged. `MANIFEST.json` lists the other 24 files; it is an integrity
inventory, not a signature or self-authenticating trust anchor.

This is a relocation of an already observed engineering regression, not a new
scientific sample, natural-error-rate evaluation, human gold, independent
replication, adaptive-cost advantage, historical execution certificate, or
complete consumed-byte proof. It does not establish a whole-project license or
ownership grant. Original notices and provenance in the retained inputs remain.
