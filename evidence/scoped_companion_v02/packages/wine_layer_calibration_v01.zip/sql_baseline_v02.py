"""Independent fixed extraction + SQLite/hash-join calibration; no new execution or crypto verification."""
import sys
sys.dont_write_bytecode = True
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
from decimal import Decimal, localcontext, ROUND_HALF_UP
import ast
import argparse
import base64
import csv
import hashlib
import io
import json
import sqlite3
import tarfile
import time

HERE = None
PROTOCOL = None
RESOURCE_CHECK = None
PROTOCOL_SHA = '3d5f542359cc385cd6edacc3612994fecb034dcedae4e3322602c1aea934641f'
KEYS = ['repository', 'source_commit', 'run_id', 'attempt', 'protocol_sha256', 'tar_sha256']
PASS_OLD = 'PASS_PROSPECTIVE_STRACE_OBSERVATION_ONLY'
CSV_MEMBER = 'results/ours.csv'
PARAMS_MEMBER = 'results/ours_exp_params.py'
HEADER = ['draw', 'seed', 'train_accuracy', 'test_accuracy', 'n_leaves', 'height', 'bound', 'time']

def need(ok, message):
    if not ok:
        raise ValueError(message)

def digest(b):
    return hashlib.sha256(b).hexdigest()

def parse(b):
    def pairs(items):
        result = {}
        for k, v in items:
            need(k not in result, 'Duplicate JSON key: ' + k)
            result[k] = v
        return result
    return json.loads(b, object_pairs_hook=pairs)

def descriptor(p):
    b = p.read_bytes()
    return {'path': p.as_posix(), 'bytes': len(b), 'sha256': digest(b)}

def key_for(run):
    e = run['identity']
    return {'repository': e['GITHUB_REPOSITORY'], 'source_commit': e['GITHUB_SHA'],
            'run_id': str(e['GITHUB_RUN_ID']), 'attempt': str(e['GITHUB_RUN_ATTEMPT']),
            'protocol_sha256': run['protocol_sha256'], 'tar_sha256': run['files']['receipt.tar']['sha256']}

def difference(actual, expected):
    return [{'field': k, 'actual': actual[k], 'expected': expected[k]} for k in KEYS if actual[k] != expected[k]]

def source_locator(run, name, member=None, pointer=None):
    d = {'run': run, 'file': name}
    if member is not None:
        d['member'] = member
    if pointer is not None:
        d['json_pointer_or_field'] = pointer
    return d

def inspect_run(run_id, run, blobs, con):
    data = blobs[run['files']['receipt.tar']['path']]
    members = {}
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:') as archive:
        for member in archive.getmembers():
            p = PurePosixPath(member.name)
            need(member.isfile() and not p.is_absolute() and '..' not in p.parts, 'Unsupported tar member.')
            need(member.name not in members, 'Duplicate tar member.')
            members[member.name] = archive.extractfile(member).read()
    host = parse(members['host_run.json'])
    native_protocol = parse(members['source/experiment/PROTOCOL.json'])
    need(digest(members['source/experiment/PROTOCOL.json']) == run['protocol_sha256'], 'Native protocol digest differs.')
    need(native_protocol['schema'] == run['protocol_schema'], 'Native protocol schema differs.')
    for member, expected in run['source_python_member_sha256'].items():
        need(digest(members[member]) == expected, 'Frozen source-byte digest differs.')
        need(host['source_hashes'][member.removeprefix('source/')] == expected, 'Host source binding differs.')
    need(host['source_hashes']['experiment/PROTOCOL.json'] == run['protocol_sha256'], 'Host protocol digest differs.')
    need(host['run_nonce'] == run['run_nonce'], 'Host nonce differs.')
    e = run['identity']
    derived_nonce = digest((e['GITHUB_SHA'] + ':' + e['GITHUB_RUN_ID'] + ':' + e['GITHUB_RUN_ATTEMPT']).encode())[:32]
    need(host['run_nonce'] == run['run_nonce'] == derived_nonce, 'Commit:run:attempt nonce derivation differs.')
    for k, value in run['identity'].items():
        need(host['github_environment'][k] == value, 'Host identity differs: ' + k)
    for native_key, member in [('author', 'inputs/author.zip'), ('data', 'inputs/wine.raw')]:
        pin = native_protocol[native_key]
        need(len(members[member]) == pin['bytes'] and digest(members[member]) == pin['sha256'], 'Retained input pin differs.')
        need(host['inputs'][native_key]['sha256'] == pin['sha256'], 'Host retained input binding differs.')
    candidate = parse(blobs[run['files']['CANDIDATE_REPORT.json']['path']])
    direct = parse(blobs[run['files']['DIRECT_BASELINE_REPORT.json']['path']])
    gate = parse(blobs[run['files']['POSTRUN_RELEASE_GATE.json']['path']])
    joint_key = key_for(run)
    need(candidate['tar_sha256'] == direct['observations']['tar_sha256'] == gate['receipt_tar_sha256'] == joint_key['tar_sha256'], 'Retained report tar bindings differ.')
    need(candidate['expected_github_identity_from_caller'] == run['identity'], 'Retained caller identity differs.')
    external = gate['expected_external_identity']
    need((external['repository'], external['head_sha'], str(external['run_id']), str(external['attempt'])) == tuple(joint_key[k] for k in KEYS[:4]), 'External release identity differs.')
    summary_member = 'out/author_result_' + run['run_nonce'] + '.json'
    summary = parse(members[summary_member]) if summary_member in members else None
    for member, b in members.items():
        con.execute('INSERT INTO tar_members VALUES (?,?,?,?)', (run_id, member, len(b), digest(b)))
    con.execute('INSERT INTO run_identity VALUES (?,?,?,?,?,?,?)', (run_id, *(joint_key[k] for k in KEYS)))
    return {'key': joint_key, 'members': members, 'host': host, 'protocol': native_protocol,
            'summary': summary, 'summary_member': summary_member, 'candidate': candidate, 'direct': direct, 'gate': gate}

def numeric(scenario, loaded, con):
    donor = loaded[scenario['numeric']]
    recipient = loaded[scenario['target']] if scenario.get('csv_only_into_target_summary') else donor
    donor_id = scenario['numeric']
    recipient_id = scenario['target'] if scenario.get('csv_only_into_target_summary') else donor_id
    evidence = [source_locator(donor_id, 'receipt.tar', CSV_MEMBER),
                source_locator(recipient_id, 'receipt.tar', recipient['summary_member']),
                source_locator(recipient_id, 'receipt.tar', PARAMS_MEMBER),
                source_locator(recipient_id, 'receipt.tar', 'host_run.json', '/run_nonce'),
                source_locator(recipient_id, 'receipt.tar', 'source/experiment/PROTOCOL.json', '/target')]
    absent = []
    if CSV_MEMBER not in donor['members']:
        absent.append('csv')
    if recipient['summary'] is None:
        absent.append('summary')
    if PARAMS_MEMBER not in recipient['members']:
        absent.append('params')
    if absent:
        return {'positive': False, 'detail_status': 'UNAVAILABLE', 'missing': absent, 'evidence': evidence,
                'key': recipient['key'], 'csv_donor_key': donor['key']}
    csv_bytes = donor['members'][CSV_MEMBER]
    params_bytes = recipient['members'][PARAMS_MEMBER]
    summary = recipient['summary']
    reader = csv.DictReader(io.StringIO(csv_bytes.decode('utf-8'), newline=''))
    need(reader.fieldnames == HEADER, 'Unexpected retained CSV header.')
    rows = list(reader)
    target = recipient['protocol']['target']
    need(target['draws'] == 25 and target['seeds'] == '1,11,...,241', 'Frozen target changed.')
    need(all(set(r) == set(HEADER) and all(v is not None for v in r.values()) for r in rows), 'Malformed CSV row.')
    tree = ast.parse(params_bytes.decode('utf-8'), mode='exec')
    need(len(tree.body) == 1 and isinstance(tree.body[0], ast.Assign) and len(tree.body[0].targets) == 1
         and isinstance(tree.body[0].targets[0], ast.Name) and tree.body[0].targets[0].id == 'exp_params', 'Unexpected params literal schema.')
    params = ast.literal_eval(tree.body[0].value)  # no author code execution
    checks = []
    def check(edge, ok, observed, expected):
        checks.append({'edge': edge, 'pass': bool(ok), 'observed': observed, 'expected': expected})
    check('csv_donor_joint_key_to_summary_recipient', donor['key'] == recipient['key'], donor['key'], recipient['key'])
    check('csv_sha256_to_summary', digest(csv_bytes) == summary['csv_sha256'], digest(csv_bytes), summary['csv_sha256'])
    check('params_sha256_to_summary', digest(params_bytes) == summary['params_sha256'], digest(params_bytes), summary['params_sha256'])
    check('summary_nonce_to_host', summary['run_nonce'] == recipient['host']['run_nonce'], summary['run_nonce'], recipient['host']['run_nonce'])
    check('summary_status', summary['status'] == 'success', summary['status'], 'success')
    check('csv_rows_to_target', len(rows) == target['draws'] == summary['csv_rows'], len(rows), target['draws'])
    check('csv_first_row_to_summary', rows[0] == summary['first_row'], rows[0], summary['first_row'])
    check('csv_last_row_to_summary', rows[-1] == summary['last_row'], rows[-1], summary['last_row'])
    need(rows, 'Empty CSV cannot support arithmetic.')
    with localcontext() as ctx:
        ctx.prec = 80
        values = []
        for i, row in enumerate(rows):
            draw, seed = int(row['draw']), int(row['seed'])
            check('draw_seed_row_' + str(i), (draw, seed) == (i, 1 + 10*i), [draw, seed], [i, 1 + 10*i])
            vals = {k: Decimal(row[k]) for k in HEADER if k not in ['draw', 'seed']}
            need(all(v.is_finite() for v in vals.values()), 'Nonfinite CSV number.')
            need(0 <= vals['test_accuracy'] <= 1 and 0 <= vals['train_accuracy'] <= 1, 'Accuracy outside [0,1].')
            values.append(vals['test_accuracy'])
            con.execute('INSERT INTO csv_rows VALUES (?,?,?,?,?)', (scenario['id'], draw, seed, row['test_accuracy'], digest(json.dumps(row, sort_keys=True).encode())))
        mean = sum(values)/len(values)
        variance = sum((x - mean)**2 for x in values)/len(values)
        sd = variance.sqrt()
        rounded = [str(v.quantize(Decimal('.001'), rounding=ROUND_HALF_UP)) for v in (mean, sd)]
        check('mean_population_sd_to_target', rounded == target['reported_mean_sd_3dp'], rounded, target['reported_mean_sd_3dp'])
        arithmetic = {'mean_from_csv_lexemes_decimal80': str(mean), 'population_sd_decimal80': str(sd),
                      'rounded_mean_sd_3dp': rounded, 'rounding': 'decimal ROUND_HALF_UP', 'rows': len(values)}
    check('params_draws', params['n_draws'] == target['draws'], params['n_draws'], target['draws'])
    check('params_prior_exponent', Decimal(str(params['error_prior_exponent'])) == Decimal(str(target['prior_exponent'])), str(params['error_prior_exponent']), str(target['prior_exponent']))
    need(params == {'exp_name': 'ac25', 'test_split_ratio': .25, 'n_draws': 25, 'n_folds': 10, 'max_n_leaves': 40, 'error_prior_exponent': 13.7}, 'Frozen retained parameter dictionary differs.')
    con.execute('INSERT INTO output_edges VALUES (?,?,?,?)', (scenario['id'], donor_id, digest(csv_bytes), summary['csv_sha256']))
    edge_join = con.execute('SELECT COUNT(*) FROM output_edges e JOIN tar_members m ON e.donor=m.run AND m.member=? AND e.actual_sha=m.sha AND e.summary_sha=m.sha WHERE e.scenario=?', (CSV_MEMBER, scenario['id'])).fetchone()[0]
    ok = all(c['pass'] for c in checks) and edge_join == 1
    return {'positive': ok, 'detail_status': 'PASSED' if ok else 'BINDING_MISMATCH', 'evidence': evidence,
            'key': recipient['key'], 'csv_donor_key': donor['key'], 'checks': checks, 'arithmetic': arithmetic,
            'csv_summary_hash_join_rows': edge_join, 'params_literal': params,
            'csv_member': {'bytes': len(csv_bytes), 'sha256': digest(csv_bytes)},
            'summary_member': {'bytes': len(recipient['members'][recipient['summary_member']]), 'sha256': digest(recipient['members'][recipient['summary_member']])}}

def retained_read_gate(run_id, loaded):
    r = loaded[run_id]
    cand = r['candidate']['receipt_audit']['checks']
    direct = r['direct']['checks']
    requested = {'candidate': ['author_execve_same_pid', 'wine_open_observed', 'wine_positive_read_observed', 'execve_wine_order'],
                 'direct': ['author_execve_same_pid', 'wine_open_and_read', 'execve_wine_order']}
    flags, absent, failed = [], [], []
    for kind, keys in requested.items():
        obj = cand if kind == 'candidate' else direct
        for k in keys:
            value = obj.get(k)
            flags.append({'report': kind, 'field': k, 'value': value})
            if k not in obj:
                absent.append(kind + '.' + k)
            elif value is not True:
                failed.append(kind + '.' + k)
    statuses = [r['candidate']['status'], r['candidate']['receipt_audit']['status'], r['direct']['status']]
    positive = not absent and not failed and all(x == PASS_OLD for x in statuses)
    return {'positive': positive, 'key': r['key'],
            'detail_status': 'PASSED' if positive else ('UNAVAILABLE' if absent else 'NOT_PASSED'),
            'retained_statuses': statuses, 'flags': flags, 'missing_flags': absent, 'false_flags': failed,
            'evidence': [source_locator(run_id, 'CANDIDATE_REPORT.json', pointer='/receipt_audit/checks'),
                         source_locator(run_id, 'DIRECT_BASELINE_REPORT.json', pointer='/checks'),
                         source_locator(run_id, 'receipt.tar', 'source/experiment/PROTOCOL.json', '/trace_rule')],
            'fresh_trace_parsing': False, 'physical_nonreading_inferred_from_failed_gate': False}

def retained_signature(protocol, blobs, loaded):
    files = protocol['v09_retained_signature_files']
    acceptance = parse(blobs[files['ACCEPTANCE.json']['path']])
    verified = parse(blobs[files['verified.stdout.json']['path']])
    bundle_name = next(k for k in files if k.endswith('.jsonl'))
    bundle = parse(blobs[files[bundle_name]['path']])
    need(len(verified) == 1, 'Expected exactly one retained verified statement.')
    vr = verified[0]['verificationResult']
    statement = vr['statement']
    raw_statement = parse(base64.b64decode(bundle['dsseEnvelope']['payload'], validate=True))
    need(statement == raw_statement, 'Retained verification statement differs from raw bundle payload.')
    need(verified[0]['attestation']['bundle'] == bundle, 'Retained verified bundle differs from saved raw bundle.')
    key = loaded['v09']['key']
    gate = loaded['v09']['gate']
    workflow = statement['predicate']['buildDefinition']['externalParameters']['workflow']
    ref = 'refs/heads/' + gate['expected_external_identity']['head_branch']
    workflow_path = '.github/workflows/rrnc-wine-strace.yml'
    repo_url = 'https://github.com/' + key['repository']
    invocation = repo_url + '/actions/runs/' + key['run_id'] + '/attempts/' + key['attempt']
    expected_workflow = {'path': workflow_path, 'ref': ref, 'repository': repo_url}
    cert = vr['signature']['certificate']
    assertions = {
        'acceptance_status': acceptance['status'] == 'PASS_RETAINED_SIGNATURE_BUNDLE',
        'retained_exit_zero': type(acceptance['verify_exit']) is int and acceptance['verify_exit'] == 0,
        'acceptance_run': str(acceptance['run_id']) == key['run_id'] and str(acceptance['attempt']) == key['attempt'],
        'acceptance_commit_tar': acceptance['source_commit'] == key['source_commit'] and acceptance['receipt_tar_sha256'] == key['tar_sha256'],
        'acceptance_bundle_hash': acceptance['bundle_name'] == bundle_name and acceptance['bundle_sha256'] == files[bundle_name]['sha256'],
        'acceptance_stdout_hash': acceptance['verification_stdout_sha256'] == files['verified.stdout.json']['sha256'],
        'gate_retained_verified': gate['attestation']['verified'] is True and gate['attestation']['status'] == 'CRYPTO_VERIFIED',
        'gate_retained_exit_hash': type(gate['attestation']['gh_exit_code']) is int and gate['attestation']['gh_exit_code'] == 0 and gate['attestation']['gh_stdout_sha256'] == files['verified.stdout.json']['sha256'],
        'subject_exact': statement['subject'] == [{'name': 'receipt.tar', 'digest': {'sha256': key['tar_sha256']}}],
        'statement_types': statement['_type'] == 'https://in-toto.io/Statement/v1' and statement['predicateType'] == 'https://slsa.dev/provenance/v1',
        'workflow_repository_ref_path': workflow == expected_workflow,
        'resolved_dependency': statement['predicate']['buildDefinition']['resolvedDependencies'] == [{'uri': 'git+' + repo_url + '@' + ref, 'digest': {'gitCommit': key['source_commit']}}],
        'invocation_run_attempt': statement['predicate']['runDetails']['metadata']['invocationId'] == invocation,
        'builder_workflow': statement['predicate']['runDetails']['builder']['id'] == repo_url + '/' + workflow_path + '@' + ref,
        'certificate_repo_commit_ref': cert['githubWorkflowRepository'] == key['repository'] and cert['githubWorkflowSHA'] == key['source_commit'] and cert['githubWorkflowRef'] == ref,
        'certificate_invocation': cert['runInvocationURI'] == invocation,
        'certificate_workflow_uri': cert['subjectAlternativeName'] == repo_url + '/' + workflow_path + '@' + ref,
        'certificate_issuer': cert['issuer'] == 'https://token.actions.githubusercontent.com',
    }
    return {'positive': all(assertions.values()), 'key': key, 'detail_status': 'PASSED_RETAINED_BINDINGS_ONLY' if all(assertions.values()) else 'BINDING_MISMATCH',
            'checks': assertions, 'fresh_cryptographic_verification': False, 'trust_root_refresh': False,
            'evidence': [source_locator('v09', 'ACCEPTANCE.json'), source_locator('v09', 'verified.stdout.json', pointer='/0/verificationResult'),
                         source_locator('v09', bundle_name, pointer='/dsseEnvelope/payload'), source_locator('v09', 'POSTRUN_RELEASE_GATE.json', pointer='/attestation')]}


def resolve_inputs(p, root):
    """Resolve only the 17 explicit protocol input descriptors inside this bundle."""
    root = root.resolve()
    specs = [d for r in p['runs'].values() for d in r['files'].values()]
    specs += list(p['v09_retained_signature_files'].values())
    specs += list(p['existing_semantic_modules'].values())
    if len(specs) != 17:
        raise ValueError('EXPECTED_17_INPUTS')
    for d in specs:
        text = d['path']
        rel = PurePosixPath(text)
        if rel.is_absolute() or '..' in rel.parts or '\\' in text or ':' in text or str(rel) != text:
            raise ValueError('INVALID_RELATIVE_INPUT_PATH')
        path = (root / text).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            raise ValueError('INPUT_OUTSIDE_BUNDLE_OR_MISSING')
        d['path'] = str(path)
    return p

def run():
    begin = time.perf_counter()
    result = {'schema': 1, 'status': 'FAIL', 'human_review': False}
    try:
        resource = parse(RESOURCE_CHECK.read_bytes())
        need(resource['status'] == 'PASS' and resource['output_directory'] == HERE.as_posix(), 'Resource check target differs.')
        need(resource['minimum_free_bytes'] >= 64*1024*1024 and resource['free_bytes'] >= resource['minimum_free_bytes'], 'Resource check capacity failed.')
        age = (datetime.now(timezone.utc) - datetime.fromisoformat(resource['checked_at_utc'])).total_seconds()
        need(0 <= age < 1800 and resource['original_guard_replayed'] is False, 'Resource check stale or historical guard replayed.')
        protocol_bytes = PROTOCOL.read_bytes()
        need(digest(protocol_bytes) == PROTOCOL_SHA, 'Protocol pin differs.')
        p = parse(protocol_bytes)
        p = resolve_inputs(p, PROTOCOL.parent)
        need(p['joint_key'] == KEYS and len(p['scenarios']) == 6, 'Frozen scenario contract differs.')
        descriptors = [d for r in p['runs'].values() for d in r['files'].values()] + list(p['v09_retained_signature_files'].values()) + list(p['existing_semantic_modules'].values())
        blobs, pins = {}, []
        for d in descriptors:
            path = Path(d['path'])
            b = path.read_bytes()
            need(len(b) == d['bytes'] and digest(b) == d['sha256'], 'Input pin differs: ' + str(path))
            blobs[d['path']] = b
            pins.append({'path': path.as_posix(), 'bytes': len(b), 'sha256_before': digest(b)})
        con = sqlite3.connect(':memory:')
        con.executescript('''CREATE TABLE tar_members(run TEXT,member TEXT,bytes INTEGER,sha TEXT,PRIMARY KEY(run,member));
          CREATE TABLE run_identity(run TEXT PRIMARY KEY,repository TEXT,source_commit TEXT,run_id TEXT,attempt TEXT,protocol_sha256 TEXT,tar_sha256 TEXT);
          CREATE TABLE csv_rows(scenario TEXT,draw INTEGER,seed INTEGER,test_accuracy TEXT,row_sha TEXT,PRIMARY KEY(scenario,draw));
          CREATE TABLE output_edges(scenario TEXT,donor TEXT,actual_sha TEXT,summary_sha TEXT);
          CREATE TABLE admissions(scenario TEXT,layer TEXT,ok INTEGER,repository TEXT,source_commit TEXT,run_id TEXT,attempt TEXT,protocol_sha256 TEXT,tar_sha256 TEXT,PRIMARY KEY(scenario,layer));
          CREATE TABLE references_to_identity(scenario TEXT,copy_index INTEGER,repository TEXT,source_commit TEXT,run_id TEXT,attempt TEXT,protocol_sha256 TEXT,tar_sha256 TEXT);''')
        loaded = {name: inspect_run(name, run, blobs, con) for name, run in p['runs'].items()}
        sig_v09 = retained_signature(p, blobs, loaded)
        scenarios = []
        joint_sql = '''SELECT COUNT(*) FROM admissions n JOIN admissions r ON n.scenario=r.scenario
          AND n.repository=r.repository AND n.source_commit=r.source_commit AND n.run_id=r.run_id
          AND n.attempt=r.attempt AND n.protocol_sha256=r.protocol_sha256 AND n.tar_sha256=r.tar_sha256
          JOIN admissions s ON n.scenario=s.scenario AND n.repository=s.repository AND n.source_commit=s.source_commit
          AND n.run_id=s.run_id AND n.attempt=s.attempt AND n.protocol_sha256=s.protocol_sha256 AND n.tar_sha256=s.tar_sha256
          WHERE n.scenario=? AND n.layer='artifact_numeric' AND r.layer='selected_read_gate' AND s.layer='retained_signed_identity'
          AND n.ok=1 AND r.ok=1 AND s.ok=1'''
        for scenario in p['scenarios']:
            sid = scenario['id']
            target = loaded[scenario['target']]['key']
            nu = numeric(scenario, loaded, con)
            rd = retained_read_gate(scenario['read'], loaded)
            sg = sig_v09 if scenario['signature'] == 'v09' else {
                'positive': False, 'key': loaded[scenario['signature']]['key'], 'detail_status': 'UNAVAILABLE',
                'evidence': [source_locator(scenario['signature'], 'POSTRUN_RELEASE_GATE.json', pointer='/attestation')],
                'retained_attestation': loaded[scenario['signature']]['gate']['attestation'], 'fresh_cryptographic_verification': False}
            components = {'artifact_numeric': nu, 'selected_read_gate': rd, 'retained_signed_identity': sg}
            layers, diagnostics = {}, {}
            for layer, component in components.items():
                mismatches = difference(component['key'], target)
                ok = component['positive'] and not mismatches
                layers[layer] = 'MET' if ok else 'UNRESOLVED'
                diagnostics[layer] = {**component, 'target_key_mismatches': mismatches,
                                      'component_positive_before_target_join': component['positive']}
                con.execute('INSERT INTO admissions VALUES (?,?,?,?,?,?,?,?,?)', (sid, layer, int(ok), *(component['key'][k] for k in KEYS)))
            joint = con.execute(joint_sql, (sid,)).fetchone()[0]
            need(joint in [0, 1], 'Unexpected joint multiplicity.')
            layers['joint_scoped_receipt'] = 'MET' if joint else 'UNRESOLVED'
            layers['historical_2020_execution'] = 'UNRESOLVED'
            if joint:
                for copy in range(scenario['copies']):
                    con.execute('INSERT INTO references_to_identity VALUES (?,?,?,?,?,?,?,?)', (sid, copy, *(target[k] for k in KEYS)))
            distinct = con.execute('SELECT COUNT(*) FROM (SELECT DISTINCT repository,source_commit,run_id,attempt,protocol_sha256,tar_sha256 FROM references_to_identity WHERE scenario=?)', (sid,)).fetchone()[0]
            diagnostics['joint_scoped_receipt'] = {'six_field_sql_join_rows': joint, 'target_key': target,
                'component_pair_mismatches': {'numeric_to_read': difference(nu['key'], rd['key']), 'numeric_to_signature': difference(nu['key'], sg['key']), 'read_to_signature': difference(rd['key'], sg['key'])},
                'csv_donor_to_target_mismatches': difference(nu['csv_donor_key'], target),
                'evidence': {'numeric': nu['evidence'], 'read': rd['evidence'], 'signature': sg['evidence']}}
            diagnostics['historical_2020_execution'] = {'reason': 'No admitted object in this frozen packet attests the original historical execution; matching arithmetic and current prospective identity cannot supply it.', 'admitted_historical_evidence': []}
            scenarios.append({'id': sid, 'kind': scenario['kind'], 'layers': layers, 'joint_distinct_identity_count': distinct,
                              'input_reference_copies': scenario['copies'], 'diagnostics': diagnostics})
        expected_check = []
        for row in scenarios:
            expected = {layer: ('MET' if layer in p['expected_positive_layers'][row['id']] else 'UNRESOLVED') for layer in p['claim_layers']}
            expected_check.append({'id': row['id'], 'labels_agree_with_frozen_calibration': row['layers'] == expected})
        need(all(x['labels_agree_with_frozen_calibration'] for x in expected_check), 'Computed layers disagree with frozen calibration; preserve result as failure.')
        mixed = next(x for x in scenarios if x['id'] == 'mixed_output')['diagnostics']['artifact_numeric']
        need(mixed['csv_summary_hash_join_rows'] == 0 and any(c['edge'] == 'csv_sha256_to_summary' and not c['pass'] for c in mixed['checks']), 'Mixed output digest edge was not tested.')
        duplicate = next(x for x in scenarios if x['id'] == 'duplicate_v09')
        need(duplicate['input_reference_copies'] == 2 and duplicate['joint_distinct_identity_count'] == 1, 'Whole-identity DISTINCT failed.')
        for d in pins:
            b = Path(d['path']).read_bytes()
            d['sha256_after'] = digest(b)
            d['unchanged'] = len(b) == d['bytes'] and d['sha256_after'] == d['sha256_before']
            need(d['unchanged'], 'Original input mutated.')
        need(PROTOCOL.read_bytes() == protocol_bytes, 'Protocol mutated.')
        need(time.perf_counter() - begin < 60, 'Cooperative 60-second computation cap.')
        result.update({'status': 'PASS_INDEPENDENT_SQL_HASH_JOIN_BASELINE', 'protocol': descriptor(PROTOCOL),
            'resource_check': descriptor(RESOURCE_CHECK), 'script': descriptor(Path(__file__)), 'scenarios': scenarios,
            'layer_label_count': sum(len(x['layers']) for x in scenarios), 'expected_calibration_checks': expected_check,
            'original_input_bindings': pins, 'all_original_bytes_unchanged': all(x['unchanged'] for x in pins),
            'tar_member_inventory': [dict(zip(['run', 'member', 'bytes', 'sha256'], row)) for row in con.execute('SELECT * FROM tar_members ORDER BY run,member')],
            'sql': {'joint_query': joint_sql, 'tables': ['tar_members', 'run_identity', 'csv_rows', 'output_edges', 'admissions', 'references_to_identity'],
                    'input_reference_copies_among_accepted_scenarios': con.execute('SELECT COUNT(*) FROM references_to_identity').fetchone()[0],
                    'global_distinct_joint_identities': con.execute('SELECT COUNT(*) FROM (SELECT DISTINCT repository,source_commit,run_id,attempt,protocol_sha256,tar_sha256 FROM references_to_identity)').fetchone()[0]},
            'information_contract': 'Direct fixed extraction from all the same protocol-pinned original bytes; retained 276 reports are evidence inputs. No iteration302 candidate code/results imported or read.',
            'computed_now': ['CSV decimal arithmetic and draw/seed sequence', 'summary/params/nonce and CSV hash edges', 'retained gate fields and identity joins', 'retained verification-output and raw-statement binding', 'whole-joint-identity DISTINCT'],
            'not_computed_now': ['new author execution', 'trace rerun or complete consumed-byte certification', 'new cryptographic signature verification or refreshed trust root', 'historical 2020 execution', 'new human gold or independent scientific sample', 'method superiority'],
            'status_interpretation': 'MET means the stated scoped positive layer is supported. UNRESOLVED includes unavailable evidence, a retained gate not passed, or a failed binding; it does not assert that the scientific claim or physical read is false.',
            'semantic_modules_used': 'Protocol-pinned module files were hashed only; neither imported nor executed.'})
        con.close()
    except Exception as e:
        result.update({'error_type': type(e).__name__, 'error': str(e)})
    result['elapsed_seconds'] = time.perf_counter() - begin
    result['completed_at_utc'] = datetime.now(timezone.utc).isoformat()
    b = (json.dumps(result, indent=2, ensure_ascii=False) + '\n').encode()
    need(len(b) <= 2 * 1024**2, 'Output budget exceeded.')
    with (HERE / 'BASELINE_RESULT_V02.json').open('xb') as f:
        f.write(b)
    print(json.dumps({'status': result['status'], 'elapsed_seconds': result['elapsed_seconds'],
                      'layer_label_count': result.get('layer_label_count'), 'scenarios': [{k: x[k] for k in ['id','layers','joint_distinct_identity_count']} for x in result.get('scenarios',[])],
                      'result_bytes': len(b), 'result_sha256': digest(b), 'error': result.get('error')}))
    return 0 if result['status'] == 'PASS_INDEPENDENT_SQL_HASH_JOIN_BASELINE' else 1

def main():
    global HERE, PROTOCOL, RESOURCE_CHECK
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--protocol', required=True, type=Path)
    ap.add_argument('--output', required=True, type=Path)
    ap.add_argument('--resource-check', required=True, type=Path)
    args = ap.parse_args()
    HERE, PROTOCOL, RESOURCE_CHECK = args.output.resolve(), args.protocol.resolve(), args.resource_check.resolve()
    need(HERE.is_dir() and not (HERE/'BASELINE_RESULT_V02.json').exists(), 'Output must exist without a previous result.')
    need(not HERE.is_relative_to(Path(__file__).resolve().parent), 'Output must be outside bundle.')
    return run()

if __name__ == '__main__':
    raise SystemExit(main())
