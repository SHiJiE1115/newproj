"""Independent semantic checker for rules-v2 finite-world certificates.

This module does not call the certificate generator or its group evaluator.
It shares only the canonical hash codec and data types with the generator.
The caller supplies the expected request; certificate fields are not trusted.
"""

from __future__ import annotations

import hashlib
import hmac
from dataclasses import asdict, dataclass, replace
from itertools import combinations
from math import comb
from typing import Mapping

from rules_v2_core import (
    RULE_VERSION, LEVELS, AdmissionReceipt, Certificate, Claim, Observation,
    ObservationStatus, Probe, Quantifier, Status, Study, canonical_bytes, digest,
)


@dataclass(frozen=True)
class VerificationResult:
    valid: bool
    errors: tuple[str, ...]


def verify_admission_receipt(study: Study, claim: Claim, probe: Probe,
                             observation: Observation, receipt: AdmissionReceipt,
                             trusted_issuers: Mapping[str, Mapping[str, bytes]]) -> VerificationResult:
    """Audit a receipt against the *pre-observation* model and host trust keys."""
    try:
        study.validate(claim)
        probe.validate(study, claim)
    except ValueError as exc:
        return VerificationResult(False, (f"invalid input: {exc}",))
    if (observation.probe_id != probe.probe_id
            or observation.status != ObservationStatus.VERIFIED
            or not isinstance(observation.material, bytes)
            or not observation.material
            or not probe.accepts_value(observation.value)):
        return VerificationResult(False, ("observation lacks verified material",))
    key = trusted_issuers.get(receipt.issuer, {}).get(receipt.protocol_version)
    if not isinstance(key, bytes) or not key:
        return VerificationResult(False, ("unregistered issuer or protocol",))
    expected = (digest(probe), claim.target, digest(claim), digest(study.scope),
                study.scope.snapshot_digest, digest({"study": study, "claim": claim}),
                hashlib.sha256(observation.material).hexdigest(), digest(observation.value))
    actual = (receipt.probe_digest, receipt.target, receipt.claim_digest,
              receipt.scope_digest, receipt.snapshot_digest, receipt.prior_model_digest,
              receipt.material_digest, receipt.value_digest)
    if actual != expected:
        return VerificationResult(False, ("receipt binding mismatch",))
    body = asdict(receipt)
    body.pop("signature")
    calculated = hmac.new(key, canonical_bytes(body), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calculated, receipt.signature):
        return VerificationResult(False, ("receipt signature mismatch",))
    return VerificationResult(True, ())


def _recompute_groups(study: Study, claim: Claim, world, predicate: str,
                      group_size: int) -> tuple[tuple[str, ...], ...]:
    """A separate exhaustive evaluator, intentionally not using core._groups."""
    acceptable = []
    wanted = "support" if predicate == "replication" else predicate
    for record in sorted(study.records, key=lambda item: item.record_id):
        fact = world.facts[record.record_id]
        if (fact.direction == wanted and fact.applicable
                and fact.basis in claim.admissible_bases
                and LEVELS[fact.level] >= LEVELS[claim.required_level]):
            acceptable.append(record)
    output = []
    for group in combinations(acceptable, group_size):
        valid = True
        for left, right in combinations(group, 2):
            if left.source_unit_id == right.source_unit_id:
                valid = False
                break
            for dim in claim.separation_dimensions:
                if (world.origins[left.source_unit_id][dim]
                        & world.origins[right.source_unit_id][dim]):
                    valid = False
                    break
            if not valid:
                break
        if valid:
            output.append(tuple(item.record_id for item in group))
    return tuple(output)


def verify_certificate(study: Study, claim: Claim, certificate: Certificate, *,
                       predicate: str, replication_r: int = 2,
                       quantifier: Quantifier = Quantifier.CONDITIONAL,
                       max_world_checks: int | None = None,
                       max_group_candidates: int | None = None) -> VerificationResult:
    """Check a certificate against *independently supplied* input and request."""
    errors = []
    try:
        study.validate(claim)
    except ValueError as exc:
        return VerificationResult(False, (f"invalid input: {exc}",))
    if predicate not in {"support", "contra", "replication"} or replication_r < 2:
        return VerificationResult(False, ("invalid expected predicate or threshold",))
    if predicate == "replication" and not claim.separation_dimensions:
        return VerificationResult(False, ("replication needs an explicit separation dimension",))
    if not isinstance(quantifier, Quantifier):
        return VerificationResult(False, ("invalid expected quantifier",))
    if any(cap is not None and cap < 0 for cap in (max_world_checks, max_group_candidates)):
        return VerificationResult(False, ("invalid expected work cap",))
    expected_header = (RULE_VERSION, claim.target, predicate, replication_r,
                       quantifier, max_world_checks, max_group_candidates)
    actual_header = (certificate.rule_version, certificate.target, certificate.predicate,
                     certificate.replication_r, certificate.quantifier,
                     certificate.max_world_checks, certificate.max_group_candidates)
    if actual_header != expected_header:
        errors.append("request or target binding mismatch")
    scope_hash = digest(study.scope)
    claim_hash = digest(claim)
    records_hash = digest(tuple(sorted(study.records, key=lambda x: x.record_id)))
    worlds_hash = digest(tuple(sorted(study.worlds, key=lambda x: x.world_id)))
    request = {"rule_version": study.rule_version, "scope": scope_hash,
               "claim": claim_hash, "records": records_hash, "worlds": worlds_hash,
               "predicate": predicate, "r": replication_r, "quantifier": quantifier.value,
               "max_world_checks": max_world_checks,
               "max_group_candidates": max_group_candidates}
    expected_hashes = (scope_hash, claim_hash, records_hash, worlds_hash,
                       study.scope.snapshot_digest, digest(request))
    actual_hashes = (certificate.scope_digest, certificate.claim_digest,
                     certificate.records_digest, certificate.worlds_digest,
                     certificate.snapshot_digest, certificate.input_digest)
    if actual_hashes != expected_hashes:
        errors.append("input, scope, snapshot, claim, or world digest mismatch")
    if certificate.certificate_digest != digest(replace(certificate, certificate_digest="")):
        errors.append("certificate content digest mismatch")

    group_size = replication_r if predicate == "replication" else 1
    empty_proof = (not certificate.world_proofs and not certificate.conditional_groups
                   and certificate.fixed_group is None
                   and not certificate.blocking_world_by_group
                   and certificate.checked_worlds == 0)
    if not study.worlds:
        if (certificate.status != Status.INCONSISTENT
                or certificate.world_consensus_status != Status.INCONSISTENT
                or not empty_proof):
            errors.append("empty world set requires an empty INCONSISTENT proof")
        return VerificationResult(not errors, tuple(errors))
    cap_hit = ((max_world_checks is not None and len(study.worlds) > max_world_checks)
               or (max_group_candidates is not None
                   and comb(len(study.records), group_size) > max_group_candidates))
    if cap_hit:
        if (certificate.status != Status.TIMEOUT
                or certificate.world_consensus_status != Status.TIMEOUT
                or not empty_proof):
            errors.append("work cap requires an empty TIMEOUT proof")
        return VerificationResult(not errors, tuple(errors))
    if certificate.status in {Status.TIMEOUT, Status.INCONSISTENT}:
        errors.append("spurious TIMEOUT or INCONSISTENT status")

    expected_proofs = tuple((world.world_id,
                             _recompute_groups(study, claim, world, predicate, group_size))
                            for world in sorted(study.worlds, key=lambda w: w.world_id))
    actual_proofs = tuple((proof.world_id, proof.groups) for proof in certificate.world_proofs)
    if actual_proofs != expected_proofs or certificate.checked_worlds != len(expected_proofs):
        errors.append("world proof table disagrees with independent enumeration")
    chosen = tuple((world_id, groups[0]) for world_id, groups in expected_proofs if groups)
    if certificate.conditional_groups != chosen:
        errors.append("conditional witness table is not canonical")
    if len(chosen) == len(expected_proofs):
        expected_consensus = Status.MET
    elif not chosen and claim.closed_scope:
        expected_consensus = Status.NOT_MET_WITHIN_SCOPE
    else:
        expected_consensus = Status.UNRESOLVED
    if certificate.world_consensus_status != expected_consensus:
        errors.append("world-consensus status disagrees with the possible worlds")
    common = set(expected_proofs[0][1])
    for _, groups in expected_proofs[1:]:
        common &= set(groups)
    fixed = min(common) if common else None
    if certificate.fixed_group != fixed:
        errors.append("fixed group is not the world intersection")
    all_candidates = tuple(combinations(sorted(r.record_id for r in study.records),
                                        group_size))
    blockers = (tuple((group, next(world_id for world_id, groups in expected_proofs
                                   if group not in groups)) for group in all_candidates)
                if fixed is None else ())
    if certificate.blocking_world_by_group != blockers:
        errors.append("candidate-group counterexample table is incomplete or wrong")
    if quantifier == Quantifier.CONDITIONAL:
        if len(chosen) == len(expected_proofs):
            expected_status = Status.MET
        elif claim.closed_scope:
            expected_status = Status.NOT_MET_WITHIN_SCOPE
        else:
            expected_status = Status.UNRESOLVED
    elif fixed is not None:
        expected_status = Status.MET
    else:
        expected_status = Status.NOT_MET_WITHIN_SCOPE if claim.closed_scope else Status.UNRESOLVED
    if certificate.status != expected_status:
        errors.append("status disagrees with the requested quantifier")
    return VerificationResult(not errors, tuple(errors))
