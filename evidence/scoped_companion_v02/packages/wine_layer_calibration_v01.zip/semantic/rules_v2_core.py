"""Rules-v2 finite-world reference semantics for *scoped* evidence claims.

The worlds and their evidence-basis labels are declared inputs, not verified
historical facts. This module proves only statements over that finite model.
It neither discovers all real worlds nor authenticates old experimental reads.
"""

from __future__ import annotations

import hashlib
import hmac
import json
from dataclasses import asdict, dataclass, fields, is_dataclass, replace
from enum import Enum
from itertools import combinations
from math import comb
from typing import Any, Mapping


RULE_VERSION = "rules-v2.1"
LEVELS = {"unverified": 0, "reported": 1, "independently_checked": 2}
DIRECTIONS = {"support", "contra", "neutral"}


class TargetKind(str, Enum):
    PUBLIC_REPORT = "PUBLIC_REPORT"
    ARTIFACT_VERSION = "ARTIFACT_VERSION"
    PROSPECTIVE_RUN = "PROSPECTIVE_RUN"
    HISTORICAL_RUN = "HISTORICAL_RUN"


class EvidenceBasis(str, Enum):
    REPORT_TEXT = "REPORT_TEXT"
    HASHED_ARTIFACT = "HASHED_ARTIFACT"
    TRUSTED_RUN_EVENT = "TRUSTED_RUN_EVENT"
    READ_COVERAGE = "READ_COVERAGE"


class Status(str, Enum):
    MET = "MET"
    NOT_MET_WITHIN_SCOPE = "NOT_MET_WITHIN_SCOPE"
    UNRESOLVED = "UNRESOLVED"
    INCONSISTENT = "INCONSISTENT"
    TIMEOUT = "TIMEOUT"


class Quantifier(str, Enum):
    CONDITIONAL = "FOR_ALL_WORLDS_EXISTS_GROUP"
    FIXED = "EXISTS_GROUP_FOR_ALL_WORLDS"


class ObservationStatus(str, Enum):
    VERIFIED = "VERIFIED"
    INCONCLUSIVE = "INCONCLUSIVE"
    ERROR = "ERROR"


class AdmissionError(ValueError):
    """An alleged verifier receipt is absent, untrusted, or mismatched."""


def _plain(value: Any) -> Any:
    if isinstance(value, Enum):
        return value.value
    if is_dataclass(value):
        return {field.name: _plain(getattr(value, field.name)) for field in fields(value)}
    if isinstance(value, Mapping):
        return {str(k): _plain(v) for k, v in sorted(value.items(), key=lambda kv: str(kv[0]))}
    if isinstance(value, (set, frozenset)):
        return sorted(_plain(v) for v in value)
    if isinstance(value, (tuple, list)):
        return [_plain(v) for v in value]
    return value


def canonical_bytes(value: Any) -> bytes:
    """Canonical UTF-8 JSON for local hashes; hashes are not signatures."""
    return json.dumps(_plain(value), ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def digest(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


@dataclass(frozen=True)
class Target:
    kind: TargetKind
    target_id: str


@dataclass(frozen=True)
class Scope:
    scope_id: str
    scope_version: str
    snapshot_digest: str
    assumptions: tuple[str, ...]


@dataclass(frozen=True)
class Claim:
    claim_id: str
    target: Target
    separation_dimensions: tuple[str, ...]
    admissible_bases: tuple[EvidenceBasis, ...]
    required_level: str = "reported"
    closed_scope: bool = True


@dataclass(frozen=True)
class EvidenceRecord:
    record_id: str
    source_unit_id: str
    experiment_design_id: str
    target: Target
    locator: str


@dataclass(frozen=True)
class EvidenceFact:
    direction: str
    applicable: bool
    basis: EvidenceBasis = EvidenceBasis.REPORT_TEXT
    level: str = "reported"


@dataclass(frozen=True)
class World:
    world_id: str
    facts: Mapping[str, EvidenceFact]
    # Source unit -> dimension -> nonempty set of source identities.
    origins: Mapping[str, Mapping[str, frozenset[str]]]


@dataclass(frozen=True)
class Study:
    scope: Scope
    records: tuple[EvidenceRecord, ...]
    worlds: tuple[World, ...]
    rule_version: str = RULE_VERSION

    def validate(self, claim: Claim) -> None:
        if self.rule_version != RULE_VERSION:
            raise ValueError("rules-v2.1 is required; older certificate rules stay separate")
        if not isinstance(claim.target.kind, TargetKind) or not claim.target.target_id:
            raise ValueError("target needs a categorical kind and nonempty identifier")
        if (not claim.claim_id or claim.required_level not in LEVELS
                or not isinstance(claim.closed_scope, bool)):
            raise ValueError("invalid claim identifier, level, or closed-scope flag")
        if (len(set(claim.separation_dimensions)) != len(claim.separation_dimensions)
                or any(not d for d in claim.separation_dimensions)):
            raise ValueError("separation dimensions must be distinct and nonempty strings")
        if (not claim.admissible_bases
                or len(set(claim.admissible_bases)) != len(claim.admissible_bases)
                or any(not isinstance(b, EvidenceBasis) for b in claim.admissible_bases)):
            raise ValueError("supply explicit categorical evidence bases")
        if (not self.scope.scope_id or not self.scope.scope_version
                or len(self.scope.snapshot_digest) != 64
                or any(c not in "0123456789abcdef" for c in self.scope.snapshot_digest)
                or not self.scope.assumptions):
            raise ValueError("scope needs a snapshot SHA-256 and model assumptions")
        ids = [r.record_id for r in self.records]
        units = {r.source_unit_id for r in self.records}
        if len(ids) != len(set(ids)) or any(
            not r.record_id or not r.source_unit_id or not r.experiment_design_id
            or not r.locator or r.target != claim.target for r in self.records
        ):
            raise ValueError("invalid, duplicate, or other-target evidence record")
        if len({w.world_id for w in self.worlds}) != len(self.worlds):
            raise ValueError("duplicate world identifier")
        for world in self.worlds:
            if not world.world_id or set(world.facts) != set(ids) or set(world.origins) != units:
                raise ValueError("each world must cover all records and source units")
            for fact in world.facts.values():
                if (not isinstance(fact, EvidenceFact)
                        or fact.direction not in DIRECTIONS or fact.level not in LEVELS
                        or not isinstance(fact.applicable, bool)
                        or not isinstance(fact.basis, EvidenceBasis)):
                    raise ValueError("invalid evidence fact")
            for dim_map in world.origins.values():
                if not set(claim.separation_dimensions) <= set(dim_map):
                    raise ValueError("world lacks an explicitly requested dimension")
                if any(not isinstance(dim_map[d], (set, frozenset))
                       or not dim_map[d]
                       or any(not isinstance(x, str) or not x for x in dim_map[d])
                       for d in claim.separation_dimensions):
                    raise ValueError("source identity sets must be nonempty")


def fingerprints(study: Study, claim: Claim, predicate: str, r: int,
                 quantifier: Quantifier, max_world_checks: int | None = None,
                 max_group_candidates: int | None = None) -> dict[str, str]:
    """Bind the exact target, scope, snapshot, records, worlds, and request."""
    scope_hash = digest(study.scope)
    claim_hash = digest(claim)
    records_hash = digest(tuple(sorted(study.records, key=lambda x: x.record_id)))
    worlds_hash = digest(tuple(sorted(study.worlds, key=lambda x: x.world_id)))
    request = {"rule_version": study.rule_version, "scope": scope_hash,
               "claim": claim_hash, "records": records_hash, "worlds": worlds_hash,
               "predicate": predicate, "r": r, "quantifier": quantifier.value,
               "max_world_checks": max_world_checks,
               "max_group_candidates": max_group_candidates}
    return {"scope_digest": scope_hash, "claim_digest": claim_hash,
            "records_digest": records_hash, "worlds_digest": worlds_hash,
            "input_digest": digest(request)}


def _eligible(record: EvidenceRecord, world: World, claim: Claim, predicate: str) -> bool:
    fact = world.facts[record.record_id]
    wanted = "support" if predicate == "replication" else predicate
    return (fact.direction == wanted and fact.applicable
            and fact.basis in claim.admissible_bases
            and LEVELS[fact.level] >= LEVELS[claim.required_level])


def _separated(a: EvidenceRecord, b: EvidenceRecord, world: World,
               dimensions: tuple[str, ...]) -> bool:
    if a.source_unit_id == b.source_unit_id:
        return False
    left, right = world.origins[a.source_unit_id], world.origins[b.source_unit_id]
    return all(left[d].isdisjoint(right[d]) for d in dimensions)


def _groups(study: Study, claim: Claim, world: World, predicate: str,
            r: int) -> tuple[tuple[str, ...], ...]:
    group_size = r if predicate == "replication" else 1
    eligible = sorted((e for e in study.records if _eligible(e, world, claim, predicate)),
                      key=lambda e: e.record_id)
    return tuple(tuple(e.record_id for e in group)
                 for group in combinations(eligible, group_size)
                 if all(_separated(a, b, world, claim.separation_dimensions)
                        for a, b in combinations(group, 2)))


@dataclass(frozen=True)
class WorldProof:
    world_id: str
    groups: tuple[tuple[str, ...], ...]


@dataclass(frozen=True)
class Certificate:
    rule_version: str
    target: Target
    predicate: str
    replication_r: int
    quantifier: Quantifier
    max_world_checks: int | None
    max_group_candidates: int | None
    # Truth of the requested quantified formula over the declared worlds.
    status: Status
    # Three-valued state of the requested evidence predicate across possible worlds.
    world_consensus_status: Status
    world_proofs: tuple[WorldProof, ...]
    conditional_groups: tuple[tuple[str, tuple[str, ...]], ...]
    fixed_group: tuple[str, ...] | None
    # For each candidate group, a named world in which it fails (when no fixed group exists).
    blocking_world_by_group: tuple[tuple[tuple[str, ...], str], ...]
    checked_worlds: int
    scope_digest: str
    claim_digest: str
    records_digest: str
    worlds_digest: str
    snapshot_digest: str
    input_digest: str
    certificate_digest: str = ""


def seal_certificate(cert: Certificate) -> Certificate:
    return replace(cert, certificate_digest=digest(replace(cert, certificate_digest="")))


def certify(study: Study, claim: Claim, predicate: str, *, replication_r: int = 2,
            quantifier: Quantifier = Quantifier.CONDITIONAL,
            max_world_checks: int | None = None,
            max_group_candidates: int | None = None) -> Certificate:
    study.validate(claim)
    if predicate not in {"support", "contra", "replication"}:
        raise ValueError("unknown predicate")
    if replication_r < 2 or not isinstance(quantifier, Quantifier):
        raise ValueError("invalid replication threshold or quantifier")
    if predicate == "replication" and not claim.separation_dimensions:
        raise ValueError("replication requires at least one explicit separation dimension")
    if any(cap is not None and cap < 0 for cap in (max_world_checks, max_group_candidates)):
        raise ValueError("work caps must be nonnegative")
    fp = fingerprints(study, claim, predicate, replication_r, quantifier,
                      max_world_checks, max_group_candidates)
    base = dict(rule_version=RULE_VERSION, target=claim.target, predicate=predicate,
                replication_r=replication_r, quantifier=quantifier,
                max_world_checks=max_world_checks,
                max_group_candidates=max_group_candidates,
                scope_digest=fp["scope_digest"], claim_digest=fp["claim_digest"],
                records_digest=fp["records_digest"], worlds_digest=fp["worlds_digest"],
                snapshot_digest=study.scope.snapshot_digest,
                input_digest=fp["input_digest"])
    if not study.worlds:
        return seal_certificate(Certificate(**base, status=Status.INCONSISTENT,
            world_consensus_status=Status.INCONSISTENT,
            world_proofs=(), conditional_groups=(), fixed_group=None,
            blocking_world_by_group=(), checked_worlds=0))
    group_size = replication_r if predicate == "replication" else 1
    if ((max_world_checks is not None and len(study.worlds) > max_world_checks)
            or (max_group_candidates is not None
                and comb(len(study.records), group_size) > max_group_candidates)):
        return seal_certificate(Certificate(**base, status=Status.TIMEOUT,
            world_consensus_status=Status.TIMEOUT,
            world_proofs=(), conditional_groups=(), fixed_group=None,
            blocking_world_by_group=(), checked_worlds=0))
    proofs = tuple(WorldProof(w.world_id, _groups(study, claim, w, predicate, replication_r))
                   for w in sorted(study.worlds, key=lambda w: w.world_id))
    selected = tuple((p.world_id, p.groups[0]) for p in proofs if p.groups)
    common = set(proofs[0].groups)
    for p in proofs[1:]:
        common.intersection_update(p.groups)
    fixed = min(common) if common else None
    all_candidate_groups = tuple(combinations(sorted(r.record_id for r in study.records),
                                              group_size))
    blockers = (tuple((g, next(p.world_id for p in proofs if g not in p.groups))
                      for g in all_candidate_groups) if fixed is None else ())
    if len(selected) == len(proofs):
        world_consensus_status = Status.MET
    elif not selected and claim.closed_scope:
        world_consensus_status = Status.NOT_MET_WITHIN_SCOPE
    else:
        world_consensus_status = Status.UNRESOLVED
    if quantifier == Quantifier.CONDITIONAL:
        if len(selected) == len(proofs):
            status = Status.MET
        elif claim.closed_scope:
            status = Status.NOT_MET_WITHIN_SCOPE
        else:
            status = Status.UNRESOLVED
    elif fixed is not None:
        status = Status.MET
    else:
        status = Status.NOT_MET_WITHIN_SCOPE if claim.closed_scope else Status.UNRESOLVED
    return seal_certificate(Certificate(**base, status=status,
        world_consensus_status=world_consensus_status, world_proofs=proofs,
        conditional_groups=selected, fixed_group=fixed,
        blocking_world_by_group=blockers, checked_worlds=len(proofs)))


@dataclass(frozen=True)
class Probe:
    probe_id: str
    kind: str
    record_id: str | None = None
    left_unit: str | None = None
    right_unit: str | None = None
    dimension: str | None = None

    def validate(self, study: Study, claim: Claim) -> None:
        if not self.probe_id:
            raise ValueError("probe identifier is required")
        if self.kind in {"direction", "applicable", "basis", "level"}:
            if (self.record_id not in {r.record_id for r in study.records}
                    or any(x is not None for x in
                           (self.left_unit, self.right_unit, self.dimension))):
                raise ValueError("probe names an unknown record")
        elif self.kind == "origin_overlap":
            units = {r.source_unit_id for r in study.records}
            if (self.record_id is not None
                    or self.left_unit not in units or self.right_unit not in units
                    or self.left_unit == self.right_unit
                    or self.dimension not in claim.separation_dimensions):
                raise ValueError("probe names an invalid source-unit pair or dimension")
        else:
            raise ValueError("unknown probe kind")

    def value_in(self, world: World) -> Any:
        if self.kind in {"direction", "applicable", "basis", "level"}:
            fact = world.facts[self.record_id]
            return getattr(fact, self.kind)
        if self.kind == "origin_overlap":
            return not world.origins[self.left_unit][self.dimension].isdisjoint(
                world.origins[self.right_unit][self.dimension])
        raise ValueError("unknown probe kind")

    def accepts_value(self, value: Any) -> bool:
        if self.kind == "direction":
            return isinstance(value, str) and value in DIRECTIONS
        if self.kind in {"applicable", "origin_overlap"}:
            return isinstance(value, bool)
        if self.kind == "basis":
            return isinstance(value, EvidenceBasis)
        if self.kind == "level":
            return isinstance(value, str) and value in LEVELS
        return False


@dataclass(frozen=True)
class Observation:
    probe_id: str
    status: ObservationStatus
    value: Any = None
    material: bytes = b""


@dataclass(frozen=True)
class AdmissionReceipt:
    issuer: str
    protocol_version: str
    probe_digest: str
    target: Target
    claim_digest: str
    scope_digest: str
    snapshot_digest: str
    prior_model_digest: str
    material_digest: str
    value_digest: str
    signature: str


@dataclass(frozen=True)
class AdmissionResult:
    study: Study
    receipt: AdmissionReceipt | None
    removed_world_ids: tuple[str, ...]


def _receipt_body(receipt: AdmissionReceipt) -> dict[str, Any]:
    return {k: v for k, v in asdict(receipt).items() if k != "signature"}


def sign_receipt(*, issuer: str, protocol_version: str, key: bytes,
                 study: Study, claim: Claim, probe: Probe,
                 observation: Observation) -> AdmissionReceipt:
    """Called only by a trusted verifier service; its key must stay outside LLM inputs.

    This is a symmetric local admission mechanism, not a public attestation.
    The service must itself validate that material supports the observed value.
    """
    study.validate(claim)
    probe.validate(study, claim)
    if (observation.status != ObservationStatus.VERIFIED
            or observation.probe_id != probe.probe_id or not observation.material
            or not isinstance(observation.material, bytes)
            or not probe.accepts_value(observation.value)
            or not issuer or not protocol_version
            or not isinstance(key, bytes) or not key):
        raise AdmissionError("a verified, material-backed observation is required")
    prior = digest({"study": study, "claim": claim})
    unsigned = AdmissionReceipt(issuer, protocol_version, digest(probe), claim.target,
        digest(claim), digest(study.scope), study.scope.snapshot_digest, prior,
        hashlib.sha256(observation.material).hexdigest(), digest(observation.value), "")
    signature = hmac.new(key, canonical_bytes(_receipt_body(unsigned)),
                         hashlib.sha256).hexdigest()
    return replace(unsigned, signature=signature)


def admit_observation(study: Study, claim: Claim, probe: Probe,
                      observation: Observation, receipt: AdmissionReceipt | None,
                      trusted_issuers: Mapping[str, Mapping[str, bytes]]) -> AdmissionResult:
    """Narrow worlds only after a registered issuer's bound receipt verifies.

    ``trusted_issuers`` is a host-owned registry issuer -> protocol -> HMAC key.
    A caller-supplied ``reliable`` boolean is deliberately absent.
    """
    study.validate(claim)
    probe.validate(study, claim)
    if observation.probe_id != probe.probe_id:
        raise AdmissionError("probe and observation identifiers differ")
    if not isinstance(observation.status, ObservationStatus):
        raise AdmissionError("unknown observation status")
    if observation.status != ObservationStatus.VERIFIED:
        return AdmissionResult(study, None, ())
    if (receipt is None or not isinstance(observation.material, bytes)
            or not observation.material or not probe.accepts_value(observation.value)):
        raise AdmissionError("verified observation needs a material-backed receipt")
    key = trusted_issuers.get(receipt.issuer, {}).get(receipt.protocol_version)
    if not isinstance(key, bytes) or not key:
        raise AdmissionError("unregistered verifier or protocol")
    expected = (digest(probe), claim.target, digest(claim), digest(study.scope),
                study.scope.snapshot_digest, digest({"study": study, "claim": claim}),
                hashlib.sha256(observation.material).hexdigest(), digest(observation.value))
    actual = (receipt.probe_digest, receipt.target, receipt.claim_digest,
              receipt.scope_digest, receipt.snapshot_digest, receipt.prior_model_digest,
              receipt.material_digest, receipt.value_digest)
    signature = hmac.new(key, canonical_bytes(_receipt_body(receipt)),
                         hashlib.sha256).hexdigest()
    if actual != expected or not hmac.compare_digest(signature, receipt.signature):
        raise AdmissionError("receipt signature or binding mismatch")
    kept = tuple(w for w in study.worlds if probe.value_in(w) == observation.value)
    removed = tuple(w.world_id for w in study.worlds if probe.value_in(w) != observation.value)
    return AdmissionResult(replace(study, worlds=kept), receipt, removed)
