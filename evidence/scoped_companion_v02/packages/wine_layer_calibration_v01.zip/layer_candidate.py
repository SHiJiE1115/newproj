"""Finite retrospective Wine claim-layer calibration; no experiment or crypto rerun.

Only pinned, retained evidence is admitted. The rules engine checks the resulting
explicit fact model, not the truth or completeness of all possible histories.
"""
from __future__ import annotations
import argparse
import base64
import csv
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP, localcontext
import hashlib
import importlib.util
import io
import json
from pathlib import Path, PurePosixPath
import sys
import tarfile
import time

PROTOCOL_SHA256 = '3d5f542359cc385cd6edacc3612994fecb034dcedae4e3322602c1aea934641f'
PASS = 'PASS_PROSPECTIVE_STRACE_OBSERVATION_ONLY'
FIELDS = ('repository', 'source_commit', 'run_id', 'attempt', 'protocol_sha256', 'tar_sha256')
CSV_FIELDS = ['draw','seed','train_accuracy','test_accuracy','n_leaves','height','bound','time']


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def plain(value):
    return json.loads(json.dumps(value, default=lambda x: x.value if hasattr(x, 'value') else x.__dict__))


def pinned(spec):
    b = Path(spec['path']).read_bytes()
    require(len(b) == spec['bytes'] and sha(b) == spec['sha256'], 'PIN_MISMATCH:' + Path(spec['path']).name)
    return b


def edge(out, name, observed, expected):
    out.append({'edge': name, 'observed': observed, 'expected': expected, 'passed': observed == expected})


def all_edges(edges):
    return all(e['passed'] for e in edges)


def compare_keys(out, prefix, actual, expected):
    for k in FIELDS:
        edge(out, prefix + '.' + k, actual[k], expected[k])


def load_run(name, spec):
    blobs = {k:pinned(v) for k,v in spec['files'].items()}
    members = {}
    with tarfile.open(fileobj=io.BytesIO(blobs['receipt.tar']), mode='r:') as archive:
        for item in archive.getmembers():
            path = PurePosixPath(item.name)
            require(not path.is_absolute() and '..' not in path.parts and item.name not in members,
                    'UNSAFE_OR_DUPLICATE_TAR_MEMBER')
            require(item.isfile() and item.size <= 4*1024*1024, 'UNEXPECTED_TAR_MEMBER_TYPE_OR_SIZE')
            members[item.name] = archive.extractfile(item).read()
    host = json.loads(members['host_run.json'])
    protocol = json.loads(members['source/experiment/PROTOCOL.json'])
    ident = spec['identity']
    k = {'repository': ident['GITHUB_REPOSITORY'], 'source_commit': ident['GITHUB_SHA'],
         'run_id': ident['GITHUB_RUN_ID'], 'attempt': ident['GITHUB_RUN_ATTEMPT'],
         'protocol_sha256': spec['protocol_sha256'], 'tar_sha256':sha(blobs['receipt.tar'])}
    checks=[]
    for field,value in ident.items(): edge(checks,'host.'+field,host['github_environment'].get(field),value)
    edge(checks,'protocol_sha256',sha(members['source/experiment/PROTOCOL.json']),spec['protocol_sha256'])
    edge(checks,'host_protocol_sha256',host['source_hashes'].get('experiment/PROTOCOL.json'),spec['protocol_sha256'])
    edge(checks,'protocol_schema',protocol['schema'],spec['protocol_schema'])
    nonce=sha(f"{k['source_commit']}:{k['run_id']}:{k['attempt']}".encode())[:32]
    edge(checks,'frozen_nonce',spec['run_nonce'],nonce)
    edge(checks,'host_nonce',host.get('run_nonce'),nonce)
    edge(checks,'container_command_nonce',host['container_command'][-1],nonce)
    for member,digest in spec['source_python_member_sha256'].items():
        edge(checks,'member.'+member,sha(members[member]),digest)
        edge(checks,'host_source.'+member,host['source_hashes'].get(member.removeprefix('source/')),digest)
    for tag,member in [('author','inputs/author.zip'),('data','inputs/wine.raw')]:
        edge(checks,'input_sha.'+tag,sha(members[member]),protocol[tag]['sha256'])
        edge(checks,'input_bytes.'+tag,len(members[member]),protocol[tag]['bytes'])
    cand=json.loads(blobs['CANDIDATE_REPORT.json']); direct=json.loads(blobs['DIRECT_BASELINE_REPORT.json'])
    gate=json.loads(blobs['POSTRUN_RELEASE_GATE.json'])
    edge(checks,'candidate_tar',cand.get('tar_sha256'),k['tar_sha256'])
    edge(checks,'direct_tar',direct.get('observations',{}).get('tar_sha256'),k['tar_sha256'])
    edge(checks,'gate_tar',gate.get('receipt_tar_sha256'),k['tar_sha256'])
    edge(checks,'candidate_caller_identity',cand.get('expected_github_identity_from_caller'),ident)
    g=gate['expected_external_identity']
    for field,gfield in [('repository','repository'),('source_commit','head_sha'),('run_id','run_id'),('attempt','attempt')]:
        edge(checks,'gate_identity.'+field,str(g[gfield]),k[field])
    require(all_edges(checks),'NATIVE_SOURCE_BINDING_FAILED:'+name)
    return {'name':name,'key':k,'members':members,'host':host,'protocol':protocol,'nonce':nonce,
            'candidate':cand,'direct':direct,'gate':gate,'binding_checks':checks,
            'file_bindings':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in blobs.items()}}


def numeric(csv_run, summary_run, target):
    out=[]; cm=csv_run['members']; sm=summary_run['members'];
    compare_keys(out,'csv_donor_to_target',csv_run['key'],target['key'])
    compare_keys(out,'summary_to_target',summary_run['key'],target['key'])
    summary_member='out/author_result_'+summary_run['nonce']+'.json'
    present={'csv':'results/ours.csv' in cm,'summary':summary_member in sm,
             'params':'results/ours_exp_params.py' in sm}
    for key,val in present.items():edge(out,'present.'+key,val,True)
    info={'csv_source':csv_run['name'],'summary_source':summary_run['name'],
          'summary_member':summary_member,'checks':out,'observations':{},'admitted':False}
    if not all(present.values()):
        info['diagnostic']='UNAVAILABLE_RETAINED_OUTPUT_NOT_A_NEGATIVE_HISTORY';return info
    b=cm['results/ours.csv'];summary=json.loads(sm[summary_member]);params=sm['results/ours_exp_params.py']
    rows=list(csv.DictReader(io.StringIO(b.decode('utf-8'))))
    edge(out,'csv_fields',list(rows[0]) if rows else [],CSV_FIELDS)
    edge(out,'row_count',len(rows),25)
    edge(out,'summary_csv_rows',summary.get('csv_rows'),25)
    edge(out,'csv_to_recipient_summary_sha256',sha(b),summary.get('csv_sha256'))
    edge(out,'summary_first_row',summary.get('first_row'),rows[0] if rows else None)
    edge(out,'summary_last_row',summary.get('last_row'),rows[-1] if rows else None)
    edge(out,'draw_sequence',[int(r['draw']) for r in rows],list(range(25)))
    edge(out,'seed_sequence',[int(r['seed']) for r in rows],list(range(1,242,10)))
    edge(out,'summary_status',summary.get('status'),'success')
    edge(out,'summary_nonce_to_host',summary.get('run_nonce'),summary_run['host'].get('run_nonce'))
    edge(out,'summary_nonce_to_target',summary.get('run_nonce'),target['nonce'])
    edge(out,'params_to_summary_sha256',sha(params),summary.get('params_sha256'))
    edge(out,'params_to_target_sha256',sha(params),sha(target['members']['results/ours_exp_params.py']))
    edge(out,'summary_shape',summary.get('shape'),[178,13,3])
    with localcontext() as ctx:
        ctx.prec=80
        vals=[Decimal(r['test_accuracy']) for r in rows]
        finite=bool(vals) and all(v.is_finite() for v in vals)
        edge(out,'finite_accuracy',finite,True)
        if finite:
            mean=sum(vals)/len(vals);sd=(sum((v-mean)**2 for v in vals)/len(vals)).sqrt()
            rounded=[str(v.quantize(Decimal('0.001'),rounding=ROUND_HALF_UP)) for v in (mean,sd)]
            grid=all(0<=v<=1 and abs(v*45-(v*45).to_integral_value())<Decimal('1e-11') for v in vals)
            edge(out,'accuracy_grid',grid,True)
            edge(out,'rounded_protocol_target',rounded,target['protocol']['target']['reported_mean_sd_3dp'])
            info['observations']={'rows':len(rows),'mean_decimal':str(mean),'population_sd_decimal':str(sd),
                    'rounded_mean_sd':rounded,'csv_sha256':sha(b),'summary_sha256':sha(sm[summary_member]),
                    'params_sha256':sha(params),'nonce':summary.get('run_nonce')}
    info['admitted']=all_edges(out)
    info['diagnostic']='ADMITTED_ARTIFACT_ARITHMETIC' if info['admitted'] else 'OUTPUT_OR_IDENTITY_BINDING_NOT_MET'
    return info


def selected_read(run,target):
    out=[];compare_keys(out,'retained_read_to_target',run['key'],target['key'])
    c=run['candidate'];d=run['direct'];cc=c['receipt_audit'].get('checks',{});dc=d.get('checks',{})
    for prefix,report in [('candidate',c),('candidate_audit',c['receipt_audit']),('direct',d)]:
        edge(out,prefix+'.status',report.get('status'),PASS)
    for prefix,checks in [('candidate',cc),('direct',dc)]:
        edge(out,prefix+'.all_recorded_checks_pass',bool(checks) and all(x is True for x in checks.values()),True)
    for k in ['author_execve_same_pid','wine_open_observed','wine_positive_read_observed','execve_wine_order',
              'trace_isolation_observed','frozen_source_snapshot','source_hashes']:
        edge(out,'candidate.'+k,cc.get(k),True)
    for k in ['author_execve_same_pid','wine_open_and_read','execve_wine_order','receipt_source_snapshot','local_frozen_protocol']:
        edge(out,'direct.'+k,dc.get(k),True)
    return {'source':run['name'],'admitted':all_edges(out),'checks':out,
            'retained_native_gate':'OBSERVED' if c.get('status')==d.get('status')==PASS else 'NOT_PASSED',
            'limitation':'Recorded version-specific predicate only; NOT_PASSED or missing flags do not establish absence of a physical read.'}


def retained_signature(run,target,raw):
    out=[];compare_keys(out,'retained_signature_to_target',run['key'],target['key'])
    if run['name']!='v09':
        return {'source':run['name'],'admitted':False,'checks':out,
                'retained_status':run['gate']['attestation']['status'],
                'diagnostic':'NO_MATCHING_RETAINED_SUCCESSFUL_VERIFICATION_NOT_INVALID_SIGNATURE'}
    acceptance=json.loads(raw['ACCEPTANCE.json']);verified=json.loads(raw['verified.stdout.json'])
    bundle_name=acceptance['bundle_name'];bundles=[json.loads(line) for line in raw[bundle_name].splitlines() if line.strip()]
    edge(out,'retained_verification_entry_count',len(verified),1);edge(out,'retained_bundle_count',len(bundles),1)
    require(len(verified)==len(bundles)==1,'UNEXPECTED_SIGNATURE_ENTRY_COUNT')
    entry=verified[0];bundle=bundles[0];vr=entry['verificationResult'];statement=vr['statement'];cert=vr['signature']['certificate']
    edge(out,'bundle_to_saved_verified_bundle',bundle,entry['attestation']['bundle'])
    edge(out,'decoded_signed_statement',json.loads(base64.b64decode(bundle['dsseEnvelope']['payload'],validate=True)),statement)
    edge(out,'acceptance_status',acceptance.get('status'),'PASS_RETAINED_SIGNATURE_BUNDLE')
    for f in ['download_exit','verify_exit']:edge(out,'acceptance.'+f,acceptance.get(f),0)
    edge(out,'acceptance_bundle_hash',sha(raw[bundle_name]),acceptance['bundle_sha256'])
    edge(out,'acceptance_verified_stdout_hash',sha(raw['verified.stdout.json']),acceptance['verification_stdout_sha256'])
    k=run['key'];g=run['gate'];branch=g['expected_external_identity']['head_branch'];repo='https://github.com/'+k['repository']
    workflow='.github/workflows/rrnc-wine-strace.yml';ref='refs/heads/'+branch
    invocation=repo+'/actions/runs/'+k['run_id']+'/attempts/'+k['attempt'];signer=repo+'/'+workflow+'@'+ref
    for f,val in [('receipt_tar_sha256',k['tar_sha256']),('source_commit',k['source_commit']),
                  ('run_id',int(k['run_id'])),('attempt',int(k['attempt']))]:edge(out,'acceptance.'+f,acceptance.get(f),val)
    edge(out,'gate_retained_verified',g['attestation'].get('verified'),True)
    edge(out,'gate_retained_crypto_exit',g['attestation'].get('gh_exit_code'),0)
    edge(out,'gate_stdout_hash',g['attestation'].get('gh_stdout_sha256'),sha(raw['verified.stdout.json']))
    edge(out,'statement_type',statement.get('_type'),'https://in-toto.io/Statement/v1')
    edge(out,'predicate_type',statement.get('predicateType'),'https://slsa.dev/provenance/v1')
    edge(out,'subject',statement['subject'],[{'name':'receipt.tar','digest':{'sha256':k['tar_sha256']}}])
    bd=statement['predicate']['buildDefinition'];rd=statement['predicate']['runDetails']
    edge(out,'statement_workflow',bd['externalParameters']['workflow'],{'path':workflow,'ref':ref,'repository':repo})
    edge(out,'statement_dependency',bd['resolvedDependencies'],[{'digest':{'gitCommit':k['source_commit']},'uri':'git+'+repo+'@'+ref}])
    edge(out,'statement_invocation',rd['metadata']['invocationId'],invocation)
    edge(out,'statement_builder',rd['builder']['id'],signer)
    for f,val in {'githubWorkflowRepository':k['repository'],'githubWorkflowSHA':k['source_commit'],
      'githubWorkflowRef':ref,'sourceRepositoryURI':repo,'sourceRepositoryDigest':k['source_commit'],
      'sourceRepositoryRef':ref,'runInvocationURI':invocation,'subjectAlternativeName':signer,
      'buildSignerURI':signer,'buildSignerDigest':k['source_commit'],'buildConfigURI':signer,
      'buildConfigDigest':k['source_commit'],'issuer':'https://token.actions.githubusercontent.com',
      'runnerEnvironment':'github-hosted'}.items():edge(out,'retained_certificate.'+f,cert.get(f),val)
    # Do not reproduce bulky public certificate/signature material in edge diagnostics.
    for e in out:
        if e['edge'] in {'bundle_to_saved_verified_bundle','decoded_signed_statement'}:
            e['observed']={'canonical_sha256':sha(json.dumps(e['observed'],sort_keys=True,separators=(',',':')).encode())}
            e['expected']={'canonical_sha256':sha(json.dumps(e['expected'],sort_keys=True,separators=(',',':')).encode())}
    return {'source':run['name'],'admitted':all_edges(out),'checks':out,'retained_status':'RETAINED_CRYPTO_VERIFIED_RESULT',
            'fresh_cryptographic_verification':False,'trust_root_refreshed':False}


def load_semantics(specs):
    loaded=[]
    for name in ['rules_v2_core.py','rules_v2_checker.py']:
        pinned(specs[name]);module_name=name[:-3]
        spec=importlib.util.spec_from_file_location(module_name,specs[name]['path'])
        module=importlib.util.module_from_spec(spec);sys.modules[module_name]=module;spec.loader.exec_module(module);loaded.append(module)
    return loaded


def certify_layer(core,checker,scenario,layer,admitted,target_key,protocol_sha):
    kind=core.TargetKind.HISTORICAL_RUN if layer=='historical_2020_execution' else (
         core.TargetKind.ARTIFACT_VERSION if layer=='artifact_numeric' else core.TargetKind.PROSPECTIVE_RUN)
    tid=core.digest({'target_key':target_key,'layer':layer})
    target=core.Target(kind,tid);unit=core.digest(target_key)
    records=tuple(core.EvidenceRecord('evidence-reference-'+str(i),unit,'shared-wine-code-data-design',target,
                    'admitted-component/'+scenario['id']+'/'+layer) for i in range(scenario['copies']))
    facts={r.record_id:core.EvidenceFact('support' if admitted else 'neutral',admitted,
          core.EvidenceBasis.HASHED_ARTIFACT,'reported') for r in records}
    world=core.World('retained-evidence-projection',facts,{unit:{'run':frozenset([unit])}})
    scope=core.Scope('wine-retrospective-layer-calibration','iteration302-v01',protocol_sha,
       ('A single explicit fact projection, not an exhaustive model of physical or historical worlds.',
        'Only scoped predicates supported by pinned archived material are admitted.',
        'The certificate checker checks semantic certificates; it does not authenticate the adapter facts.'))
    study=core.Study(scope,records,(world,))
    claim=core.Claim(scenario['id']+':'+layer,target,('run',),(core.EvidenceBasis.HASHED_ARTIFACT,),
                     required_level='reported',closed_scope=False)
    cert=core.certify(study,claim,'support');checked=checker.verify_certificate(study,claim,cert,predicate='support')
    require(checked.valid,'SEMANTIC_CERTIFICATE_REJECTED')
    return {'status':cert.status.value,'claim':json.loads(core.canonical_bytes(claim)),
            'admitted_fact_table':json.loads(core.canonical_bytes(world)),
            'certificate':json.loads(core.canonical_bytes(cert)),
            'checker':{'valid':checked.valid,'errors':list(checked.errors)}}


def resolve_inputs(p, root):
    """Resolve only the 17 explicit protocol input descriptors inside this bundle."""
    root = root.resolve()
    specs = [d for r in p['runs'].values() for d in r['files'].values()]
    specs += list(p['v09_retained_signature_files'].values())
    specs += list(p['existing_semantic_modules'].values())
    if len(specs) != 17:
        raise ValueError('EXPECTED_17_INPUTS')
    for d in specs:
        text = d['path']
        rel = PurePosixPath(text)
        if rel.is_absolute() or '..' in rel.parts or '\\' in text or ':' in text or str(rel) != text:
            raise ValueError('INVALID_RELATIVE_INPUT_PATH')
        path = (root / text).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            raise ValueError('INPUT_OUTSIDE_BUNDLE_OR_MISSING')
        d['path'] = str(path)
    return p


def run(protocol_path):
    pb=protocol_path.read_bytes();require(sha(pb)==PROTOCOL_SHA256,'PROTOCOL_PIN_MISMATCH');p=json.loads(pb)
    p=resolve_inputs(p,protocol_path.resolve().parent)
    runs={n:load_run(n,s) for n,s in p['runs'].items()}
    signature={n:pinned(s) for n,s in p['v09_retained_signature_files'].items()}
    core,checker=load_semantics(p['existing_semantic_modules'])
    outputs=[]
    for s in p['scenarios']:
        target=runs[s['target']];donor=runs[s['numeric']]
        summary=target if s.get('csv_only_into_target_summary') else donor
        nr=numeric(donor,summary,target);rr=selected_read(runs[s['read']],target);sr=retained_signature(runs[s['signature']],target,signature)
        admitted={'artifact_numeric':nr['admitted'],'selected_read_gate':rr['admitted'],
                  'retained_signed_identity':sr['admitted'],'joint_scoped_receipt':all(x['admitted'] for x in (nr,rr,sr)),
                  'historical_2020_execution':False}
        certs={layer:certify_layer(core,checker,s,layer,admitted[layer],target['key'],sha(pb)) for layer in p['claim_layers']}
        layers={layer:certs[layer]['status'] for layer in p['claim_layers']}
        identities={tuple(target['key'][k] for k in FIELDS) for _ in range(s['copies']) if admitted['joint_scoped_receipt']}
        outputs.append({'id':s['id'],'kind':s['kind'],'target':s['target'],'target_key':target['key'],
            'layers':layers,'joint_distinct_identity_count':len(identities),'reference_count':s['copies'],
            'numeric':nr,'selected_read':rr,'retained_signature':sr,'semantic_certificates':certs,
            'positive_evidence_sources':{'artifact_numeric':{'csv':donor['name'],'summary':summary['name']} if nr['admitted'] else None,
              'selected_read_gate':s['read'] if rr['admitted'] else None,'retained_signed_identity':s['signature'] if sr['admitted'] else None},
            'historical_reason':'No admitted evidence establishes original 2020 execution; open scope, no contrary fact asserted.'})
    expected={s['id']:{k:('MET' if k in p['expected_positive_layers'][s['id']] else 'UNRESOLVED') for k in p['claim_layers']} for s in p['scenarios']}
    matches=all(o['layers']==expected[o['id']] for o in outputs)
    report={'schema':1,'status':'PASS_SCOPED_RETAINED_EVIDENCE_CALIBRATION' if matches else 'FAIL_EXPECTED_LAYER_MISMATCH',
       'protocol_sha256':sha(pb),'scenarios':outputs,'all_semantic_certificates_independently_checked':True,
       'expected_layer_matrix_matches':matches,
       'native_input_bindings':{n:{'key':r['key'],'file_bindings':r['file_bindings'],'checks':r['binding_checks']} for n,r in runs.items()},
       'signature_file_bindings':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in signature.items()},
       'semantic_module_bindings':{n:{'bytes':v['bytes'],'sha256':v['sha256']} for n,v in p['existing_semantic_modules'].items()},
       'fresh_arithmetic_only':True,'fresh_signature_verification':False,'fresh_physical_execution':False,
       'human_review':False,'claims_not_made':p['claims_not_made'],
       'semantics_scope':'Rules-v2.1 support over an explicit admitted retained-evidence fact table. This is not enumeration of complete possible histories, a trusted-service HMAC admission, or independent verification of extractor truth.'}
    return report


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--protocol',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args();require(args.output.is_dir(),'OUTPUT_DIRECTORY_MUST_EXIST')
    paths=[args.output/'CANDIDATE_RESULT_V01.json',args.output/'EXECUTION_V01.json']
    require(not any(p.exists() for p in paths),'REFUSE_OVERWRITE')
    start=time.perf_counter();began=datetime.now(timezone.utc).isoformat();exitcode=1
    try:
        report=run(args.protocol);exitcode=0 if report['status'].startswith('PASS_') else 1
    except Exception as error:
        report={'schema':1,'status':'FAIL_CANDIDATE_EXECUTION','error_class':type(error).__name__,'error':str(error)}
    b=(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode();paths[0].write_bytes(b)
    execution={'schema':1,'started_utc':began,'ended_utc':datetime.now(timezone.utc).isoformat(),
       'elapsed_seconds':time.perf_counter()-start,'exit_code':exitcode,'script_sha256':sha(Path(__file__).read_bytes()),
       'protocol_sha256':sha(args.protocol.read_bytes()),'result_sha256':sha(b),'result_bytes':len(b),
       'new_experiment':False,'network_access':False,'baseline_302_output_read':False,
       'process_exit_note':'Self-recorded requested exit; parent must additionally retain actual tool exit.'}
    paths[1].write_text(json.dumps(execution,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':report['status'],'result_sha256':sha(b),'result_bytes':len(b),'exit_code':exitcode,
         'summary':[{'id':s['id'],'layers':s['layers'],'joint_distinct_identity_count':s['joint_distinct_identity_count']} for s in report.get('scenarios',[])]}))
    raise SystemExit(exitcode)

if __name__=='__main__':main()
