"""Offline source-bound decoder with explicit core and optional-scope decisions.

This module makes no network calls. Neither literal matching nor successful
decoding certifies relevance, claim truth, or remote execution provenance.
"""
import hashlib
import json
import math
import re
import unicodedata

POLICIES = ('bindings_only', 'apply_literal_unvalidated')
MAX_RESPONSE_BYTES = 65536
MAX_SOURCE_BYTES = 1048576
MAX_SOURCE_CELLS = 10000
MAX_BINDINGS = 128
MAX_QUOTES = 32


class Rejected(ValueError):
    pass


def _check(condition, code):
    if not condition:
        raise Rejected(code)


def _fields(value, names, code):
    _check(type(value) is dict and set(value) == set(names), code)


def _ordered(points):
    return [list(point) for point in sorted(points)]


def _augment(seed):
    # Only ORIGINAL seed cells generate additions; this is one pass.
    return seed | {(0, col) for row, col in seed} | {(row, 1) for row, col in seed}


def _normalized(text):
    return ' '.join(unicodedata.normalize('NFKC', text).casefold().split())


def _duplicates(pairs):
    obj = {}
    for key, value in pairs:
        _check(key not in obj, 'DUPLICATE_JSON_KEY')
        obj[key] = value
    return obj


def _constant(value):
    raise Rejected('NONFINITE_JSON_CONSTANT')


def _receipt(policy):
    return {'schema': 1, 'decoder': 'layered_scope_decoder_v01', 'policy': policy,
            'status': 'REJECTED', 'core_status': 'NOT_EVALUATED', 'core_code': None,
            'scope_status': 'NOT_EVALUATED', 'scope_code': None,
            'source_sha256': None, 'response_content_sha256': None,
            'binding_seed_cells': [], 'base_cells': [], 'scope_candidate_seed_cells': None,
            'scope_candidate_cells': None, 'selected_seed_cells': [], 'selected_cells': [],
            'scope_applied': False, 'scope_matches': [], 'scope_axis_values': [],
            'scope_rejection_preserved_base': False, 'semantic_scope_verified': False,
            'truth_certified': False, 'remote_execution_authenticated': False, 'model_calls': 0}


def _source(source):
    _fields(source, ('claim', 'caption', 'column_ids', 'rows'), 'SOURCE_FIELDS')
    _check(type(source['claim']) is str and type(source['caption']) is str, 'SOURCE_TEXT_TYPES')
    columns, rows = source['column_ids'], source['rows']
    _check(type(columns) is list and columns and
           columns == ['c' + str(i) for i in range(1, len(columns) + 1)], 'SOURCE_COLUMNS')
    _check(type(rows) is list and rows, 'SOURCE_ROWS')
    _check(len(rows) * len(columns) <= MAX_SOURCE_CELLS, 'SOURCE_CELL_CAP')
    cells = {}
    for row_index, row in enumerate(rows):
        _fields(row, ('row_id', 'cells'), 'SOURCE_ROW_FIELDS')
        _check(row['row_id'] == 'r' + str(row_index), 'SOURCE_ROW_ID')
        _check(type(row['cells']) is list and len(row['cells']) == len(columns), 'SOURCE_ROW_WIDTH')
        for col_index, pair in enumerate(row['cells'], 1):
            _check(type(pair) is list and len(pair) == 2 and
                   pair[0] == 'r' + str(row_index) + 'c' + str(col_index), 'SOURCE_CELL_ID')
            value = pair[1]
            _check(value is None or type(value) in (str, int, float, bool), 'SOURCE_CELL_SCALAR')
            _check(type(value) is not float or math.isfinite(value), 'SOURCE_CELL_NONFINITE')
            cells[(row_index, col_index)] = (value if type(value) is str else
                                            json.dumps(value, ensure_ascii=False, allow_nan=False))
    try:
        raw = json.dumps(source, ensure_ascii=False, sort_keys=True, separators=(',', ':'),
                         allow_nan=False).encode('utf-8')
    except (ValueError, TypeError, UnicodeError, RecursionError):
        raise Rejected('SOURCE_SERIALIZATION')
    _check(len(raw) <= MAX_SOURCE_BYTES, 'SOURCE_BYTE_CAP')
    return cells, source['claim'], hashlib.sha256(raw).hexdigest()


def _axis_ids(values, prefix, allowed):
    _check(type(values) is list and values and all(type(v) is str for v in values), 'BINDING_AXIS_TYPE')
    _check(len(values) == len(set(values)), 'BINDING_DUPLICATE_ID')
    indices = []
    for value in values:
        _check(re.fullmatch(prefix + r'(0|[1-9][0-9]*)', value) is not None, 'BINDING_ID_SYNTAX')
        _check(value in allowed, 'BINDING_UNKNOWN_ID')
        indices.append(int(value[1:]))
    return indices


def _core(plan, cells):
    _fields(plan, ('abstain', 'bindings', 'scope'), 'ENVELOPE_FIELDS')
    _check(type(plan['abstain']) is bool, 'ABSTAIN_TYPE')
    bindings = plan['bindings']
    _check(type(bindings) is list and len(bindings) <= MAX_BINDINGS, 'BINDINGS_TYPE_OR_CAP')
    if plan['abstain']:
        _check(not bindings and plan['scope'] is None, 'ABSTENTION_CONFLICT')
        return set(), True
    _check(bindings, 'EMPTY_NONABSTAIN_BINDINGS')
    row_ids = {'r' + str(row) for row, col in cells}
    col_ids = {'c' + str(col) for row, col in cells}
    seed = set()
    for binding in bindings:
        _fields(binding, ('rows', 'columns'), 'BINDING_FIELDS')
        rows = _axis_ids(binding['rows'], 'r', row_ids)
        columns = _axis_ids(binding['columns'], 'c', col_ids)
        seed.update((row, col) for row in rows for col in columns)
    # Nothing is exposed until ALL bindings have passed.
    return seed, False


def _scope(scope, cells, claim, seed):
    if scope is None:
        return {'status': 'NOT_REQUESTED', 'code': 'NULL_SCOPE', 'matches': [],
                'candidate': None, 'axis_values': []}
    _fields(scope, ('axis', 'claim_quotes'), 'SCOPE_FIELDS')
    _check(scope['axis'] in ('row', 'column'), 'SCOPE_AXIS')
    quotes = scope['claim_quotes']
    _check(type(quotes) is list and 1 <= len(quotes) <= MAX_QUOTES, 'SCOPE_QUOTE_COUNT')
    _check(all(type(quote) is str for quote in quotes), 'SCOPE_QUOTE_TYPE')
    _check(len(quotes) == len(set(quotes)), 'SCOPE_DUPLICATE_QUOTE')
    # Validate every quotation before emitting an applicable candidate.
    for quote in quotes:
        _check(quote and quote in claim, 'SCOPE_QUOTE_NOT_EXACT_CLAIM_SUBSTRING')
        _check(_normalized(quote), 'SCOPE_BLANK_QUOTE')
    index = {}
    for point, value in cells.items():
        index.setdefault(_normalized(value), set()).add(point)
    matched, values, missing = [], set(), False
    for quote in quotes:
        hits = index.get(_normalized(quote), set())
        values.update(point[0 if scope['axis'] == 'row' else 1] for point in hits)
        missing = missing or not hits
        start = claim.find(quote)
        matched.append({'literal': quote, 'first_claim_occurrence': [start, start + len(quote)],
                        'source_cells': _ordered(hits)})
    if missing:
        return {'status': 'UNMATCHED_LITERAL', 'code': 'NO_WHOLE_CELL_MATCH',
                'matches': matched, 'candidate': None, 'axis_values': sorted(values)}
    candidate = {point for point in seed if point[0 if scope['axis'] == 'row' else 1] in values}
    if not candidate:
        return {'status': 'EMPTY_INTERSECTION', 'code': 'NO_SEED_ON_SCOPE_AXIS',
                'matches': matched, 'candidate': None, 'axis_values': sorted(values)}
    return {'status': 'APPLICABLE_UNVALIDATED', 'code': 'LITERAL_AXIS_ONLY',
            'matches': matched, 'candidate': candidate, 'axis_values': sorted(values)}


def compile_plan(public_input, response_text, *, scope_policy='bindings_only'):
    """Decode one complete proposal. Invalid optional metadata preserves a valid core.

    The default returns the source-bound base even when a candidate scope exists.
    Only the explicit experimental policy applies a literal scope. Neither policy
    asserts that the base or candidate is relevant or semantically correct.
    """
    if scope_policy not in POLICIES:
        raise ValueError('UNKNOWN_SCOPE_POLICY')
    result = _receipt(scope_policy)
    try:
        cells, claim, source_hash = _source(public_input)
        result['source_sha256'] = source_hash
    except (Rejected, ValueError, TypeError, UnicodeError, RecursionError) as error:
        result.update(status='INVALID_SOURCE', core_status='REJECTED_SOURCE', core_code=str(error))
        return result
    try:
        _check(type(response_text) is str, 'RESPONSE_TYPE')
        raw = response_text.encode('utf-8')
        result['response_content_sha256'] = hashlib.sha256(raw).hexdigest()
        _check(len(raw) <= MAX_RESPONSE_BYTES, 'RESPONSE_BYTE_CAP')
        plan = json.loads(response_text, object_pairs_hook=_duplicates, parse_constant=_constant)
        seed, abstain = _core(plan, cells)
    except (Rejected, ValueError, TypeError, UnicodeError, RecursionError) as error:
        result.update(status='INVALID_CORE', core_status='REJECTED', core_code=str(error))
        return result
    if abstain:
        result.update(status='ABSTAIN', core_status='ABSTAIN', core_code='EXPLICIT_ABSTENTION',
                      scope_status='NOT_REQUESTED', scope_code='ABSTENTION')
        return result
    base = _augment(seed)
    result.update(status='ACCEPTED_BASE', core_status='VALID', core_code='VALID_BINDINGS',
                  binding_seed_cells=_ordered(seed), base_cells=_ordered(base),
                  selected_seed_cells=_ordered(seed), selected_cells=_ordered(base))
    try:
        decision = _scope(plan['scope'], cells, claim, seed)
    except (Rejected, ValueError, TypeError, UnicodeError, RecursionError) as error:
        result.update(scope_status='REJECTED_METADATA', scope_code=str(error),
                      scope_rejection_preserved_base=True)
        return result
    result.update(scope_status=decision['status'], scope_code=decision['code'],
                  scope_matches=decision['matches'], scope_axis_values=decision['axis_values'])
    candidate = decision['candidate']
    if candidate is not None:
        after = _augment(candidate)
        if not candidate <= seed or not after <= base or not after <= set(cells):
            raise AssertionError('SOURCE_CONTAINMENT_INVARIANT')
        result.update(scope_candidate_seed_cells=_ordered(candidate), scope_candidate_cells=_ordered(after))
        if scope_policy == 'apply_literal_unvalidated':
            result.update(status='ACCEPTED_EXPERIMENTAL_SCOPE', scope_applied=True,
                          selected_seed_cells=_ordered(candidate), selected_cells=_ordered(after))
    if not base <= set(cells):
        raise AssertionError('BASE_SOURCE_CONTAINMENT_INVARIANT')
    return result


def compile_received(public_input, record, *, scope_policy='bindings_only'):
    """Transport-content guard only; a supplied record is not remote attestation."""
    if scope_policy not in POLICIES:
        raise ValueError('UNKNOWN_SCOPE_POLICY')
    if (type(record) is not dict or record.get('status') != 'RECEIVED'
            or record.get('finish_reason') != 'stop'
            or record.get('transport_content_complete') is not True
            or record.get('content_nonempty') is not True):
        result = _receipt(scope_policy)
        result.update(status='REJECTED_TRANSPORT', core_status='NOT_EVALUATED',
                      core_code='REQUIRE_COMPLETE_RECEIVED_STOP')
        return result
    return compile_plan(public_input, record.get('content'), scope_policy=scope_policy)
