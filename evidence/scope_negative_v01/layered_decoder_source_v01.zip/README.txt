Layered source-bound decoder, offline research candidate v01

Requirements: Python 3.9+ standard library. No installation, network, model API, keys, or supervisor is needed. This source snapshot is separate from the live worker and frozen study.

Example (run from the extracted directory; choose a NEW output file):
python -I -B decode_plan_cli_v01.py --input example_source.json --response example_bad_scope_response.txt --out example_receipt.json

The example supplies valid bindings and an invalid optional quotation: Method is a source label but is absent from the claim. Expected receipt: core_status VALID, scope_status REJECTED_METADATA, scope_rejection_preserved_base true, selected_cells [[0,2],[1,1],[1,2],[2,1],[2,2]]. This is synthetic interface behavior, not accuracy evidence.

Policies:
- bindings_only (default): return the augmented valid binding seed; inspect optional scope and record any candidate without applying it.
- apply_literal_unvalidated (explicit research option): when ALL quote and whole-cell conditions pass and the intersection is nonempty, apply the literal-axis candidate. Otherwise preserve the valid base and record the reason.

Invalid source, malformed whole JSON, any duplicate JSON key (including inside scope), nonfinite constants, invalid envelope/abstention, or ANY invalid binding rejects the entire core. There is no prefix or partial-region salvage. After whole JSON and core pass, invalid optional-scope fields or quotations are locally rejected and cannot erase the base. Unmatched literals and empty intersections have separate statuses. No alias, fuzzy match, quote splitting, invented quote or semantic repair occurs.

Bindings are unions of Cartesian products of source row IDs and column IDs. For ORIGINAL seed cells (r,c), context adds (0,c) and (r,1) ONCE. It is not a recursive closure. Row 0 is a real top header; c0 does not exist. Limits: 65536 response UTF-8 bytes; 128 bindings; 32 quotes; 10000 source cells; 1048576 canonical source UTF-8 bytes.

Use --received-json with a complete worker content record instead of --response when available. RECEIVED, finish_reason stop, transport_content_complete true and content_nonempty true are required. These fields are not authentication; execution identity, source/response hashing and cost audit remain separate. The output always leaves semantic_scope_verified, truth_certified and remote_execution_authenticated false.

The local research verification covered 19516 finite mechanical checks, including all 511 nonempty seed subsets of one 3x3 source with 19 named scope variants and both policies (19418 matrix checks), resource/corruption/transport boundaries, and 48 policy replays of 24 retained real responses. These counts do not prove universal parser security, semantic correctness, human review, population accuracy or prospective method superiority. The finite verification driver and full replay evidence are separate project artifacts, not included in this small example packet.

The repaired enabled-scope replay F1 was 0.762811 versus 0.765105 for frozen C and [0.734863,0.780318] for B's old missing-response outer bounds. The bindings-only replay was 0.765142. These are post-result transformations of old outputs, with inherited S call cost, not new independent model samples. The original negative S-B result remains unchanged. Do not infer research novelty or a justified new API study from this engineering repair.
