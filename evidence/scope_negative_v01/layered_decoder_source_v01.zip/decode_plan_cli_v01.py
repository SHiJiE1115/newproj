"""Local file interface for the layered decoder; no API or credential support."""
import argparse
import importlib.util
import json
from pathlib import Path

# Resolve the sibling module explicitly so Python's isolated mode also works.
_spec = importlib.util.spec_from_file_location('layered_scope_decoder_v01',
                                             Path(__file__).resolve().with_name('layered_scope_decoder_v01.py'))
_decoder = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_decoder)
POLICIES = _decoder.POLICIES
compile_plan = _decoder.compile_plan
compile_received = _decoder.compile_received


def strict_json(path):
    def unique(pairs):
        obj = {}
        for key, value in pairs:
            if key in obj:
                raise ValueError('DUPLICATE_JSON_KEY')
            obj[key] = value
        return obj

    def constant(value):
        raise ValueError('NONFINITE_JSON_CONSTANT')

    return json.loads(Path(path).read_bytes().decode('utf-8'),
                      object_pairs_hook=unique, parse_constant=constant)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', required=True, help='Complete public-input JSON file')
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--response', help='Raw model JSON proposal, without transport attestation')
    group.add_argument('--received-json', help='Worker content record; content flags are not authentication')
    parser.add_argument('--policy', choices=POLICIES, default='bindings_only')
    parser.add_argument('--out', required=True, help='New receipt file; existing files are never overwritten')
    args = parser.parse_args()
    target = Path(args.out)
    if target.exists():
        parser.error('--out must name a new file')
    public_input = strict_json(args.input)
    if args.response:
        result = compile_plan(public_input, Path(args.response).read_bytes().decode('utf-8'), scope_policy=args.policy)
    else:
        record = strict_json(args.received_json)
        result = compile_received(public_input, record, scope_policy=args.policy)
    with target.open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(result, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write('\n')
    print(json.dumps({'status': result['status'], 'core_status': result['core_status'],
                      'scope_status': result['scope_status'], 'receipt': str(target)}, ensure_ascii=False))
    # Rejected proposals still produce reviewable receipts and nonzero status.
    return 0 if result['core_status'] in ('VALID', 'ABSTAIN') else 2


if __name__ == '__main__':
    raise SystemExit(main())
