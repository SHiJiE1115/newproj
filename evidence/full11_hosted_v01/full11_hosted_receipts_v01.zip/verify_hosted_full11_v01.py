"""Offline receipt checks conditional on independently trusted GitHub metadata.

Expected run/commit must come from a trusted run page/API, never from the ZIP.
This checks retained execution evidence; it does not authenticate metadata files
by itself, certify literature novelty, or rerun the mathematical checker.
"""
import argparse
import datetime
import hashlib
import io
import json
from pathlib import Path
import stat
import zipfile

REPO = 'SHiJiE1115/newproj'
WORKFLOW = '.github/workflows/rrnc-full11-direct.yml'
FREEZE = '575f3f7c52340f2deea9be7e46a1d4f67c3b89ec115384565fd866116a5ca7a5'
PROOF_ZIP = '2c875b0f12ef368cc730579f68ceaf708a33cdd1481a01abd15f2aa5fc51d874'
PROOF_MANIFEST = '575ac14eed411deecc2d57663c6c1bdd90e27fa2ea34188c2e8dd965d983fd3b'
WINDOWS_RESULT = '5a2ed31d40c620919b4d4af18a21c23761026e66aabe9d14717e228ed7966b1f'
MEMBERS = {'CHILD_START.json', 'CHILD_TERMINAL.json', 'RUN_START.json', 'SOURCE_GATE.json',
           'SUMMARY.json', 'PROOF_RESULT.json', 'proof_stdout.txt', 'proof_stderr.txt'}


def need(condition, reason):
    if not condition:
        raise ValueError(reason)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def strict(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, 'DUPLICATE_JSON_KEY')
            result[key] = value
        return result

    def constant(value):
        raise ValueError('NONFINITE_JSON_CONSTANT')

    return json.loads(raw, object_pairs_hook=pairs, parse_constant=constant)


def canonical(value):
    # Type-sensitive: JSON false and numeric 0 must never be treated as equal.
    return json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False, separators=(',', ':'))


def stamp(value):
    result = datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))
    need(result.tzinfo is not None, 'TIMESTAMP_WITHOUT_TIMEZONE')
    return result


def bind(raw, descriptor, name):
    need(descriptor['name'] == name and descriptor['bytes'] == len(raw)
         and descriptor['sha256'] == sha(raw), 'OUTPUT_DESCRIPTOR:' + name)


def verify(archive_raw, run, jobs, artifact_listing, windows_raw, expected_run, expected_commit):
    need(type(expected_run) is int and expected_run > 0, 'EXPECTED_RUN_TYPE')
    need(run['id'] == expected_run and run['head_sha'] == expected_commit, 'TRUSTED_RUN_IDENTITY')
    need(run['repository']['full_name'] == REPO and run['path'] == WORKFLOW, 'TRUSTED_REPO_WORKFLOW')
    need(run['status'] == 'completed' and run['conclusion'] == 'success'
         and type(run['run_attempt']) is int and run['run_attempt'] == 1, 'TRUSTED_TERMINAL_RUN')
    need(run['event'] == 'workflow_dispatch' and run['workflow_id'] == 386029510, 'MANUAL_WORKFLOW')
    need(len(jobs['jobs']) == 1, 'JOB_COUNT')
    job = jobs['jobs'][0]
    need(job['run_id'] == expected_run and job['head_sha'] == expected_commit
         and job['name'] == 'verify-full11-direct', 'TRUSTED_JOB_IDENTITY')
    need(job['status'] == 'completed' and job['conclusion'] == 'success', 'TRUSTED_JOB_TERMINAL')
    for name in ['Verify frozen sources and replay the complete exact proof', 'Preserve actual success or failure receipts']:
        matches = [s for s in job['steps'] if s['name'] == name]
        need(len(matches) == 1 and matches[0]['status'] == 'completed'
             and matches[0]['conclusion'] == 'success', 'REQUIRED_STEP:' + name)
    need(artifact_listing['total_count'] == len(artifact_listing['artifacts']) == 1, 'ARTIFACT_COUNT')
    artifact = artifact_listing['artifacts'][0]
    need(artifact['name'] == 'full11-direct-' + str(expected_run) + '-1', 'ARTIFACT_NAME')
    need(artifact['workflow_run']['id'] == expected_run
         and artifact['workflow_run']['head_sha'] == expected_commit, 'ARTIFACT_RUN_IDENTITY')
    need(len(archive_raw) == artifact['size_in_bytes']
         and artifact['digest'] == 'sha256:' + sha(archive_raw), 'TRUSTED_ARTIFACT_DIGEST')
    need(sha(windows_raw) == WINDOWS_RESULT, 'FROZEN_WINDOWS_REFERENCE')
    with zipfile.ZipFile(io.BytesIO(archive_raw)) as archive:
        need(set(archive.namelist()) == MEMBERS and len(archive.namelist()) == len(MEMBERS), 'EXACT_ARCHIVE_MEMBER_SET')
        need(sum(i.file_size for i in archive.infolist()) <= 1048576, 'ARCHIVE_OUTPUT_CAP')
        for entry in archive.infolist():
            need(Path(entry.filename).name == entry.filename and not entry.is_dir()
                 and not stat.S_ISLNK(entry.external_attr >> 16), 'ARCHIVE_PATH')
        need(archive.testzip() is None, 'ZIP_CRC')
        raw = {name: archive.read(name) for name in MEMBERS}
    parsed = {name: strict(data) for name, data in raw.items() if name.endswith('.json')}
    start, child, terminal = (parsed[n] for n in ['RUN_START.json', 'CHILD_START.json', 'CHILD_TERMINAL.json'])
    summary, source, proof = (parsed[n] for n in ['SUMMARY.json', 'SOURCE_GATE.json', 'PROOF_RESULT.json'])
    env = start['github']
    expected_env = {'GITHUB_REPOSITORY': REPO, 'GITHUB_SHA': expected_commit, 'GITHUB_RUN_ID': str(expected_run),
                    'GITHUB_RUN_ATTEMPT': '1', 'GITHUB_WORKFLOW_REF': REPO + '/' + WORKFLOW + '@refs/heads/main',
                    'GITHUB_JOB': 'verify-full11-direct'}
    need(canonical(env) == canonical(expected_env), 'RECEIPT_GITHUB_IDENTITY')
    need(start['execution_kind'] == 'github-actions' and start['check_only'] is False, 'ACTUAL_NOT_SOURCE_GATE_ONLY')
    need(start['runtime']['system'] == proof['runtime']['system'] == 'Linux', 'ACTUAL_LINUX_RUNTIME')
    need(start['expected_freeze_sha256'] == FREEZE, 'RECEIPT_FREEZE')
    need(type(terminal['pid']) is int and terminal['pid'] > 0 and terminal['pid'] == child['pid'], 'CHILD_PID')
    need(type(terminal['actual_exit_code']) is int and terminal['actual_exit_code'] == 0, 'ACTUAL_EXIT_NOT_TYPED_ZERO')
    need(terminal['retained_process_object'] is True
         and terminal['exit_observation'] == 'Popen.communicate_returncode'
         and terminal['timed_out_and_killed'] is False, 'ACTUAL_RETAINED_PROCESS_EXIT')
    need(child['started_utc'] == terminal['started_utc'], 'CHILD_START_BINDING')
    argv = child['argv']
    need(len(argv) == 10 and argv[1:5] == ['-I', '-X', 'utf8', '-B']
         and Path(argv[5]).name == 'replay_full11_v01.py'
         and argv[6] == '--out' and Path(argv[7]).name == 'PROOF_RESULT.json'
         and argv[8:] == ['--seconds', '900'], 'CHILD_FROZEN_COMMAND')
    tolerance = datetime.timedelta(seconds=2)
    times = [stamp(run['created_at']), stamp(job['started_at']), stamp(start['started_utc']),
             stamp(child['started_utc']), stamp(terminal['observed_exit_utc']), stamp(summary['ended_utc'])]
    need(times == sorted(times) and times[-1] <= stamp(job['completed_at']) + tolerance, 'EXECUTION_TIME_ORDER')
    need(0 < terminal['wall_seconds'] < 930, 'CHILD_TIME_BUDGET')
    need(summary['status'] == 'PASS_ACTUAL_FROZEN_FULL11_PROOF_REPLAY'
         and summary['execution_kind'] == 'github-actions' and summary['child_started'] is True
         and summary['mathematical_certificate_replay_completed'] is True
         and summary['scientific_replay_completed'] is False, 'SCOPED_SUMMARY')
    bind(raw['PROOF_RESULT.json'], summary['proof_result'], 'PROOF_RESULT.json')
    bind(raw['CHILD_TERMINAL.json'], summary['child_terminal'], 'CHILD_TERMINAL.json')
    need(source['status'] == 'PASS_FROZEN_BYTES_ONLY' and source['freeze']['sha256'] == FREEZE
         and summary['source_freeze']['sha256'] == FREEZE, 'SOURCE_GATE')
    need(source['archive']['bytes'] == 3105235 and source['archive']['sha256'] == PROOF_ZIP, 'SOURCE_ARCHIVE')
    need(proof['status'] == 'PASS_SELF_CONTAINED_EXACT_FULL11_AND16_MENUS'
         and proof['manifest_sha256'] == PROOF_MANIFEST, 'MATHEMATICAL_RESULT_IDENTITY')
    need(canonical(strict(raw['proof_stdout.txt'])) == canonical(proof), 'STDOUT_RESULT_DISAGREEMENT')
    need(raw['proof_stderr.txt'] == b'', 'UNEXPECTED_CHILD_STDERR')
    windows = strict(windows_raw)
    need(windows['runtime']['system'] == 'Windows', 'REFERENCE_PLATFORM')
    omitted = {'runtime', 'wall_seconds'}
    need(set(windows) == set(proof), 'PLATFORM_RESULT_FIELD_SET')
    win_math = {k: v for k, v in windows.items() if k not in omitted}
    linux_math = {k: v for k, v in proof.items() if k not in omitted}
    need(canonical(win_math) == canonical(linux_math), 'COMPLETE_PARSED_MATH_RESULT_DIFFERS')
    for record in [start, summary, proof]:
        need(type(record['API_calls']) is int and record['API_calls'] == 0, 'NONZERO_OR_UNTYPED_MODEL_API_CALLS')
    need(proof['novelty_claim'] is False and proof['human_review_claim'] is False, 'UNSUPPORTED_SCOPE_FLAG')
    return {'status': 'PASS_ACTUAL_LINUX_RECEIPT_AND_COMPLETE_WINDOWS_MATH_COMPARISON',
            'run_id': expected_run, 'source_commit': expected_commit, 'job_id': job['id'],
            'artifact_id': artifact['id'], 'artifact_bytes': len(archive_raw), 'artifact_sha256': sha(archive_raw),
            'artifact_server_digest_matched': True, 'actual_exit_code': terminal['actual_exit_code'],
            'Linux_runtime': proof['runtime'], 'Windows_runtime': windows['runtime'],
            'Linux_wall_seconds': proof['wall_seconds'], 'Windows_wall_seconds': windows['wall_seconds'],
            'all_parsed_mathematical_fields_match': True, 'excluded_fields_only': sorted(omitted),
            'identical_mathematical_result_sha256': sha(canonical(linux_math).encode('utf-8')),
            'complete_roots': proof['complete_roots'],
            'rational_certificate_nodes': proof['main_certificates']['nodes'] + proof['direct_certificates']['nodes'],
            'legal_policies': proof['policies'], 'global_orders': proof['global_orders_checked'], 'max_ratio': proof['max_ratio'],
            'trusted_metadata_assumption': 'Supplied GitHub API snapshots must be independently trusted; the verifier does not authenticate arbitrary JSON files.',
            'historical_scientific_execution_authenticated': False, 'new_literature_priority_or_application_gain': False,
            'new_model_API_calls': 0}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ['artifact', 'github-run', 'github-jobs', 'github-artifacts', 'windows-result', 'out']:
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--expected-run-id', type=int, required=True)
    p.add_argument('--expected-source-commit', required=True)
    a = p.parse_args()
    need(not a.out.exists() and a.out.parent.is_dir(), 'NEW_OUTPUT_REQUIRED')
    result = verify(a.artifact.read_bytes(), strict(a.github_run.read_bytes()), strict(a.github_jobs.read_bytes()),
                    strict(a.github_artifacts.read_bytes()), a.windows_result.read_bytes(),
                    a.expected_run_id, a.expected_source_commit)
    with a.out.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(result, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.write('\n')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
