# Source, attribution and license scope

## Deposited research material

Aditya Putatunda, Giuseppe Cuono, Federico Orlando and Silvia Picozzi.
**AMaRaNTA: automated first-principles exchange parameters in 2D magnets
[Results]**. Materials Cloud, published 7 May 2026.

- Fixed record: https://archive.materialscloud.org/records/wygeh-jrc57
- DOI: https://doi.org/10.24435/materialscloud:he-3k
- Original archive: `group8.aiida`, published size 433,290,634 bytes.
- Original record metadata is included as `source_record_metadata.json`.

The record declares **Creative Commons Attribution 4.0 International**:
https://creativecommons.org/licenses/by/4.0/ and
https://creativecommons.org/licenses/by/4.0/legalcode . The attribution is to
the deposited source and does not imply endorsement of this audit by its authors.
The deposited material retains that license; this bundle imposes no additional
restrictions on its licensed use. The record's license declaration is not an
independent warranty of third-party ownership.

`db.sqlite3` and `objects/*.body` are byte-for-byte selected members retained
from the original archive. Original database user/computer metadata remains
part of that already-public source; the archive's authentication table is empty.
Any supplemental small JSON/text representations are retained source bytes.
`target.json`, `source_slot_map.json` and `provenance.json` are selections,
reformatting and audit descriptions, not new author-provided execution records.
The database and raw objects have not been edited to fill missing provenance.
The full original archive is not redistributed here.

## Audit implementation

`verify_vps3.py` and `four_state_arithmetic.py` are project audit implementations,
separate from deposited author source. This notice does not select a blanket
license for that implementation or represent missing author approvals. The
record's CC BY 4.0 statement applies to the deposited material, not automatically
to all files in this repository. Publication was authorized by the project user.
