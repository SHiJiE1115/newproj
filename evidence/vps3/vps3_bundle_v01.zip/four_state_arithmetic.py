"""Exact four-state arithmetic under declared, separately checked semantics.

Input directions and current text values are observations, not witnesses of
execution, convergence or valid physical spin constraints. No certificate is
issued and no scientific truth or independent replication is inferred.
"""
from fractions import Fraction as F
import re


class FourStateOutsideContract(ValueError):
    pass


def boolean(value):
    if type(value) is bool:
        return value
    token = str(value).strip().strip(".").lower()
    if token in ("true", "t"):
        return True
    if token in ("false", "f"):
        return False
    raise FourStateOutsideContract("Unrecognized declared Boolean")


def vector(raw, cap=100000):
    result = []
    for token in str(raw).split():
        if "*" in token:
            count, value = token.split("*")
            count = int(count)
        else:
            count, value = 1, token
        if count < 1 or len(result) + count > cap:
            raise FourStateOutsideContract("Vector repetition outside fixed cap")
        result.extend([F(value.replace("D", "e").replace("d", "e"))] * count)
    if not result:
        raise FourStateOutsideContract("Empty direction vector")
    return tuple(result)


def parse_incar(text):
    fields = {}
    for line in text.splitlines():
        line = re.split(r"[!#]", line, maxsplit=1)[0].strip()
        if not line or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key, value = key.strip().upper(), value.strip()
        if key in fields:
            raise FourStateOutsideContract("Duplicate raw INCAR key")
        fields[key] = value
    return fields


def infer_states(label, inputs):
    """Infer signed directions from four inputs, never from call order."""
    if len(inputs) != 4:
        raise FourStateOutsideContract("Exactly four state inputs required")
    inputs = [{k.upper(): v for k, v in item.items()} for item in inputs]
    tensor = re.fullmatch(r"J_([xyz])([xyz])", label)
    scalar = label in ("J_scalar_2NN", "J_scalar_3NN")
    anisotropy = label == "A_scalar"
    if not (tensor or scalar or anisotropy):
        raise FourStateOutsideContract("No declared formula for parameter label")
    soc = not scalar
    for item in inputs:
        if boolean(item["LSORBIT"]) != soc or boolean(item["LNONCOLLINEAR"]) != soc:
            raise FourStateOutsideContract("Stage flags disagree with frozen formula scope")
        if scalar and int(item["ISPIN"]) != 2:
            raise FourStateOutsideContract("Scalar collinear inputs require ISPIN=2")
    vectors = [vector(item["MAGMOM"] if scalar else item["M_CONSTR"]) for item in inputs]
    if len({len(v) for v in vectors}) != 1 or (not scalar and len(vectors[0]) % 3):
        raise FourStateOutsideContract("Direction lengths differ or lack triples")
    if not scalar and any(v != vector(item["MAGMOM"]) for v, item in zip(vectors, inputs)):
        raise FourStateOutsideContract("Initial and constrained directions differ")
    rows = vectors if scalar else [tuple(tuple(v[j:j+3]) for j in range(0, len(v), 3)) for v in vectors]
    varying = [i for i in range(len(rows[0])) if len({row[i] for row in rows}) > 1]
    if len(varying) != (1 if anisotropy else 2):
        raise FourStateOutsideContract("Wrong number of varying sites")
    magnitude = set()
    states = []
    axes = None if scalar else (["xyz".index(tensor[1]), "xyz".index(tensor[2])] if tensor else [0, 2])
    for row in rows:
        if anisotropy:
            values = row[varying[0]]
            nonzero = [axis for axis, value in enumerate(values) if value]
            if len(nonzero) != 1 or nonzero[0] not in axes:
                raise FourStateOutsideContract("SIA must use signed x or z directions")
            axis = nonzero[0]
            magnitude.add(abs(values[axis]))
            state = ("+" if values[axis] > 0 else "-") + "xyz"[axis]
        else:
            signs = []
            for offset, site in enumerate(varying):
                if scalar:
                    value = row[site]
                else:
                    values = row[site]
                    if any(value for axis, value in enumerate(values) if axis != axes[offset]):
                        raise FourStateOutsideContract("Parameter axes disagree with raw direction")
                    value = values[axes[offset]]
                if not value:
                    raise FourStateOutsideContract("Zero selected spin direction")
                magnitude.add(abs(value))
                signs.append("+" if value > 0 else "-")
            state = "".join(signs)
        states.append(state)
    expected = {"+x", "-x", "+z", "-z"} if anisotropy else {"++", "+-", "-+", "--"}
    if set(states) != expected or len(magnitude) != 1:
        raise FourStateOutsideContract("Directions do not form four distinct equal-magnitude states")
    if not scalar:
        forbidden = {0, 2} if anisotropy else set(axes)
        for site in range(len(rows[0])):
            if site not in varying and any(rows[0][site][axis] for axis in forbidden):
                raise FourStateOutsideContract("Reference background is not orthogonal to selected directions")
    coefficients = {state: (1 if state in ({"+z", "-z"} if anisotropy else {"++", "--"}) else -1) for state in states}
    # Report convention S=1 is declared externally. The initialization moment
    # is reported, but is deliberately not used as the denominator.
    return {"states": states, "varying_sites_zero_based": varying,
            "initialization_moment": str(next(iter(magnitude))), "coefficients": coefficients,
            "family": "SIA" if anisotropy else ("SCALAR_EXCHANGE" if scalar else "TENSOR_EXCHANGE"),
            "expected_soc_and_noncollinear": soc}


NUMBER = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eEdD][-+]?\d+)?"


def parse_outcar(text, expected_soc):
    paired = re.findall(r"energy\s+without entropy\s*=\s*(" + NUMBER + r")\s+energy\(sigma->0\)\s*=\s*(" + NUMBER + r")", text)
    free = re.findall(r"free\s+energy\s+TOTEN\s*=\s*(" + NUMBER + r")\s+eV", text)
    if not paired or not free or "General timing and accounting informations for this job" not in text:
        raise FourStateOutsideContract("No complete final printed energy and timing block")
    observed_flags = {}
    for key in ("LSORBIT", "LNONCOLLINEAR"):
        values = re.findall(r"(?im)^\s*" + key + r"\s*=\s*(\.?true\.?|\.?false\.?|T|F)(?=\s|$)", text)
        if not values or {boolean(value) for value in values} != {expected_soc}:
            raise FourStateOutsideContract("Printed OUTCAR flags disagree with frozen stage")
        observed_flags[key] = expected_soc
    return {"energy_sigma_to_zero_eV": paired[-1][1], "energy_without_entropy_eV": paired[-1][0],
            "free_energy_TOTEN_eV": free[-1], "timing_marker_present": True, "printed_flags": observed_flags}


def evaluate_mev(energies_by_state, coefficients):
    if set(energies_by_state) != set(coefficients) or len(energies_by_state) != 4:
        raise FourStateOutsideContract("Complete state energy dictionary required")
    return sum((F(str(energies_by_state[state]).replace("D", "e").replace("d", "e")) * coefficients[state]
                for state in coefficients), F(0)) * 250
