# VPS3: a fixed offline evidence audit

This bundle reproduces a current-artifact arithmetic audit of one deposited
VPS3 workflow: 12 parameters, 48 CalcJobs and 93 distinct repository objects.
It uses Python 3.10+ and the standard library. It downloads nothing.

After extracting into `bundle`, run from any directory:

```sh
python3 -I -X utf8 -B bundle/verify_vps3.py --bundle bundle --output result.json
```

The output must be outside the bundle and must not already exist. A successful
run exits 0 and writes `PASS_CURRENT_BYTES_TYPED_PORTS_AND_NUMERICAL_COMPATIBILITY`.
It verifies every manifest entry, the content-addressed objects, database typed
ports, raw input state assignment and the prespecified final sigma-to-zero
energies. Only the digest-pinned arithmetic helper is executed; archived author
source is read as text/AST. No AiiDA installation or VASP execution is needed.

## Fixed observations and boundaries

- 12/12 raw four-state results agree with the native Float and Dict values
  within the fixed 1e-7 meV tolerance and with the displayed text precision.
- 48/48 raw energies equal their stored List-slot finite-decimal values exactly.
- The separate small JSON representation agrees for 0/12 parameters under
  the declared comparison. This discrepancy is retained, not diagnosed here.
- All twelve energy Lists lack a CREATE parent in this retained graph; all
  twelve parameter Floats lack a CalcJob ancestor through CREATE/input_calc.
  Numerical equality does not reconstruct missing historical edges.

S=1 is the declared formula convention, not an inferred magnetic-moment
denominator. 40 jobs use SOC/noncollinearity and 8 use the declared collinear
conditions. This is one workflow, not twelve independent scientific samples.
Jxx had been checked earlier; full recovery added eleven parameter coverages.

These observations do not authenticate the historical raw-to-List conversion,
the runtime parser semantics, physical convergence, scientific truth or the
cause of the small-JSON discrepancy. They are not human gold labels. They do
not establish an adaptive-query or certification-method performance advantage.
A hosted execution of this verifier is an offline audit run, not a new material
calculation. It does not instantiate the complete-source contract of the
separate six/seven-query theory study.

`target.json` is a selected, reformatted scientific target from the frozen
protocol. `source_slot_map.json` records its static source interpretation.
`provenance.json` identifies the archive and preserves a scoped acquisition-cost
summary including failures and cache reuse. Full HTTP receipts are not included;
the listed totals are not the entire research cost. No whole-archive MD5 or
publisher signature was verified. The manifest checks retained bytes and is not
independent historical attestation. See `SOURCE_NOTICE.md` for attribution and
license scope.
