"""Offline, standard-library verification of the fixed VPS3 numerical bundle.

manifest.json contains files: [{path, bytes, sha256}], excluding itself.
target.json retains the scientific fields of the frozen target, without paths.
source_slot_map.json contains source_repository_key and state_coefficients.
Only the digest-pinned audit helper is executed. Archived source objects are
parsed as text/AST and are never imported or executed.
"""

import argparse
import ast
from collections import Counter
from datetime import datetime, timezone
from decimal import Decimal
from fractions import Fraction as F
import hashlib
from io import BytesIO
import json
import os
from pathlib import Path, PurePosixPath
import re
import sqlite3
import stat
import sys
import types
import zipfile

HELPER_SHA256 = '5a77cca6d6170c224d7f336c89ecbd598a0e3356394ec91334de66e7a40cecfa'
DB_SHA256 = '4739d6dc4022b08f5189f600f11031fee4bd0ef4e7ff7ed3d1bd6869832e28df'
SOURCE_KEY = '2a1f2d0808f435b64e2aa0dfd7d1e9be069880f80c28356af702d3b84630643a'
SMALL_ZIP_SHA256 = '586b2724fa05d97baa872255b8ccbb71d32db95789391c298bb71f7bcfb2f85d'
SMALL_MEMBERS = {
    'output_readble/VPS3.J_dict.txt': (419, '988690d98e95fc1297977da59e9cf3761b9f3d5d54267abedfe32435f01654a7'),
    'other_data/exchanges.json': (586223, '5c1ea9b61c4848f064f0a5887fbdcd3c0f40ccf2743077ad44eb29093410c9a2'),
}
VPS3_IDENTITY = {'pk': 39321, 'uuid': '4950e647-3097-4205-a52b-3cdc77c629af', 'label': 'VPS3'}
LABELS = {'J_' + a + b for a in 'xyz' for b in 'xyz'} | {'A_scalar', 'J_scalar_2NN', 'J_scalar_3NN'}
WORKCHAIN = 'process.workflow.workchain.WorkChainNode.'
CALCJOB = 'process.calculation.calcjob.CalcJobNode.'
CALCFUNCTION = 'process.calculation.calcfunction.CalcFunctionNode.'
DICT = 'data.core.dict.Dict.'
FLOAT = 'data.core.float.Float.'
LIST = 'data.core.list.List.'
HEX64 = re.compile(r'[0-9a-f]{64}')
FILE_CAP = 64 * 2**20
BUNDLE_CAP = 256 * 2**20
JSON_CAP = 2 * 2**20
RESULT_CAP = 2 * 2**20


class Rejected(ValueError):
    pass


def require(condition, reason):
    if not condition:
        raise Rejected(reason)


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha_file(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(2**20), b''):
            value.update(block)
    return value.hexdigest()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'DUPLICATE_JSON_KEY')
        result[key] = value
    return result


def invalid_constant(_):
    raise Rejected('NONFINITE_JSON_CONSTANT')


def json_loads(text, *, decimals=False):
    return json.loads(text, object_pairs_hook=unique_object,
                      parse_float=Decimal if decimals else float,
                      parse_constant=invalid_constant)


def read_json(path):
    require(path.stat().st_size <= JSON_CAP, 'JSON_SIZE_CAP:' + path.name)
    return json_loads(path.read_bytes())


def relative_name(name):
    require(isinstance(name, str) and name and '\\' not in name and ':' not in name,
            'INVALID_MANIFEST_PATH')
    path = PurePosixPath(name)
    require(not path.is_absolute() and path.as_posix() == name
            and all(part not in ('', '.', '..') for part in path.parts), 'NON_RELATIVE_MANIFEST_PATH')
    for part in path.parts:
        require(not part.endswith(('.', ' ')) and not re.search(r'[\x00-\x1f<>"|?*]', part),
                'NONPORTABLE_MANIFEST_PATH')
        require(not re.fullmatch(r'(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?', part, re.I),
                'RESERVED_MANIFEST_PATH')
    return name


def inventory(bundle):
    found = set()
    for directory, dirs, files in os.walk(bundle, followlinks=False):
        for name in dirs:
            require(not (Path(directory) / name).is_symlink(), 'SYMLINK_DIRECTORY')
        for name in files:
            path = Path(directory) / name
            require(stat.S_ISREG(path.lstat().st_mode), 'NON_REGULAR_BUNDLE_FILE')
            found.add(relative_name(path.relative_to(bundle).as_posix()))
            require(len(found) <= 256, 'FILE_COUNT_CAP')
    return found


def verify_manifest(bundle):
    found = inventory(bundle)
    require('manifest.json' in found, 'MISSING_MANIFEST')
    manifest = read_json(bundle / 'manifest.json')
    rows = manifest['files']
    require(isinstance(rows, list) and 0 < len(rows) <= 255, 'MANIFEST_FILE_COUNT')
    entries, folded, total = {}, set(), 0
    for row in rows:
        name = relative_name(row['path'])
        require(name != 'manifest.json' and name not in entries and name.casefold() not in folded,
                'DUPLICATE_OR_SELF_MANIFEST_ENTRY')
        require(type(row['bytes']) is int and 0 <= row['bytes'] <= FILE_CAP, 'FILE_SIZE_CAP:' + name)
        require(isinstance(row['sha256'], str) and HEX64.fullmatch(row['sha256']), 'INVALID_SHA256:' + name)
        total += row['bytes']
        require(total <= BUNDLE_CAP, 'BUNDLE_SIZE_CAP')
        entries[name] = row
        folded.add(name.casefold())
    require(found == set(entries) | {'manifest.json'}, 'MANIFEST_INVENTORY_MISMATCH')
    for name, row in entries.items():
        path = bundle / name
        require(path.stat().st_size == row['bytes'], 'FILE_LENGTH_MISMATCH:' + name)
        require(sha_file(path) == row['sha256'], 'FILE_HASH_MISMATCH:' + name)
    required = {'target.json', 'db.sqlite3', 'four_state_arithmetic.py', 'source_slot_map.json',
                'verify_vps3.py', 'small_views.zip'}
    require(required <= set(entries), 'REQUIRED_PAYLOAD_MISSING')
    require(entries['four_state_arithmetic.py']['sha256'] == HELPER_SHA256, 'UNCHECKED_HELPER')
    require(entries['db.sqlite3']['sha256'] == DB_SHA256, 'WRONG_NATIVE_DATABASE')
    require(sha_file(Path(__file__)) == entries['verify_vps3.py']['sha256'], 'EXECUTING_VERIFIER_NOT_BUNDLED_COPY')
    return entries, sha_file(bundle / 'manifest.json'), total


def checked_read(bundle, entries, name):
    require(name in entries, 'UNMANIFESTED_READ:' + name)
    raw = (bundle / name).read_bytes()
    require(len(raw) == entries[name]['bytes'] and sha_bytes(raw) == entries[name]['sha256'],
            'INPUT_CHANGED_AFTER_INVENTORY:' + name)
    return raw


def verify_small_views(bundle, entries, target, components):
    raw = checked_read(bundle, entries, 'small_views.zip')
    require(len(raw) == 53905 and sha_bytes(raw) == SMALL_ZIP_SHA256, 'SMALL_ZIP_IDENTITY')
    members = {}
    with zipfile.ZipFile(BytesIO(raw)) as archive:
        names = archive.namelist()
        for name, (size, digest) in SMALL_MEMBERS.items():
            require(names.count(name) == 1, 'SMALL_MEMBER_NOT_UNIQUE:' + name)
            info = archive.getinfo(name)
            require(info.file_size == size and not info.flag_bits & 1, 'SMALL_MEMBER_METADATA:' + name)
            data = archive.read(info)  # Fixed member, in memory; also checks its ZIP CRC.
            require(len(data) == size and sha_bytes(data) == digest, 'SMALL_MEMBER_IDENTITY:' + name)
            members[name] = data
    require(all(target['target'][key] == value for key, value in VPS3_IDENTITY.items()),
            'SMALL_VIEW_TARGET_IDENTITY')
    lines = members['output_readble/VPS3.J_dict.txt'].decode('utf-8').splitlines()
    require(lines[0] == '# VPS3  (PK 39321)', 'SMALL_TEXT_IDENTITY')
    text_to_label = {'J' + a + b: 'J_' + a + b for a in 'xyz' for b in 'xyz'}
    text_to_label.update({'J2': 'J_scalar_2NN', 'J3': 'J_scalar_3NN', 'A': 'A_scalar'})
    printed = {}
    for line in lines:
        if not line.strip() or line.lstrip().startswith('#'):
            continue
        match = re.fullmatch(r'\s*(J[xyz]{2}|J2|J3|A)\s+([+-]\d+\.\d{3})\s+(meV)\s*', line)
        require(match is not None, 'SMALL_TEXT_PARAMETER_ROW')
        key, lexeme, unit = match.groups()
        label = text_to_label[key]
        require(label not in printed, 'SMALL_TEXT_DUPLICATE_PARAMETER')
        printed[label] = (key, lexeme, unit)
    require(set(printed) == LABELS, 'SMALL_TEXT_TWELVE_KEYS')
    # Preserve source JSON number tokens verbatim; do not round through float.
    rows = json.loads(members['other_data/exchanges.json'], object_pairs_hook=unique_object,
                      parse_float=str, parse_constant=invalid_constant)
    require(isinstance(rows, list) and all(isinstance(row, dict) for row in rows), 'SMALL_JSON_ROWS')
    candidates = [row for row in rows
                  if any(row.get(key) == value for key, value in VPS3_IDENTITY.items())]
    require(len(candidates) == 1, 'SMALL_JSON_UNIQUE_VPS3_ROW')
    row = candidates[0]
    require(all(row.get(key) == value for key, value in VPS3_IDENTITY.items()), 'SMALL_JSON_IDENTITY')
    exchanges = row['exchanges']
    require(isinstance(exchanges, dict) and set(exchanges) == LABELS and row['missing'] == [],
            'SMALL_JSON_TWELVE_KEYS')
    for label, component in components.items():
        key, lexeme, unit = printed[label]
        require(component['text_key'] == key and component['printed_lexeme'] == lexeme
                and component['printed_unit'] == unit and component['printed_half_last_digit'] == '0.0005',
                'TARGET_PRINTED_LEXEME_NOT_SOURCE:' + label)
        require(type(exchanges[label]) is str and component['json_central_value'] == exchanges[label],
                'TARGET_JSON_LEXEME_NOT_SOURCE:' + label)
    return {'zip_path': 'small_views.zip', 'zip_bytes': len(raw), 'zip_sha256': SMALL_ZIP_SHA256,
            'members': [{'path': name, 'bytes': size, 'sha256': digest}
                        for name, (size, digest) in SMALL_MEMBERS.items()],
            'identity': VPS3_IDENTITY, 'unique_json_identity_rows': 1,
            'printed_source_lexemes_exactly_bound': 12, 'json_source_lexemes_exactly_bound': 12,
            'members_extracted_to_filesystem': False, 'historical_consumption_certified': False}


def exact_numeric(value):
    require(type(value) in (int, Decimal), 'NONNUMERIC_NATIVE_ATTRIBUTE')
    if isinstance(value, Decimal):
        require(value.is_finite(), 'NONFINITE_NATIVE_ATTRIBUTE')
    return F(value)


def load_checked_helper(raw):
    require(sha_bytes(raw) == HELPER_SHA256, 'UNCHECKED_HELPER_BYTES')
    module = types.ModuleType('vps3_checked_four_state_arithmetic')
    # Compile the checked bytes directly: no cached bytecode and no author source.
    exec(compile(raw, 'four_state_arithmetic.py', 'exec'), module.__dict__)
    return module


class NativeDB:
    def __init__(self, path):
        self.con = sqlite3.connect(path.resolve().as_uri() + '?mode=ro&immutable=1', uri=True)
        self.con.execute('PRAGMA query_only=ON')
        self.con.execute('PRAGMA trusted_schema=OFF')
        self.con.row_factory = sqlite3.Row

    def close(self):
        self.con.close()

    def node(self, pk, *, uuid=None, kind=None):
        row = self.con.execute('SELECT id,uuid,node_type,process_type,attributes,repository_metadata '
                               'FROM db_dbnode WHERE id=?', (pk,)).fetchone()
        require(row is not None, 'MISSING_NATIVE_NODE')
        node = dict(row)
        require(uuid is None or node['uuid'] == uuid, 'NATIVE_UUID_MISMATCH')
        require(kind is None or node['node_type'] == kind, 'NATIVE_NODE_TYPE_MISMATCH')
        node['attributes'] = json_loads(node['attributes'], decimals=True)
        node['repository_metadata'] = json_loads(node['repository_metadata'])
        return node

    def links(self, pk, kind, *, incoming=False, label=None):
        left, right = ('output_id', 'input_id') if incoming else ('input_id', 'output_id')
        sql = 'SELECT ' + right + ' FROM db_dblink WHERE ' + left + '=? AND type=?'
        args = [pk, kind]
        if label is not None:
            sql += ' AND label=?'
            args.append(label)
        return [row[0] for row in self.con.execute(sql + ' ORDER BY ' + right, args)]

    def one(self, pk, kind, *, incoming=False, label=None):
        ids = self.links(pk, kind, incoming=incoming, label=label)
        require(len(ids) == 1, 'NON_SINGLETON_TYPED_PORT:' + kind + ':' + str(label))
        return self.node(ids[0])

    def ancestry(self, pk):
        sql = '''WITH RECURSIVE a(id) AS (
            SELECT ? UNION SELECT l.input_id FROM db_dblink l JOIN a ON l.output_id=a.id
            WHERE l.type IN ('create','input_calc'))
            SELECT n.id,n.node_type FROM db_dbnode n JOIN a ON a.id=n.id ORDER BY n.id'''
        return [(row[0], row[1]) for row in self.con.execute(sql, (pk,))]


def brief(node):
    return {key: node[key] for key in ('id', 'uuid', 'node_type')}


def verify_source(db, target, raw, slot_map):
    require(sha_bytes(raw) == SOURCE_KEY and slot_map['source_repository_key'] == SOURCE_KEY,
            'SOURCE_OBJECT_IDENTITY')
    tree = ast.parse(raw.decode('utf-8'))
    definitions = {node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)}
    declared = target['source_nodes']
    ids = [row[0] for row in db.con.execute('SELECT id FROM db_dbnode WHERE node_type=? ORDER BY id', (CALCFUNCTION,))]
    require(len(declared) == 49 and sorted(row['id'] for row in declared) == ids, 'SOURCE_NODE_SET')
    for row in declared:
        node = db.node(row['id'], uuid=row['uuid'], kind=CALCFUNCTION)
        attrs = node['attributes']
        for key in ('function_name', 'function_namespace', 'function_starting_line_number', 'function_number_of_lines'):
            require(attrs[key] == row[key], 'SOURCE_METADATA_MISMATCH:' + key)
        require(node['repository_metadata']['o']['source_file']['k'] == row['repository_key'] == SOURCE_KEY,
                'SOURCE_REPOSITORY_BINDING')
        definition = definitions[row['function_name']]
        first = min([definition.lineno] + [item.lineno for item in definition.decorator_list])
        require(first == row['function_starting_line_number']
                and definition.end_lineno - first + 1 == row['function_number_of_lines'], 'SOURCE_AST_SPAN')
    rows = slot_map['state_coefficients']
    slots = {row['label']: row['source_slot_states'] for row in rows}
    require(len(rows) == len(slots) == 12 and set(slots) == LABELS, 'SOURCE_SLOT_LABELS')
    for label, states in slots.items():
        expected = ['+z', '+x', '-x', '-z'] if label == 'A_scalar' else ['++', '+-', '-+', '--']
        require(states == expected, 'SOURCE_SLOT_ORDER')
    return slots


def verify_case(db, case, group_id, helper, object_text):
    require(case['subwork_id'] == group_id, 'CASE_SUBWORK_ID')
    db.node(group_id, uuid=case['subwork_uuid'], kind=WORKCHAIN)
    work = db.node(case['work_id'], uuid=case['work_uuid'], kind=WORKCHAIN)
    calc = db.node(case['calc_id'], uuid=case['calc_uuid'], kind=CALCJOB)
    params = db.node(case['parameters_id'], uuid=case['parameters_uuid'], kind=DICT)
    retrieved = db.node(case['retrieved_id'], uuid=case['retrieved_uuid'], kind='data.core.folder.FolderData.')
    require(db.links(work['id'], 'call_calc') == [calc['id']], 'WORK_CALC_PORT')
    require(db.links(work['id'], 'input_work', incoming=True, label='parameters') == [params['id']], 'WORK_PARAMETER_PORT')
    require(db.links(work['id'], 'return', label='retrieved') == [retrieved['id']], 'WORK_RETRIEVED_PORT')
    require(db.links(retrieved['id'], 'create', incoming=True) == [calc['id']], 'RETRIEVED_CREATOR')
    require(db.links(calc['id'], 'create', label='retrieved') == [retrieved['id']], 'CALC_RETRIEVED_PORT')
    require(calc['repository_metadata']['o']['INCAR']['k'] == case['objects']['INCAR'], 'INCAR_REPOSITORY_KEY')
    require(retrieved['repository_metadata']['o']['OUTCAR']['k'] == case['objects']['OUTCAR'], 'OUTCAR_REPOSITORY_KEY')
    raw = helper.parse_incar(object_text(case['objects']['INCAR']))
    native = {key.upper(): value for key, value in params['attributes']['incar'].items()}
    direction = 'MAGMOM' if case['label'] in ('J_scalar_2NN', 'J_scalar_3NN') else 'M_CONSTR'
    for key in {direction, 'MAGMOM'}:
        require(helper.vector(raw[key]) == helper.vector(native[key]), 'RAW_NATIVE_DIRECTION')
    for flag in ('LSORBIT', 'LNONCOLLINEAR'):
        require(helper.boolean(raw[flag]) == helper.boolean(native[flag]), 'RAW_NATIVE_STAGE_FLAG')
    # This is a stored work input / selected-field relationship, not a claim
    # that every historical runtime input or consumed file is present.
    return raw


def list_path(db, subwork, label, source_nodes):
    value = db.one(subwork['id'], 'return', label='J_parameter')
    require(value['node_type'] == FLOAT, 'J_PARAMETER_NOT_FLOAT')
    creator = db.one(value['id'], 'create', incoming=True)
    require(creator['node_type'] == CALCFUNCTION and creator['id'] in source_nodes,
            'FLOAT_CREATOR_NOT_DECLARED_CALCFUNCTION')
    require(creator['attributes']['function_name'] == 'find_energy_four_state', 'WRONG_LIST_FUNCTION')
    callers = [(row[0], row[1]) for row in db.con.execute(
        "SELECT input_id,label FROM db_dblink WHERE output_id=? AND type='call_calc'", (creator['id'],))]
    require(callers == [(subwork['id'], 'CALL')], 'SUBWORK_CALCFUNCTION_CALL')
    require(db.links(creator['id'], 'create', label='result') == [value['id']], 'FUNCTION_RESULT_PORT')
    ports = [(row[0], row[1]) for row in db.con.execute(
        "SELECT input_id,label FROM db_dblink WHERE output_id=? AND type='input_calc'", (creator['id'],))]
    require(len(ports) == 1 and ports[0][1] == 'list_of_energies', 'FUNCTION_ENERGY_LIST_PORT')
    input_list = db.node(ports[0][0], kind=LIST)
    energies = input_list['attributes']['list']
    require(type(energies) is list and len(energies) == 4, 'LIST_LENGTH')
    exact = [exact_numeric(value) for value in energies]
    return value, creator, input_list, energies, exact


def verify_science(bundle, entries, result):
    target = json_loads(checked_read(bundle, entries, 'target.json'))
    slot_map = json_loads(checked_read(bundle, entries, 'source_slot_map.json'))
    require(F(target['native_absolute_tolerance_meV']) == F('0.0000001'), 'CHANGED_NATIVE_TOLERANCE')
    tolerance = F(target['native_absolute_tolerance_meV'])
    require(len(target['cases']) == 48 and len({row['calc_uuid'] for row in target['cases']}) == 48,
            'CASE_DENOMINATOR')
    require(Counter(row['label'] for row in target['cases']) == Counter({label: 4 for label in LABELS}),
            'FOUR_CASES_PER_LABEL')
    families = {row['label']: row for row in target['families']}
    components = {row['json_key']: row for row in target['components']}
    require(len(target['families']) == len(target['components']) == 12
            and set(families) == set(components) == set(target['native_values']) == LABELS, 'TARGET_LABELS')
    result['small_view_sources'] = verify_small_views(bundle, entries, target, components)
    keys = {row['repository_key'] for row in target['objects']}
    require(len(target['objects']) == len(keys) == 93 and all(HEX64.fullmatch(key) for key in keys), 'OBJECT_KEYS')
    object_names = {'objects/' + key + '.body' for key in keys}
    require({name for name in entries if name.startswith('objects/')} == object_names, 'OBJECT_INVENTORY')
    for key in keys:
        require(entries['objects/' + key + '.body']['sha256'] == key, 'CONTENT_ADDRESSED_OBJECT_HASH')
    expected_roles = {SOURCE_KEY: ['CALCFUNCTION_STORED_SOURCE_FILE']}
    for case in target['cases']:
        require(set(case['objects']) == {'INCAR', 'OUTCAR'}, 'CASE_OBJECT_ROLES')
        for role, key in case['objects'].items():
            expected_roles.setdefault(key, []).append(case['label'] + ':' + str(case['calc_id']) + ':' + role)
    require({row['repository_key']: sorted(row['roles']) for row in target['objects']}
            == {key: sorted(roles) for key, roles in expected_roles.items()}, 'OBJECT_ROLE_BINDING')

    def object_text(key):
        require(key in keys, 'UNDECLARED_OBJECT')
        return checked_read(bundle, entries, 'objects/' + key + '.body').decode('utf-8')

    helper = load_checked_helper(checked_read(bundle, entries, 'four_state_arithmetic.py'))
    db = NativeDB(bundle / 'db.sqlite3')
    try:
        top = db.node(target['target']['pk'], uuid=target['target']['uuid'], kind=WORKCHAIN)
        require(top['process_type'] == target['target']['process_type'], 'TOP_PROCESS_TYPE')
        aggregate = db.one(top['id'], 'return', label='J_dict')
        units = db.one(top['id'], 'return', label='units')
        require(aggregate['node_type'] == units['node_type'] == DICT, 'SUMMARY_NODE_TYPES')
        require(aggregate['uuid'] == target['native_output_uuid'] and units['uuid'] == target['unit_output_uuid'],
                'SUMMARY_UUIDS')
        require(units['attributes'] == target['unit_attributes'], 'UNITS_ATTRIBUTES')
        require(units['attributes']['J_parameters'] == 'meV (not divided by S^2)', 'UNIT_CONVENTION')
        require(set(aggregate['attributes']) == LABELS, 'NATIVE_AGGREGATE_LABELS')
        for label in LABELS:
            require(exact_numeric(aggregate['attributes'][label]) == F(target['native_values'][label]),
                    'TARGET_NATIVE_VALUE')
        slots = verify_source(db, target, object_text(SOURCE_KEY).encode('utf-8'), slot_map)
        result['source_metadata'] = {'declared_nodes_checked': 49, 'source_sha256': SOURCE_KEY,
                                     'AST_only': True, 'runtime_namespace_certified': False}
        groups = {}
        for pk in db.links(top['id'], 'call_work', label='CALL'):
            labels = db.links(pk, 'input_work', incoming=True, label='which_label')
            if not labels:
                continue
            require(len(labels) == 1, 'SUBWORK_LABEL_PORT')
            label_node = db.node(labels[0], kind='data.core.str.Str.')
            label = label_node['attributes']['value']
            require(label in LABELS and label not in groups, 'SUBWORK_LABEL_IDENTITY')
            groups[label] = db.node(pk, kind=WORKCHAIN)
            require(groups[label]['process_type'] == top['process_type'].rsplit('.', 1)[0] + '.SubWorkChain',
                    'SUBWORK_PROCESS_TYPE')
        require(set(groups) == LABELS, 'TWELVE_SUBWORKS')
        source_ids = {row['id'] for row in target['source_nodes']}
        for label in sorted(LABELS):
            group = [row for row in target['cases'] if row['label'] == label]
            subwork = groups[label]
            require(db.links(subwork['id'], 'call_work', label='CALL') == sorted(row['work_id'] for row in group),
                    'SUBWORK_FOUR_CALC_WORKS')
            raw_inputs = [verify_case(db, case, subwork['id'], helper, object_text) for case in group]
            bound = helper.infer_states(label, raw_inputs)
            require(bound == families[label]['native_input_directions'], 'RAW_FOUR_STATE_BINDING')
            energies = []
            for case, state in zip(group, bound['states']):
                require(state == case['native_input_state'], 'DECLARED_RAW_STATE')
                energy = helper.parse_outcar(object_text(case['objects']['OUTCAR']),
                                             bound['expected_soc_and_noncollinear'])
                energies.append({'calc_id': case['calc_id'], 'calc_uuid': case['calc_uuid'], 'state': state,
                                 'OUTCAR_repository_key': case['objects']['OUTCAR'], **energy})
            evaluated = {name: helper.evaluate_mev({row['state']: row[name] for row in energies}, bound['coefficients'])
                         for name in ('energy_sigma_to_zero_eV', 'energy_without_entropy_eV', 'free_energy_TOTEN_eV')}
            primary = evaluated['energy_sigma_to_zero_eV']
            value, creator, input_list, list_lexemes, list_values = list_path(db, subwork, label, source_ids)
            float_value = exact_numeric(value['attributes']['value'])
            dict_value = exact_numeric(aggregate['attributes'][label])
            by_state = {row['state']: row for row in energies}
            list_creators = db.links(input_list['id'], 'create', incoming=True)
            calc_ancestors = [pk for pk, kind in db.ancestry(value['id']) if kind == CALCJOB]
            for index, state in enumerate(slots[label]):
                raw_value = F(by_state[state]['energy_sigma_to_zero_eV'])
                difference = list_values[index] - raw_value
                result['slots'].append({'label': label, 'slot_zero_based': index, 'state': state,
                    'calc_uuid': by_state[state]['calc_uuid'], 'input_list': brief(input_list),
                    'raw_sigma_to_zero_eV': by_state[state]['energy_sigma_to_zero_eV'],
                    'stored_list_numeric_lexeme_eV': str(list_lexemes[index]),
                    'exact_list_minus_raw_eV': str(difference), 'exact_decimal_value_equal': difference == 0})
            list_mev = helper.evaluate_mev(dict(zip(slots[label], list_values)), bound['coefficients'])
            component = components[label]
            require(F(component['printed_half_last_digit']) == F('0.0005'), 'CHANGED_PRINT_PRECISION')
            row = {'label': label, 'subwork': brief(subwork), 'float': brief(value),
                'creator': brief(creator), 'input_list': brief(input_list),
                'raw_input_states': bound, 'energies': energies,
                'raw_results_meV': {name: str(v) for name, v in evaluated.items()},
                'native_float_meV': str(value['attributes']['value']),
                'native_dict_meV': str(aggregate['attributes'][label]), 'list_result_meV': str(list_mev),
                'raw_native_float_difference_meV': str(primary - float_value),
                'raw_native_dict_difference_meV': str(primary - dict_value),
                'raw_matches_native_float': abs(primary - float_value) <= tolerance,
                'raw_matches_native_dict': abs(primary - dict_value) <= tolerance,
                'stored_list_matches_native_float': abs(list_mev - float_value) <= tolerance,
                'stored_list_matches_native_dict': abs(list_mev - dict_value) <= tolerance,
                'native_float_equals_dict': float_value == dict_value,
                'printed_lexeme_meV': component['printed_lexeme'],
                'raw_matches_printed_interval': abs(primary - F(component['printed_lexeme'])) <= F(component['printed_half_last_digit']),
                'small_json_value_meV': component['json_central_value'],
                'raw_matches_small_json': abs(primary - F(component['json_central_value'])) <= tolerance,
                'list_CREATE_parent_ids': list_creators, 'float_CalcJob_typed_ancestor_ids': calc_ancestors}
            result['parameters'].append(row)
        result['aggregate'] = {**brief(aggregate), 'CREATE_parent_ids': db.links(aggregate['id'], 'create', incoming=True)}
    finally:
        db.close()
    rows, slots = result['parameters'], result['slots']
    summary = {'parameters': len(rows), 'energy_cases': sum(len(row['energies']) for row in rows),
        'objects': len(keys), 'source_nodes': 49, 'native_float_matches': sum(row['raw_matches_native_float'] for row in rows),
        'native_dict_matches': sum(row['raw_matches_native_dict'] for row in rows),
        'printed_interval_matches': sum(row['raw_matches_printed_interval'] for row in rows),
        'small_json_matches': sum(row['raw_matches_small_json'] for row in rows),
        'exact_List_slot_matches': sum(row['exact_decimal_value_equal'] for row in slots),
        'lists_without_CREATE_parent': sum(not row['list_CREATE_parent_ids'] for row in rows),
        'floats_without_CalcJob_typed_ancestor': sum(not row['float_CalcJob_typed_ancestor_ids'] for row in rows)}
    result['summary'] = summary
    require(summary['parameters'] == 12 and summary['energy_cases'] == 48 and summary['objects'] == 93
            and len(slots) == summary['exact_List_slot_matches'] == 48, 'FIXED_NUMERICAL_DENOMINATORS')
    require(summary['native_float_matches'] == summary['native_dict_matches'] == summary['printed_interval_matches'] == 12,
            'RAW_PARAMETER_DISAGREEMENT')
    require(all(row['stored_list_matches_native_float'] and row['stored_list_matches_native_dict']
                and row['native_float_equals_dict'] for row in rows), 'STORED_LIST_FLOAT_DICT_DISAGREEMENT')
    require(summary['small_json_matches'] == 0, 'FIXED_SMALL_JSON_CONTRAST_CHANGED')
    require(summary['lists_without_CREATE_parent'] == summary['floats_without_CalcJob_typed_ancestor'] == 12
            and result['aggregate']['CREATE_parent_ids'] == [], 'FIXED_PROVENANCE_ABSENCE_CHANGED')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    bundle, output = args.bundle.resolve(), args.output.resolve()
    require(bundle.is_dir(), 'BUNDLE_DIRECTORY_REQUIRED')
    require(not args.output.exists() and not args.output.is_symlink(), 'REFUSE_OUTPUT_OVERWRITE')
    require(output != bundle and bundle not in output.parents, 'OUTPUT_MUST_BE_OUTSIDE_BUNDLE')
    result = {'schema': 'vps3-portable-verification-v1', 'status': 'REJECTED',
        'started_utc': datetime.now(timezone.utc).isoformat(), 'parameters': [], 'slots': [],
        'scope': 'Offline recheck of fixed current retained bytes, typed database ports, selected input directions, printed energies and numerical List/Float/Dict compatibility. S=1 is a declared formula convention, not the initialization-moment denominator.',
        'small_json_scope': 'The twelve small-JSON values are a separate known numerical representation: zero matches is retained, not concealed as rounding.',
        'integrity_scope': 'The manifest checks package bytes; the fixed helper, native database, small-view ZIP and two selected members also have built-in digests. Printed and small-JSON target lexemes are checked against those original members. This is not a publisher signature or historical execution certificate.',
        'network_calls': 0, 'downloaded_author_source_executions': 0, 'typed_graph_edges_added': 0,
        'historical_execution_certified': False, 'historical_raw_to_List_identity_certified': False,
        'parser_semantics_certified': False, 'scientific_truth_certified': False, 'human_gold': False,
        'method_or_adaptive_advantage_established': False, 'p1_release': False}
    code = 1
    try:
        result['phase'] = 'manifest'
        entries, manifest_digest, total = verify_manifest(bundle)
        result['manifest_sha256'] = manifest_digest
        result['manifested_files'] = len(entries)
        result['manifested_bytes'] = total
        result['phase'] = 'native_ports_and_numerical_values'
        verify_science(bundle, entries, result)
        result['phase'] = 'final_input_stability'
        # Recheck the exact manifest and all files before reporting success.
        _, final_manifest_digest, _ = verify_manifest(bundle)
        require(final_manifest_digest == manifest_digest, 'MANIFEST_CHANGED_DURING_VERIFICATION')
        result['status'] = 'PASS_CURRENT_BYTES_TYPED_PORTS_AND_NUMERICAL_COMPATIBILITY'
        result['phase'] = 'complete'
        code = 0
    except Exception as exc:
        result['error_type'] = type(exc).__name__
        result['error'] = str(exc) if isinstance(exc, Rejected) else 'VERIFICATION_ABORTED_AT_RECORDED_PHASE'
    result['finished_utc'] = datetime.now(timezone.utc).isoformat()
    result['intended_exit_code'] = code
    payload = (json.dumps(result, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    require(len(payload) <= RESULT_CAP, 'RESULT_SIZE_CAP')
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('xb') as stream:
        stream.write(payload)
    print(result['status'], json.dumps(result.get('summary', {})), flush=True)
    return code


if __name__ == '__main__':
    sys.exit(main())
